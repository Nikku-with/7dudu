import { generateObject } from "ai";
import { z } from "zod";
import { getPlannerModel, type Provider } from "@/lib/ai-providers";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

interface AnalyzePlan {
  need_search: boolean;
  queries: string[];
  reason: string;
}

function heuristicPlan(message: string): AnalyzePlan {
  const m = message.trim();
  const smallTalk =
    /^(hi+|hii+|hello+|hey+|yo+|sup|namaste|thanks?|thank you|ok+|okay|hmm+|good (morning|night|evening)|kaise ho|kya haal|wassup|how are you)[\s!.?]*$/i.test(
      m
    ) || m.split(/\s+/).length < 2;
  if (smallTalk)
    return {
      need_search: false,
      queries: [],
      reason: "Greeting / small-talk — search not needed",
    };
  // strip filler words to make a decent query
  const q = m
    .replace(
      /\b(please|pls|bro|bhai|yaar|can you|could you|tell me|search( the)?( web)?( for)?|about|i want to know|batao|karo|kya hai)\b/gi,
      " "
    )
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 90);
  return {
    need_search: true,
    queries: [q || m.slice(0, 90)],
    reason: "Keyword extraction (no AI key for deep analysis)",
  };
}

interface PriorRound {
  queries: string[];
  results: { title: string; snippet: string; domain: string }[];
}

const PlanSchema = z.object({
  need_search: z.boolean().describe("Would a live web search genuinely help answer this?"),
  queries: z
    .array(z.string().max(100))
    .max(3)
    .describe("Short keyword-style English search queries (max 8 words each), one per sub-topic"),
  reason: z.string().max(120).describe("One short line explaining the decision"),
});

const RefineSchema = z.object({
  sufficient: z.boolean().describe("Do the collected sources already cover the question well?"),
  queries: z
    .array(z.string().max(100))
    .max(2)
    .describe("Refined queries taking a different angle, only if not sufficient"),
  reason: z.string().max(120).describe("One short line explaining the decision"),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body?.message)
    return Response.json({ error: "message required" }, { status: 400 });

  const { message, api_key, groq_key, provider } = body as Record<string, string>;
  const prior = body.prior as PriorRound | undefined;
  const isRefine = Boolean(prior && Array.isArray(prior.queries));

  const envGroq = process.env.GROQ_API_KEY || "";
  const envOr = process.env.OPENROUTER_API_KEY || "";
  const prov: Provider = provider === "groq" ? "groq" : "openrouter";
  const key = prov === "groq" ? groq_key || envGroq : api_key || envOr;

  if (!key || key.trim().length < 6) {
    if (isRefine) {
      // heuristic refine: enough if 6+ results
      const enough = (prior?.results?.length || 0) >= 6;
      return Response.json({
        need_search: !enough,
        sufficient: enough,
        queries: enough ? [] : [message.slice(0, 80) + " guide"],
        reason: enough ? "Enough sources collected" : "Few results — one more try",
      });
    }
    return Response.json(heuristicPlan(message));
  }

  try {
    const model = getPlannerModel({ provider: prov, apiKey: key });

    if (isRefine) {
      const { object } = await generateObject({
        model,
        schema: RefineSchema,
        temperature: 0.1,
        maxOutputTokens: 250,
        abortSignal: AbortSignal.timeout(12_000),
        system: `You are a search result evaluator in an agentic loop. The user asked a question, searches ran, and you see what was found. Decide: are these results SUFFICIENT to answer well, or do we need ANOTHER round with refined/different queries?

Rules:
- sufficient=true if the found titles/snippets clearly cover the user's question (or all sub-topics if multi-part)
- If user asked about MULTIPLE things, check EACH is covered; if one topic missing → sufficient=false, queries target ONLY the missing topic
- Refined queries must take a DIFFERENT angle than previous ones (synonyms, more specific terms, site-style keywords) — never repeat old queries`,
        prompt: `USER QUESTION: ${message.slice(0, 400)}

PREVIOUS QUERIES: ${prior!.queries.join(" | ")}

RESULTS FOUND SO FAR (${prior!.results.length}):
${prior!.results
  .slice(0, 15)
  .map((r, i) => `${i + 1}. [${r.domain}] ${r.title}${r.snippet ? ` — ${r.snippet.slice(0, 80)}` : ""}`)
  .join("\n")}`,
      });

      const sufficient = object.sufficient || object.queries.length === 0;
      return Response.json({
        sufficient,
        need_search: !sufficient,
        queries: sufficient ? [] : object.queries,
        reason: object.reason,
      });
    }

    const { object } = await generateObject({
      model,
      schema: PlanSchema,
      temperature: 0.1,
      maxOutputTokens: 250,
      abortSignal: AbortSignal.timeout(12_000),
      system: `You are a search query planner. Analyze the user's message and decide if a live web search would genuinely help answer it.

Rules:
- Greetings, small-talk, thanks, opinions, pure coding tasks ("build me a website", "fix this code") → need_search = false, queries = []
- Questions about current events, prices, versions, news, facts, comparisons, "latest X", real products/people → need_search = true
- If the user asks about MULTIPLE different things, make one query per topic (max 3)
- Write SHORT keyword-style search queries in English, NOT the user's sentence verbatim
- If the message is Hinglish, still write English queries`,
      prompt: message.slice(0, 500),
    });

    const plan: AnalyzePlan = {
      need_search: object.need_search,
      queries: object.queries.filter((q) => q.trim().length > 0),
      reason: object.reason,
    };
    if (plan.need_search && plan.queries.length === 0) {
      plan.queries = heuristicPlan(message).queries;
    }
    return Response.json(plan);
  } catch (e) {
    console.error("[ANALYZE] generateObject failed, falling back to heuristic:", (e as Error).message);
    return Response.json(heuristicPlan(message));
  }
}
