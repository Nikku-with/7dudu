"use client";

import { useEffect, useRef, useState } from "react";
import { useAgent, type Message } from "@/store/agent-store";
import Markdown from "./markdown";
import ThinkingCard from "./thinking-card";
import { copyText, downloadFile } from "@/lib/client-utils";
import RecentSourcesDropdown from "./recent-sources";

function MessageActions({ msg }: { msg: Message }) {
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);
  return (
    <div className="flex items-center gap-1.5 mt-1.5 opacity-60 hover:opacity-100 transition-opacity">
      <button
        onClick={async () => {
          if (await copyText(msg.content)) {
            setCopied(true);
            setTimeout(() => setCopied(false), 1500);
          }
        }}
        className="px-2 py-0.5 rounded text-[10px] font-bold bg-zinc-800/80 text-zinc-400 hover:text-zinc-100 active:scale-95 transition-all"
      >
        {copied ? "✓ Copied" : "📋 Copy"}
      </button>
      <button
        onClick={() => {
          if (downloadFile(`banana-response-${msg.id}.md`, msg.content, "text/markdown")) {
            setSaved(true);
            setTimeout(() => setSaved(false), 1500);
          }
        }}
        className="px-2 py-0.5 rounded text-[10px] font-bold bg-zinc-800/80 text-zinc-400 hover:text-zinc-100 active:scale-95 transition-all"
      >
        {saved ? "✓ Saved" : "⬇ .md"}
      </button>
      {msg.metadata?.model_used && (
        <span className="text-[10px] text-zinc-600 font-mono">
          {msg.metadata.demo ? "🍌 demo" : msg.metadata.model_used}
        </span>
      )}
      <span className="text-[10px] text-zinc-600 ml-auto">
        {new Date(msg.createdAt).toLocaleTimeString("en-IN", {
          hour: "2-digit",
          minute: "2-digit",
        })}
      </span>
    </div>
  );
}

function SourcesAccordion({
  sources,
}: {
  sources: NonNullable<Message["metadata"]["sources"]>;
}) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  const copy = async (url: string) => {
    if (await copyText(url)) {
      setCopied(url);
      setTimeout(() => setCopied(null), 1500);
    }
  };

  return (
    <div className="mt-2.5 rounded-xl border border-emerald-500/25 bg-emerald-950/20 overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-2 px-3 py-2 hover:bg-emerald-500/10 transition-colors"
      >
        <span className="text-[12px]">🔗</span>
        <span className="text-[11px] font-bold tracking-wider text-emerald-300 uppercase">
          Sources used
        </span>
        <span className="text-[10px] px-1.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold">
          {sources.length}
        </span>
        <span className="ml-auto flex items-center -space-x-1">
          {sources.slice(0, 5).map((s, i) => (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              key={i}
              src={`https://www.google.com/s2/favicons?domain=${s.domain}&sz=32`}
              alt=""
              className="w-4 h-4 rounded-full border border-zinc-800 bg-zinc-900"
            />
          ))}
        </span>
        <span className="text-[10px] text-emerald-400">{open ? "▲" : "▼"}</span>
      </button>
      {open && (
        <div className="max-h-52 overflow-y-auto scroll-thin border-t border-emerald-500/15 p-1.5 space-y-0.5">
          {sources.map((s, i) => (
            <div
              key={i}
              className="group flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-emerald-500/10 transition-colors"
            >
              <span className="text-[9px] text-emerald-600 font-mono w-4 text-right shrink-0">
                {i + 1}
              </span>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={`https://www.google.com/s2/favicons?domain=${s.domain}&sz=32`}
                alt=""
                className="w-4 h-4 rounded-sm shrink-0"
              />
              <a
                href={s.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[12px] text-emerald-100 truncate flex-1 hover:text-white"
                title={s.title}
              >
                {s.title}
              </a>
              <span className="text-[10px] text-emerald-500/80 truncate max-w-[100px] shrink-0 hidden sm:block">
                {s.domain}
              </span>
              <button
                onClick={() => copy(s.url)}
                className={`shrink-0 px-1.5 py-0.5 rounded text-[9px] font-bold transition-all active:scale-95 ${
                  copied === s.url
                    ? "bg-emerald-500/30 text-emerald-200"
                    : "bg-zinc-800/80 text-zinc-400 hover:text-zinc-100"
                }`}
                title="Copy link"
              >
                {copied === s.url ? "✓" : "📋"}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ── Reasoning / thinking collapsible pinned above each agent response ─── */
function ReasoningCollapse({
  text,
  live = false,
}: {
  text: string;
  live?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const bodyRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (open && bodyRef.current)
      bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
  }, [text, open]);
  if (!text) return null;
  return (
    <div className="mb-2 rounded-xl border border-purple-500/25 bg-purple-950/20 overflow-hidden text-[11px]">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-purple-500/10 transition-colors text-left"
      >
        <span className="text-purple-400">🧠</span>
        <span className="font-black tracking-widest text-purple-300 uppercase text-[9px]">
          Thinking Process
        </span>
        {live && (
          <span className="inline-block w-1.5 h-2.5 bg-purple-400 animate-blink align-middle" />
        )}
        <span className="ml-auto text-purple-500 font-mono">{text.length} chars</span>
        <span className="text-purple-500 ml-1">{open ? "▾" : "▸"}</span>
      </button>
      {open && (
        <div
          ref={bodyRef}
          className="max-h-52 overflow-y-auto scroll-thin px-3 pb-3 font-mono text-[10px] text-purple-200/80 leading-relaxed whitespace-pre-wrap border-t border-purple-500/15"
        >
          {text}
          {live && (
            <span className="inline-block w-1.5 h-2.5 bg-purple-400 animate-blink align-middle ml-0.5" />
          )}
        </div>
      )}
    </div>
  );
}

function Bubble({ msg }: { msg: Message }) {
  if (msg.role === "user") {
    return (
      <div className="flex justify-end animate-slide-in">
        <div className="max-w-[85%] rounded-2xl rounded-br-md bg-gradient-to-br from-yellow-400/15 to-amber-500/10 border border-yellow-500/25 px-4 py-2.5 shadow-[0_0_18px_rgba(250,204,21,0.1)]">
          <div className="text-[13.5px] text-zinc-100 whitespace-pre-wrap break-words leading-relaxed">
            {msg.content}
          </div>
          <div className="text-[10px] text-zinc-500 text-right mt-1">
            {new Date(msg.createdAt).toLocaleTimeString("en-IN", {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </div>
        </div>
      </div>
    );
  }
  if (msg.role === "system") {
    return (
      <div className="rounded-xl border border-red-500/30 bg-red-950/20 px-4 py-2.5 text-[13px] text-red-200 animate-slide-in">
        {msg.content}
      </div>
    );
  }
  return (
    <div className="flex gap-2.5 animate-slide-in">
      <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-yellow-400 to-amber-600 flex items-center justify-center text-lg shrink-0 mt-0.5 shadow-[0_0_16px_rgba(250,204,21,0.25)]">
        🍌
      </div>
      <div className="min-w-0 flex-1">
        {/* Reasoning dropdown — pinned above the response bubble */}
        {msg.metadata?.reasoning && (
          <ReasoningCollapse text={msg.metadata.reasoning} />
        )}
        <div className="rounded-2xl rounded-tl-md bg-zinc-900/80 border border-zinc-800 px-4 py-3 shadow-[0_1px_0_rgba(255,255,255,0.02)]">
          <Markdown content={msg.content} />
          {msg.metadata?.sources && msg.metadata.sources.length > 0 && (
            <SourcesAccordion sources={msg.metadata.sources} />
          )}
          <MessageActions msg={msg} />
        </div>
      </div>
    </div>
  );
}

function Welcome() {
  const { sendMessage } = useAgent();
  const starters = [
    { icon: "🌐", text: "Search the web: latest AI news today", search: true },
    { icon: "🕐", text: "What is the current date and time?" },
    { icon: "🏗️", text: "Build me a portfolio website with dark theme" },
    { icon: "🎮", text: "Create a snake game in JavaScript" },
  ];
  return (
    <div className="flex flex-col items-center justify-center h-full text-center px-6 py-10">
      <div className="text-6xl mb-3 animate-float">🍌</div>
      <h1 className="text-2xl font-black bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-300 bg-clip-text text-transparent">
        BANANA AGENT
      </h1>
      <p className="text-zinc-500 text-sm mt-1.5 max-w-sm">
        100 verified tools · live web search · realtime clock · multi-select widgets · copy & download everything
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-6 w-full max-w-lg">
        {starters.map((s, i) => (
          <button
            key={i}
            onClick={() => sendMessage(s.text, "normal", Boolean(s.search))}
            className="flex items-center gap-2.5 rounded-xl border border-zinc-800 bg-zinc-900/60 px-3.5 py-3 text-left text-[13px] text-zinc-300 hover:border-yellow-500/40 hover:bg-zinc-900 transition-all active:scale-[0.98]"
          >
            <span className="text-lg">{s.icon}</span>
            <span>{s.text}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((e: SpeechRecognitionEventLike) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
  start: () => void;
  stop: () => void;
}
interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: {
    length: number;
    [i: number]: { isFinal: boolean; 0: { transcript: string } };
  };
}

export function ChatInput() {
  const { sendMessage, loading, stopGeneration, hasKey, setShowSettings, settings, setSettings } = useAgent();
  const keyPresent = hasKey();
  const [text, setText] = useState("");
  const [mode, setMode] = useState("normal");
  const [webSearch, setWebSearch] = useState(false);
  const [listening, setListening] = useState(false);
  const [micSupported, setMicSupported] = useState(true);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const recRef = useRef<SpeechRecognitionLike | null>(null);
  const baseTextRef = useRef("");

  useEffect(() => {
    const w = window as unknown as Record<string, unknown>;
    setMicSupported(
      Boolean(w.SpeechRecognition || w.webkitSpeechRecognition)
    );
    return () => { recRef.current?.stop(); };
  }, []);

  const toggleMic = () => {
    if (listening) { recRef.current?.stop(); setListening(false); return; }
    const w = window as unknown as Record<string, unknown>;
    const SR = (w.SpeechRecognition || w.webkitSpeechRecognition) as
      | (new () => SpeechRecognitionLike) | undefined;
    if (!SR) { setMicSupported(false); return; }
    const rec = new SR();
    rec.lang = "en-IN";
    rec.continuous = true;
    rec.interimResults = true;
    baseTextRef.current = text ? text.trimEnd() + " " : "";
    rec.onresult = (e: SpeechRecognitionEventLike) => {
      let interim = ""; let finals = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript;
        if (e.results[i].isFinal) finals += t + " "; else interim += t;
      }
      if (finals) baseTextRef.current += finals;
      setText((baseTextRef.current + interim).replace(/\s+/g, " ").trimStart());
      const el = taRef.current;
      if (el) { el.style.height = "auto"; el.style.height = Math.min(el.scrollHeight, 144) + "px"; }
    };
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    recRef.current = rec;
    try { rec.start(); setListening(true); } catch { setListening(false); }
  };

  const submit = () => {
    const t = text.trim();
    if (!t || loading) return;
    if (listening) { recRef.current?.stop(); setListening(false); }
    setText("");
    sendMessage(t, mode, webSearch);
  };

  const MODES = [
    { id: "normal",   label: "🍌 Normal",   color: "bg-yellow-400 text-zinc-900",       glow: "" },
    { id: "3d_max",   label: "🌌 3D MAX",   color: "bg-blue-500 text-white",             glow: "shadow-[0_0_12px_rgba(59,130,246,0.5)]" },
    { id: "advanced", label: "⚡ FORGE",    color: "bg-purple-500 text-white",           glow: "shadow-[0_0_12px_rgba(168,85,247,0.5)]" },
  ];

  const EFFORTS: { id: "low" | "medium" | "high"; label: string; color: string }[] = [
    { id: "low",    label: "⚡ Low",    color: "bg-zinc-600 text-zinc-100" },
    { id: "medium", label: "⚖️ Mid",    color: "bg-yellow-400 text-zinc-900" },
    { id: "high",   label: "🧠 Deep",   color: "bg-purple-500 text-white" },
  ];

  const thinkOn = settings.thinkingEnabled !== false;
  const curEffort = settings.reasoningEffort || "medium";

  return (
    <div className="border-t border-zinc-800/80 bg-zinc-950/95 backdrop-blur px-3 sm:px-4 pt-2.5 pb-3">
      <div className="max-w-3xl mx-auto">
        {/* ── Toolbar row ─────────────────────────────────────────────── */}
        <div className="flex items-center gap-1.5 mb-2 flex-wrap">
          {/* Mode pills */}
          {MODES.map((m) => (
            <button
              key={m.id}
              onClick={() => setMode(m.id)}
              className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition-all ${
                mode === m.id
                  ? `${m.color} ${m.glow}`
                  : "bg-zinc-800/80 text-zinc-400 hover:text-zinc-200"
              }`}
            >
              {m.label}
            </button>
          ))}

          {/* Divider */}
          <span className="w-px h-4 bg-zinc-700 mx-0.5" />

          {/* Web search */}
          <button
            onClick={() => setWebSearch(!webSearch)}
            className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition-all ${
              webSearch
                ? "bg-emerald-500 text-zinc-900 shadow-[0_0_12px_rgba(52,211,153,0.4)]"
                : "bg-zinc-800/80 text-zinc-400 hover:text-zinc-200"
            }`}
          >
            🌐 {webSearch ? "Search ON" : "Search"}
          </button>

          {/* Thinking toggle */}
          <button
            onClick={() =>
              setSettings({ ...settings, thinkingEnabled: !thinkOn })
            }
            className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition-all ${
              thinkOn
                ? "bg-purple-500/25 text-purple-200 border border-purple-500/40"
                : "bg-zinc-800/80 text-zinc-500 hover:text-zinc-300"
            }`}
            title="Toggle AI thinking / chain-of-thought"
          >
            🧠 {thinkOn ? "Think ON" : "Think OFF"}
          </button>

          {/* Effort pills — only when thinking is on */}
          {thinkOn && (
            <div className="flex items-center gap-1">
              {EFFORTS.map((e) => (
                <button
                  key={e.id}
                  onClick={() => setSettings({ ...settings, reasoningEffort: e.id })}
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold transition-all ${
                    curEffort === e.id
                      ? e.color
                      : "bg-zinc-800/60 text-zinc-500 hover:text-zinc-300"
                  }`}
                >
                  {e.label}
                </button>
              ))}
            </div>
          )}

          {!keyPresent && (
            <button
              onClick={() => setShowSettings(true)}
              className="ml-auto px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30 animate-pulse"
            >
              🔑 Add key
            </button>
          )}
          <div className={keyPresent ? "ml-auto" : ""}><RecentSourcesDropdown /></div>
        </div>

        {/* ── Mode banner (visible when non-normal) ──────────────────── */}
        {mode !== "normal" && (
          <div
            className={`mb-1.5 px-3 py-1 rounded-lg text-[11px] font-bold flex items-center gap-2 ${
              mode === "3d_max"
                ? "bg-blue-500/10 border border-blue-500/20 text-blue-300"
                : "bg-purple-500/10 border border-purple-500/20 text-purple-300"
            }`}
          >
            {mode === "3d_max"
              ? "🌌 3D MAX mode — Three.js · GSAP · Shaders · Particle systems"
              : "⚡ FORGE mode — 6-layer deep reasoning · maximum output · production-grade"}
            <button onClick={() => setMode("normal")} className="ml-auto opacity-50 hover:opacity-100 text-[10px]">✕ normal</button>
          </div>
        )}

        {/* ── Textarea + send ─────────────────────────────────────────── */}
        <div className="flex items-end gap-2 rounded-2xl border border-zinc-700/80 bg-zinc-900 focus-within:border-yellow-500/50 transition-colors px-3 py-2">
          <textarea
            ref={taRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); }
            }}
            placeholder={
              listening
                ? "🎙️ Listening… bolo, live type ho raha hai"
                : webSearch
                  ? "🌐 Web search ON — ask anything live…"
                  : "Ask Banana Agent anything… (Shift+Enter = new line)"
            }
            rows={1}
            className="flex-1 bg-transparent resize-none outline-none text-[14px] text-zinc-100 placeholder:text-zinc-600 max-h-36 scroll-thin py-1"
            style={{ minHeight: 28 }}
            onInput={(e) => {
              const el = e.currentTarget;
              el.style.height = "auto";
              el.style.height = Math.min(el.scrollHeight, 144) + "px";
            }}
          />
          {micSupported && (
            <button
              onClick={toggleMic}
              className={`shrink-0 w-9 h-9 rounded-xl flex items-center justify-center active:scale-95 transition-all ${
                listening
                  ? "bg-red-500 text-white shadow-[0_0_16px_rgba(239,68,68,0.6)] animate-pulse"
                  : "bg-zinc-800 text-zinc-300 hover:bg-zinc-700 hover:text-yellow-300"
              }`}
              title={listening ? "Stop listening" : "Speak your prompt"}
            >
              {listening ? "🔴" : "🎙️"}
            </button>
          )}
          {loading ? (
            <button
              onClick={stopGeneration}
              className="shrink-0 w-9 h-9 rounded-xl bg-red-500/20 text-red-300 hover:bg-red-500/30 flex items-center justify-center active:scale-95 transition-all"
              title="Stop"
            >
              ⏹
            </button>
          ) : (
            <button
              onClick={submit}
              disabled={!text.trim()}
              className="shrink-0 w-9 h-9 rounded-xl bg-gradient-to-br from-yellow-400 to-amber-500 text-zinc-900 font-black flex items-center justify-center disabled:opacity-30 hover:brightness-110 active:scale-95 transition-all"
              title="Send"
            >
              ➤
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default function ChatPanel() {
  const { messages, streamingText, reasoningText, loading, currentSession } = useAgent();
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages.length, streamingText, reasoningText, loading]);

  const empty = !currentSession || (messages.length === 0 && !loading);

  return (
    <div className="flex flex-col h-full min-h-0">
      <div ref={scrollRef} className="flex-1 overflow-y-auto scroll-thin">
        {empty ? (
          <Welcome />
        ) : (
          <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-4">
            {messages.map((m) => (
              <Bubble key={m.id} msg={m} />
            ))}
            {loading && <ThinkingCard />}
            {streamingText && (
              <div className="flex gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-yellow-400 to-amber-600 flex items-center justify-center text-base shrink-0 mt-0.5 animate-pulse">
                  🍌
                </div>
                <div className="min-w-0 flex-1">
                  {/* Live reasoning collapse pinned above the streaming bubble */}
                  {reasoningText && (
                    <ReasoningCollapse text={reasoningText} live />
                  )}
                  <div className="rounded-2xl rounded-tl-md bg-zinc-900/80 border border-zinc-800 px-4 py-3">
                    {/* Pass streaming=false so widgets actually render, not shimmer */}
                    <Markdown content={streamingText} streaming={false} />
                    <span className="inline-block w-2 h-4 bg-yellow-400 animate-blink align-middle ml-0.5" />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
      <ChatInput />
    </div>
  );
}
