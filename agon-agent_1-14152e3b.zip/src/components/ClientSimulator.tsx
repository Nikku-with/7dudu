import React, { useState, useEffect } from 'react';
import { 
  Terminal, 
  Play, 
  RotateCcw, 
  Globe, 
  ArrowRight, 
  CheckCircle, 
  XCircle, 
  Eye, 
  EyeOff,
  ExternalLink,
  Search,
  Database
} from 'lucide-react';

interface AppItem {
  id: string;
  name: string;
  url: string;
  custom_domain: string;
  api_key: string;
  created_at: string;
}

interface ClientSimulatorProps {
  apps: AppItem[];
}

export default function ClientSimulator({ apps }: ClientSimulatorProps) {
  const [selectedApp, setSelectedApp] = useState<AppItem | null>(apps[0] || null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulationLogs, setSimulationLogs] = useState<string[]>([]);
  const [simStatus, setSimStatus] = useState<'IDLE' | 'SUCCESS' | 'NOT_FOUND' | 'ERROR'>('IDLE');
  const [simMessage, setSimMessage] = useState('');
  const [redirectUrl, setRedirectUrl] = useState('');

  // Real-time lookup state
  const [isCheckingEmail, setIsCheckingEmail] = useState(false);
  const [emailExists, setEmailExists] = useState<boolean | null>(null);
  const [emailCheckError, setEmailCheckError] = useState('');

  useEffect(() => {
    if (apps.length > 0 && !selectedApp) {
      setSelectedApp(apps[0]);
    }
  }, [apps]);

  const activeApp = selectedApp || {
    id: 'DEMO_ID',
    name: 'Nikku Portfolio',
    custom_domain: 'nikku.com',
    api_key: 'nk_live_demo123',
  };

  const addLog = (msg: string) => {
    setSimulationLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  // Trigger real-time check when email changes and has correct domain suffix
  useEffect(() => {
    const domain = email.split('@')[1];
    if (!email || !domain || domain !== activeApp.custom_domain) {
      setEmailExists(null);
      setEmailCheckError('');
      return;
    }

    const checkTimeout = setTimeout(async () => {
      setIsCheckingEmail(true);
      setEmailCheckError('');
      addLog(`[REAL-TIME LOOKUP] CALLING /api/get-info FOR "${email}"...`);

      try {
        const res = await fetch(`/api/get-info?api_key=${activeApp.api_key}&email=${encodeURIComponent(email)}`);
        const data = await res.json();
        
        if (res.ok) {
          setEmailExists(data.exists);
          if (data.exists) {
            addLog(`[REAL-TIME LOOKUP] VIRTUAL ACCOUNT EXISTS. STATUS: 200 OK.`);
          } else {
            addLog(`[REAL-TIME LOOKUP] ACCOUNT DOES NOT EXIST. REGISTRATION WILL TRIGGER ON SUBMIT.`);
          }
        } else {
          setEmailCheckError(data.error || 'Check failed.');
          addLog(`[REAL-TIME LOOKUP] ERROR: ${data.error || 'Failed to verify.'}`);
        }
      } catch (err: any) {
        setEmailCheckError('Network error.');
        addLog(`[REAL-TIME LOOKUP] NETWORK ERROR.`);
      } finally {
        setIsCheckingEmail(false);
      }
    }, 600); // 600ms debounce

    return () => clearTimeout(checkTimeout);
  }, [email, activeApp]);

  const handleSimulateLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    setIsSimulating(true);
    setSimStatus('IDLE');
    setSimMessage('');
    setRedirectUrl('');
    setSimulationLogs([]);

    addLog(`INITIATING SSO REQUEST FOR CLIENT APP: "${activeApp.name}"`);
    addLog(`VERIFYING EMAIL SUFFIX DOMAIN...`);

    const domain = email.split('@')[1];
    if (domain !== activeApp.custom_domain) {
      addLog(`ERROR: Email domain "@${domain}" does not match registered domain "@${activeApp.custom_domain}"`);
      setSimStatus('ERROR');
      setSimMessage(`Only emails ending with @${activeApp.custom_domain} are authorized for this app.`);
      setIsSimulating(false);
      return;
    }

    addLog(`DOMAIN VALIDATED. POSTING SECURE CREDENTIALS TO NIKKU GATEWAY...`);
    addLog(`ENDPOINT: /api/auth-gateway`);
    addLog(`X-API-KEY: ${activeApp.api_key.substring(0, 12)}...`);

    try {
      // Small artificial delay for realism
      await new Promise(resolve => setTimeout(resolve, 1000));

      const res = await fetch('/api/auth-gateway', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': activeApp.api_key
        },
        body: JSON.stringify({ email, password })
      });

      const data = await res.json();

      if (res.ok && data.status === 'LOGIN_SUCCESS') {
        addLog(`GATEWAY RESPONSE: 200 OK (LOGIN_SUCCESS)`);
        addLog(`VIRTUAL USER "${data.user.email}" AUTHENTICATED SUCCESSFULLY!`);
        setSimStatus('SUCCESS');
        setSimMessage('Welcome back! Login was validated in real-time on Nikku Secure Server.');
      } else if (res.status === 404 && data.status === 'USER_NOT_FOUND') {
        addLog(`GATEWAY RESPONSE: 404 NOT FOUND (USER_NOT_FOUND)`);
        addLog(`INSTRUCTION RECEIVED: Redirect to Nikku Verification Portal.`);
        setSimStatus('NOT_FOUND');
        setSimMessage(data.message);
        
        // Formulate redirect URL
        const portalUrl = `/verify-portal?app_id=${activeApp.id}&email=${encodeURIComponent(email)}&req_pass=${encodeURIComponent(password)}&redirect_back=${encodeURIComponent(window.location.origin + '/?sim_success=true')}`;
        setRedirectUrl(portalUrl);
      } else {
        addLog(`GATEWAY RESPONSE: ${res.status} ERROR`);
        addLog(`REASON: ${data.error || 'Invalid credentials'}`);
        setSimStatus('ERROR');
        setSimMessage(data.error || 'Authentication Failed.');
      }

    } catch (err: any) {
      addLog(`FATAL ERROR: Failed to reach auth gateway server.`);
      setSimStatus('ERROR');
      setSimMessage(err.message || 'Connection lost.');
    } finally {
      setIsSimulating(false);
    }
  };

  const handleReset = () => {
    setEmail('');
    setPassword('');
    setSimulationLogs([]);
    setSimStatus('IDLE');
    setSimMessage('');
    setRedirectUrl('');
    setEmailExists(null);
    setEmailCheckError('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Left Column: Client Login UI Simulator */}
      <div className="space-y-6">
        <div>
          <h3 className="text-base font-bold text-white tracking-wide uppercase">
            CLIENT LOGIN UI SIMULATOR
          </h3>
          <p className="text-xs text-zinc-500">
            Simulate how your client websites will handle virtual custom email signups and logins
          </p>
        </div>

        <div className="bg-zinc-950 border-2 border-zinc-900 rounded-xl overflow-hidden shadow-2xl">
          {/* Simulated Browser Address Bar */}
          <div className="bg-zinc-900/80 px-4 py-2 border-b border-zinc-950 flex items-center gap-2">
            <div className="flex gap-1.5 shrink-0">
              <span className="w-3 h-3 bg-red-500/80 rounded-full" />
              <span className="w-3 h-3 bg-yellow-500/80 rounded-full" />
              <span className="w-3 h-3 bg-green-500/80 rounded-full" />
            </div>
            <div className="w-full bg-black/50 border border-zinc-800 rounded px-3 py-1 text-[10px] text-zinc-400 font-mono flex items-center justify-between">
              <span className="truncate">https://{activeApp.name.toLowerCase().replace(/\s+/g, '-') || 'my-site'}.com/login</span>
              <Globe className="w-3.5 h-3.5 text-zinc-600" />
            </div>
          </div>

          {/* Login Form Container */}
          <div className="p-8 bg-zinc-950 relative">
            <div className="max-w-xs mx-auto space-y-6">
              <div className="text-center">
                <span className="text-[10px] uppercase font-bold tracking-widest text-zinc-500">WELCOME TO</span>
                <h4 className="text-lg font-bold text-white uppercase tracking-wider mt-1">
                  {activeApp.name}
                </h4>
                <p className="text-[10px] text-zinc-500 mt-1">
                  Secure login powered by <span className="text-green-500 font-bold">@nikku-auth</span>
                </p>
              </div>

              <form onSubmit={handleSimulateLogin} className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="block text-[10px] text-zinc-400 uppercase tracking-wider font-bold">
                      Virtual Email
                    </label>
                    {/* Live lookup indicators */}
                    {isCheckingEmail && (
                      <span className="text-[9px] text-yellow-500 font-bold animate-pulse uppercase">
                        🔍 Checking Database...
                      </span>
                    )}
                    {!isCheckingEmail && emailExists === true && (
                      <span className="text-[9px] text-green-400 font-bold uppercase flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" /> Account Found
                      </span>
                    )}
                    {!isCheckingEmail && emailExists === false && (
                      <span className="text-[9px] text-cyan-400 font-bold uppercase flex items-center gap-1">
                        ✨ New Account (Auto-Redirect)
                      </span>
                    )}
                  </div>
                  
                  <input
                    type="text"
                    placeholder={`username@${activeApp.custom_domain}`}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-xs text-green-400 focus:outline-none focus:border-green-500 font-bold placeholder:text-zinc-800"
                    disabled={isSimulating}
                  />
                  <span className="text-[9px] text-zinc-600 mt-1 block">
                    Must end with <span className="text-green-500 font-bold">@{activeApp.custom_domain}</span>
                  </span>
                </div>

                <div>
                  <label className="block text-[10px] text-zinc-400 uppercase tracking-wider mb-1 font-bold">
                    Password Key
                  </label>
                  <div className="relative">
                    <input
                      type={showPass ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-xs text-green-400 focus:outline-none focus:border-green-500 font-bold tracking-widest"
                      disabled={isSimulating}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPass(!showPass)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-zinc-600 hover:text-green-400"
                    >
                      {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSimulating || !email || !password}
                  className="w-full py-2.5 bg-green-950 hover:bg-green-900 text-green-400 border border-green-500/30 hover:border-green-400 rounded text-xs font-bold tracking-widest transition-all uppercase"
                >
                  {isSimulating ? 'SSO Gate Checking...' : 'Sign In / Register'}
                </button>
              </form>

              {/* Simulation Result Boxes */}
              {simStatus === 'SUCCESS' && (
                <div className="bg-green-950/20 border border-green-500/40 rounded-lg p-4 text-xs space-y-2">
                  <div className="flex items-center gap-2 text-green-400 font-bold">
                    <CheckCircle className="w-4 h-4 shrink-0" />
                    LOGIN SUCCESSFUL!
                  </div>
                  <p className="text-zinc-300 leading-relaxed">{simMessage}</p>
                </div>
              )}

              {simStatus === 'ERROR' && (
                <div className="bg-red-950/20 border border-red-500/40 rounded-lg p-4 text-xs space-y-2">
                  <div className="flex items-center gap-2 text-red-400 font-bold">
                    <XCircle className="w-4 h-4 shrink-0" />
                    AUTHENTICATION REFUSED
                  </div>
                  <p className="text-zinc-300 leading-relaxed">{simMessage}</p>
                </div>
              )}

              {simStatus === 'NOT_FOUND' && (
                <div className="bg-yellow-950/20 border-2 border-yellow-500/30 rounded-lg p-4 text-xs space-y-3">
                  <div className="flex items-center gap-2 text-yellow-500 font-bold uppercase">
                    <ArrowRight className="w-4 h-4 shrink-0" />
                    REDIRECT ENFORCED
                  </div>
                  <p className="text-zinc-300 leading-relaxed">{simMessage}</p>
                  
                  <a
                    href={redirectUrl}
                    className="w-full py-2 bg-yellow-950 hover:bg-yellow-900 text-yellow-400 border border-yellow-500/40 hover:border-yellow-400 rounded text-[10px] font-bold tracking-widest transition-all text-center flex items-center justify-center gap-1.5 uppercase"
                  >
                    REDIRECT TO NIKKU SSO PORTAL <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Right Column: Live Terminal Debug Logs */}
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h3 className="text-base font-bold text-white tracking-wide uppercase flex items-center gap-2">
            <Terminal className="w-5 h-5 text-green-400" />
            LIVE SECURITY TERMINAL
          </h3>
          <button
            onClick={handleReset}
            className="p-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-zinc-400 hover:text-white rounded text-xs font-bold transition-all flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3" /> RESET
          </button>
        </div>

        <div className="bg-black border border-zinc-900 rounded-xl p-6 h-[400px] flex flex-col justify-between font-mono shadow-2xl relative">
          <div className="absolute top-3 right-3 flex items-center gap-1.5">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-ping" />
            <span className="text-[9px] text-green-600 font-bold uppercase">MONITORING</span>
          </div>

          <div className="overflow-y-auto space-y-2 text-[10px] text-zinc-400 select-text scrollbar-none h-full">
            <p className="text-zinc-600">// NIKKU SECURITY GATEWAY CLIENT SIMULATION LOGS</p>
            <p className="text-zinc-600">// READY FOR ACTION. ENTER CREDENTIALS TO SIMULATE.</p>
            
            {simulationLogs.map((log, index) => {
              let color = 'text-zinc-400';
              if (log.includes('ERROR') || log.includes('REFUSED')) color = 'text-red-400 font-bold';
              else if (log.includes('SUCCESS') || log.includes('VALIDATED')) color = 'text-green-400 font-bold';
              else if (log.includes('REDIRECT')) color = 'text-yellow-500 font-bold';
              else if (log.includes('INITIATING')) color = 'text-cyan-400 font-bold';
              else if (log.includes('REAL-TIME')) color = 'text-purple-400';

              return (
                <p key={index} className={color}>
                  {log}
                </p>
              );
            })}
          </div>

          <div className="border-t border-zinc-900 pt-4 mt-4 text-[9px] text-zinc-600 flex justify-between items-center">
            <span>SECURE GATEWAY SIMULATOR V1.1</span>
            <span>SYSTEM AUDITED</span>
          </div>
        </div>
      </div>
    </div>
  );
}
