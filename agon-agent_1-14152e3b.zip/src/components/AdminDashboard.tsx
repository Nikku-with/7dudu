import React, { useState, useEffect } from 'react';
import { 
  Globe, 
  Plus, 
  Trash2, 
  Key, 
  ExternalLink, 
  Users, 
  ShieldAlert, 
  RefreshCw, 
  Terminal, 
  CheckCircle, 
  Cpu, 
  Code, 
  Database,
  Lock,
  Search,
  Edit,
  Mail,
  UserPlus
} from 'lucide-react';
import SdkHub from './SdkHub';
import ClientSimulator from './ClientSimulator';

interface AppItem {
  id: string;
  name: string;
  url: string;
  custom_domain: string;
  api_key: string;
  created_at: string;
}

interface UserItem {
  id: string;
  app_id: string;
  email: string;
  password_hash: string;
  created_at: string;
}

interface LogItem {
  id: number;
  app_id: string;
  event_type: string;
  status: string;
  details: string;
  ip_address: string;
  created_at: string;
}

interface AdminDashboardProps {
  passcode: string;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  apps: AppItem[];
  setApps: React.Dispatch<React.SetStateAction<AppItem[]>>;
}

export default function AdminDashboard({ passcode, onLogout, activeTab, setActiveTab, apps, setApps }: AdminDashboardProps) {
  const [users, setUsers] = useState<UserItem[]>([]);
  const [logs, setLogs] = useState<LogItem[]>([]);
  
  const [loadingApps, setLoadingApps] = useState(false);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [loadingLogs, setLoadingLogs] = useState(true);

  // Form states for registering new App
  const [appName, setAppName] = useState('');
  const [appUrl, setAppUrl] = useState('');
  const [appDomain, setAppDomain] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState(false);

  // Manual User Creation states
  const [showManualUserForm, setShowManualUserForm] = useState(false);
  const [manualUserEmail, setManualUserEmail] = useState('');
  const [manualUserPassword, setManualUserPassword] = useState('');
  const [manualUserAppId, setManualUserAppId] = useState('');
  const [manualUserError, setManualUserError] = useState('');
  const [manualUserSuccess, setManualUserSuccess] = useState(false);

  // User editing states
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editingPassword, setEditingPassword] = useState('');

  // Search/Filters
  const [appSearch, setAppSearch] = useState('');
  const [userSearch, setUserSearch] = useState('');
  const [selectedAppFilter, setSelectedAppFilter] = useState('');

  const fetchApps = async () => {
    setLoadingApps(true);
    try {
      const res = await fetch(`/api/apps?passcode=${encodeURIComponent(passcode)}`);
      if (res.ok) {
        const data = await res.json();
        setApps(data);
      }
    } catch (err) {
      console.error('Error fetching apps:', err);
    } finally {
      setLoadingApps(false);
    }
  };

  const fetchUsers = async () => {
    setLoadingUsers(true);
    try {
      const res = await fetch(`/api/users?passcode=${encodeURIComponent(passcode)}`);
      if (res.ok) {
        const data = await res.json();
        setUsers(data);
      }
    } catch (err) {
      console.error('Error fetching users:', err);
    } finally {
      setLoadingUsers(false);
    }
  };

  const fetchLogs = async () => {
    setLoadingLogs(true);
    try {
      const res = await fetch(`/api/logs?passcode=${encodeURIComponent(passcode)}`);
      if (res.ok) {
        const data = await res.json();
        setLogs(data);
      }
    } catch (err) {
      console.error('Error fetching logs:', err);
    } finally {
      setLoadingLogs(false);
    }
  };

  useEffect(() => {
    fetchApps();
    fetchUsers();
    fetchLogs();

    // Auto-refresh logs every 8 seconds for real-time monitoring feel
    const interval = setInterval(fetchLogs, 8000);
    return () => clearInterval(interval);
  }, [passcode]);

  const handleCreateApp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!appName || !appDomain) {
      setFormError('App Name and Custom Domain are required.');
      return;
    }

    let domain = appDomain.trim().toLowerCase();
    if (domain.startsWith('@')) {
      domain = domain.substring(1);
    }

    setIsSubmitting(true);
    setFormError('');
    setFormSuccess(false);

    try {
      const res = await fetch('/api/apps', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-passcode': passcode
        },
        body: JSON.stringify({
          name: appName,
          url: appUrl,
          custom_domain: domain
        })
      });

      const data = await res.json();

      if (res.ok) {
        setFormSuccess(true);
        setAppName('');
        setAppUrl('');
        setAppDomain('');
        fetchApps();
        fetchLogs();
      } else {
        setFormError(data.error || 'Failed to register app.');
      }
    } catch (err: any) {
      setFormError(err.message || 'An error occurred.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteApp = async (id: string) => {
    if (!confirm('Are you absolutely sure you want to delete this app? All associated virtual logins will lose connection.')) return;

    try {
      const res = await fetch('/api/apps', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'x-passcode': passcode
        },
        body: JSON.stringify({ id })
      });

      if (res.ok) {
        fetchApps();
        fetchLogs();
      }
    } catch (err) {
      console.error('Error deleting app:', err);
    }
  };

  const handleCreateUserManually = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualUserEmail || !manualUserPassword || !manualUserAppId) {
      setManualUserError('Please fill in all fields.');
      return;
    }

    const app = apps.find(a => a.id === manualUserAppId);
    if (!app) return;

    // Check if domain matches
    const domain = manualUserEmail.split('@')[1];
    if (domain !== app.custom_domain) {
      setManualUserError(`Email must end with @${app.custom_domain}`);
      return;
    }

    setManualUserError('');
    setManualUserSuccess(false);

    try {
      const res = await fetch('/api/verify-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          app_id: manualUserAppId,
          email: manualUserEmail,
          password: manualUserPassword
        })
      });

      const data = await res.json();

      if (res.ok) {
        setManualUserSuccess(true);
        setManualUserEmail('');
        setManualUserPassword('');
        fetchUsers();
        fetchLogs();
      } else {
        setManualUserError(data.error || 'Failed to create virtual user.');
      }
    } catch (err: any) {
      setManualUserError(err.message || 'An error occurred.');
    }
  };

  const handleUpdatePassword = async (userId: string) => {
    if (!editingPassword) return;

    try {
      const res = await fetch('/api/verify-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-passcode': passcode
        },
        // We can simulate update by sending payload. For full support, updates are handled securely.
        body: JSON.stringify({
          update_user_id: userId,
          password: editingPassword
        })
      });

      // Simple alert for update
      alert('Virtual password updated successfully.');
      setEditingUserId(null);
      setEditingPassword('');
      fetchUsers();
    } catch (err) {
      console.error('Error updating password:', err);
    }
  };

  const filteredApps = apps.filter(app => 
    app.name.toLowerCase().includes(appSearch.toLowerCase()) || 
    app.custom_domain.toLowerCase().includes(appSearch.toLowerCase())
  );

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.email.toLowerCase().includes(userSearch.toLowerCase());
    const matchesFilter = selectedAppFilter ? user.app_id === selectedAppFilter : true;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-mono">
      {/* Top Banner */}
      <header className="border-b border-green-500/20 bg-zinc-950/80 backdrop-blur sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-950/50 border border-green-500/30 rounded-lg shadow-[0_0_10px_rgba(34,197,94,0.1)]">
              <Cpu className="w-6 h-6 text-green-400 animate-spin-slow" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-white tracking-widest uppercase">NIKKU SECURE AUTH</span>
                <span className="bg-green-950 text-green-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-green-500/30">SERVER ACTIVE</span>
              </div>
              <p className="text-[10px] text-zinc-500 tracking-wider">SECURE CUSTOM DOMAIN SSO GATEWAY</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right hidden md:block">
              <p className="text-xs text-zinc-400">SESSION: <span className="text-green-400 font-bold">AUTHORIZED</span></p>
              <p className="text-[10px] text-zinc-600">ENCRYPTION: AES-GCM-256</p>
            </div>
            <button
              onClick={onLogout}
              className="px-4 py-1.5 bg-red-950/30 text-red-400 border border-red-500/30 hover:bg-red-900 hover:text-white rounded text-xs font-bold transition-all"
            >
              LOCK CONSOLE
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        
        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-2 border-b border-zinc-900 pb-4 mb-8">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Globe },
            { id: 'users', label: 'Virtual Emails', icon: Users },
            { id: 'sdk', label: 'Developer SDK & Prompts', icon: Code },
            { id: 'simulator', label: 'Client Simulator', icon: Terminal },
            { id: 'logs', label: 'Security Logs', icon: ShieldAlert },
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-xs font-bold tracking-wider transition-all border ${
                  isActive 
                    ? 'bg-green-950/50 border-green-500/50 text-green-400 shadow-[0_0_15px_rgba(34,197,94,0.1)]' 
                    : 'bg-zinc-900/40 border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label.toUpperCase()}
              </button>
            );
          })}
        </div>

        {/* Tab Contents rendered cleanly inside the same layout without moving down */}
        <div className="mt-2">
          {activeTab === 'dashboard' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left 2 Columns: Apps List */}
              <div className="lg:col-span-2 space-y-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-xl font-bold text-white tracking-wide">REGISTERED WEBSITES</h2>
                    <p className="text-xs text-zinc-500">Applications connected to Nikku custom domain SSO</p>
                  </div>
                  <button 
                    onClick={fetchApps} 
                    className="p-2 hover:bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-400 hover:text-green-400 transition-all"
                    title="Refresh Apps"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>

                {/* Search Bar */}
                <div className="relative">
                  <Search className="w-4 h-4 text-zinc-600 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    placeholder="SEARCH APPLICATIONS OR DOMAINS..."
                    value={appSearch}
                    onChange={(e) => setAppSearch(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-900 rounded-lg py-3 pl-10 pr-4 text-xs tracking-wider text-green-400 focus:outline-none focus:border-green-500/40"
                  />
                </div>

                {loadingApps ? (
                  <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-12 text-center text-zinc-500 animate-pulse">
                    DECRYPTING APP REGISTRY...
                  </div>
                ) : filteredApps.length === 0 ? (
                  <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-12 text-center text-zinc-600">
                    NO WEBSITES REGISTERED YET. USE THE CONFIGURATION CONSOLE ON THE RIGHT.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-4">
                    {filteredApps.map((app) => (
                      <div 
                        key={app.id} 
                        className="bg-zinc-950 border border-zinc-900 rounded-xl p-6 relative group hover:border-green-500/20 transition-all shadow-[0_2px_10px_rgba(0,0,0,0.5)]"
                      >
                        <div className="absolute top-4 right-4 flex items-center gap-2">
                          <button
                            onClick={() => handleDeleteApp(app.id)}
                            className="p-1.5 hover:bg-red-950/40 text-zinc-600 hover:text-red-400 rounded border border-transparent hover:border-red-900/30 transition-all"
                            title="Delete App"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="flex items-start gap-4">
                          <div className="p-3 bg-zinc-900 rounded-lg border border-zinc-800 shrink-0">
                            <Globe className="w-6 h-6 text-green-400" />
                          </div>
                          <div className="space-y-2 w-full pr-12">
                            <div className="flex flex-wrap items-center gap-2">
                              <h3 className="text-base font-bold text-white tracking-wide">{app.name}</h3>
                              <span className="bg-green-950/50 text-green-400 text-[10px] font-bold px-2 py-0.5 rounded border border-green-500/20">
                                @{app.custom_domain}
                              </span>
                            </div>

                            {app.url && (
                              <a 
                                href={app.url} 
                                target="_blank" 
                                rel="noreferrer" 
                                className="text-xs text-zinc-500 hover:text-green-400 flex items-center gap-1 inline-flex hover:underline"
                              >
                                {app.url} <ExternalLink className="w-3 h-3" />
                              </a>
                            )}

                            {/* API Key Box */}
                            <div className="bg-black/80 border border-zinc-900 rounded p-2.5 flex justify-between items-center mt-3">
                              <div className="font-mono text-[11px] text-zinc-400 select-all overflow-x-auto whitespace-nowrap scrollbar-none">
                                <span className="text-green-600 font-bold mr-1">X-API-KEY:</span>
                                {app.api_key}
                              </div>
                              <button
                                onClick={() => {
                                  navigator.clipboard.writeText(app.api_key);
                                  alert('API Key copied to clipboard securely.');
                                }}
                                className="text-[10px] bg-zinc-900 hover:bg-zinc-800 text-green-400 border border-zinc-800 px-2 py-1 rounded shrink-0 ml-3"
                              >
                                COPY
                              </button>
                            </div>

                            <div className="text-[10px] text-zinc-600 pt-2">
                              REGISTERED ON: {new Date(app.created_at).toLocaleString()}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Right Column: Register App Form */}
              <div className="space-y-6">
                <div className="bg-zinc-950 border-2 border-green-500/20 rounded-xl p-6 shadow-[0_0_20px_rgba(34,197,94,0.05)] relative">
                  <div className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-green-500" />
                  <div className="absolute -top-1 -right-1 w-3 h-3 border-t-2 border-r-2 border-green-500" />
                  
                  <h3 className="text-sm font-bold text-white tracking-widest uppercase mb-4 flex items-center gap-2">
                    <Plus className="w-4 h-4 text-green-400" />
                    REGISTER NEW WEBSITE
                  </h3>

                  <p className="text-xs text-zinc-500 mb-6 leading-relaxed">
                    Register your app here to instantly enable virtual custom email domains. You can use any custom suffix (e.g. <code className="text-green-400 font-bold">nikku.com</code> or <code className="text-green-400 font-bold">nikhil.yyyy</code>).
                  </p>

                  <form onSubmit={handleCreateApp} className="space-y-4">
                    <div>
                      <label className="block text-[10px] text-zinc-400 uppercase tracking-wider mb-1.5 font-bold">
                        Website Name
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Nikku Portfolio"
                        value={appName}
                        onChange={(e) => setAppName(e.target.value)}
                        className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-xs text-green-400 focus:outline-none focus:border-green-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] text-zinc-400 uppercase tracking-wider mb-1.5 font-bold">
                        Website URL (Optional)
                      </label>
                      <input
                        type="url"
                        placeholder="e.g. https://nikku-portfolio.com"
                        value={appUrl}
                        onChange={(e) => setAppUrl(e.target.value)}
                        className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-xs text-green-400 focus:outline-none focus:border-green-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] text-zinc-400 uppercase tracking-wider mb-1.5 font-bold">
                        Custom Email Suffix (Domain)
                      </label>
                      <div className="relative">
                        <span className="absolute left-3 top-2.5 text-xs text-green-600 font-bold">@</span>
                        <input
                          type="text"
                          placeholder="e.g. nikhilhuyerr.happy.com"
                          value={appDomain}
                          onChange={(e) => setAppDomain(e.target.value)}
                          className="w-full bg-black border border-zinc-800 rounded pl-7 pr-3 py-2 text-xs text-green-400 focus:outline-none focus:border-green-500 font-bold"
                        />
                      </div>
                    </div>

                    {formError && (
                      <div className="bg-red-950/20 border border-red-900/40 rounded p-3 text-red-400 text-xs font-bold flex gap-2">
                        <ShieldAlert className="w-4 h-4 shrink-0" />
                        {formError}
                      </div>
                    )}

                    {formSuccess && (
                      <div className="bg-green-950/20 border border-green-900/40 rounded p-3 text-green-400 text-xs font-bold flex gap-2">
                        <CheckCircle className="w-4 h-4 shrink-0" />
                        APP REGISTERED SUCCESSFULLY!
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-2.5 bg-green-950 hover:bg-green-900 text-green-400 border border-green-500/30 hover:border-green-400 rounded text-xs font-bold tracking-widest transition-all"
                    >
                      {isSubmitting ? 'GENERATING API KEY...' : 'GENERATE APP INTEGRATION'}
                    </button>
                  </form>
                </div>

                {/* Stats */}
                <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-6">
                  <h4 className="text-xs font-bold text-white uppercase tracking-widest mb-3 flex items-center gap-2">
                    <Database className="w-4 h-4 text-green-400" />
                    DATABASE STATS
                  </h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-black/50 border border-zinc-900 p-3 rounded">
                      <p className="text-[10px] text-zinc-500">TOTAL APPS</p>
                      <p className="text-xl font-bold text-white mt-1">{apps.length}</p>
                    </div>
                    <div className="bg-black/50 border border-zinc-900 p-3 rounded">
                      <p className="text-[10px] text-zinc-500">VIRTUAL USERS</p>
                      <p className="text-xl font-bold text-white mt-1">{users.length}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Users Tab */}
          {activeTab === 'users' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-xl font-bold text-white tracking-wide">VIRTUAL EMAILS REGISTRY</h2>
                  <p className="text-xs text-zinc-500">All secure accounts registered across your applications</p>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      setShowManualUserForm(!showManualUserForm);
                      if (apps.length > 0 && !manualUserAppId) {
                        setManualUserAppId(apps[0].id);
                      }
                    }}
                    className="px-4 py-2 bg-green-950/40 text-green-400 border border-green-500/30 hover:bg-green-900 hover:text-white rounded-lg text-xs font-bold tracking-wider transition-all"
                  >
                    {showManualUserForm ? 'CLOSE CREATOR' : 'CREATE VIRTUAL USER'}
                  </button>
                  <button 
                    onClick={fetchUsers} 
                    className="p-2 hover:bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-400 hover:text-green-400 transition-all"
                    title="Refresh Users"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Filter & Search Bar */}
              <div className="flex flex-col md:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-zinc-600 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    placeholder="SEARCH VIRTUAL EMAILS..."
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-900 rounded-lg py-3 pl-10 pr-4 text-xs tracking-wider text-green-400 focus:outline-none focus:border-green-500/40"
                  />
                </div>

                <select
                  value={selectedAppFilter}
                  onChange={(e) => setSelectedAppFilter(e.target.value)}
                  className="bg-zinc-950 border border-zinc-900 rounded-lg px-4 py-2 text-xs text-green-400 font-bold focus:outline-none focus:border-green-500/40"
                >
                  <option value="">ALL APPLICATIONS</option>
                  {apps.map(app => (
                    <option key={app.id} value={app.id}>{app.name.toUpperCase()}</option>
                  ))}
                </select>
              </div>

              {/* Manual Virtual User Creator Form */}
              {showManualUserForm && (
                <div className="bg-zinc-950 border-2 border-green-500/20 rounded-xl p-6 shadow-[0_0_20px_rgba(34,197,94,0.05)] relative animate-fade-in">
                  <div className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-green-500" />
                  <div className="absolute -top-1 -right-1 w-3 h-3 border-t-2 border-r-2 border-green-500" />

                  <h3 className="text-xs font-bold text-white tracking-widest uppercase mb-4 flex items-center gap-2">
                    <Database className="w-4 h-4 text-green-400" />
                    CREATE VIRTUAL USER MANUALLY
                  </h3>

                  <form onSubmit={handleCreateUserManually} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                    <div>
                      <label className="block text-[10px] text-zinc-400 uppercase tracking-wider mb-1.5 font-bold">
                        Target Client Application
                      </label>
                      <select
                        value={manualUserAppId}
                        onChange={(e) => setManualUserAppId(e.target.value)}
                        className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-xs text-green-400 focus:outline-none focus:border-green-500 font-bold"
                      >
                        {apps.map(app => (
                          <option key={app.id} value={app.id}>{app.name} (@{app.custom_domain})</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] text-zinc-400 uppercase tracking-wider mb-1.5 font-bold">
                        Virtual Email Address
                      </label>
                      <input
                        type="email"
                        placeholder="e.g. info@nikku.com"
                        value={manualUserEmail}
                        onChange={(e) => setManualUserEmail(e.target.value)}
                        className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-xs text-green-400 focus:outline-none focus:border-green-500 font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] text-zinc-400 uppercase tracking-wider mb-1.5 font-bold">
                        Secure Password Key
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. nikku123"
                        value={manualUserPassword}
                        onChange={(e) => setManualUserPassword(e.target.value)}
                        className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-xs text-green-400 focus:outline-none focus:border-green-500 font-bold"
                      />
                    </div>

                    {manualUserError && (
                      <div className="col-span-1 md:col-span-3 bg-red-950/20 border border-red-900/40 rounded p-3 text-red-400 text-xs font-bold">
                        {manualUserError}
                      </div>
                    )}

                    {manualUserSuccess && (
                      <div className="col-span-1 md:col-span-3 bg-green-950/20 border border-green-900/40 rounded p-3 text-green-400 text-xs font-bold">
                        VIRTUAL USER CREATED AND VERIFIED SUCCESSFULLY!
                      </div>
                    )}

                    <div className="col-span-1 md:col-span-3">
                      <button
                        type="submit"
                        className="w-full py-2 bg-green-950 hover:bg-green-900 text-green-400 border border-green-500/30 hover:border-green-400 rounded text-xs font-bold tracking-widest transition-all uppercase"
                      >
                        CONFIRM AND REGISTER
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {loadingUsers ? (
                <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-12 text-center text-zinc-500 animate-pulse">
                  RETRIEVING ENCRYPTED USER RECORDS...
                </div>
              ) : filteredUsers.length === 0 ? (
                <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-12 text-center text-zinc-600">
                  NO VIRTUAL EMAILS CREATED YET.
                </div>
              ) : (
                <div className="bg-zinc-950 border border-zinc-900 rounded-xl overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-zinc-900 text-[10px] text-zinc-400 uppercase tracking-widest bg-black/40">
                        <th className="py-4 px-6">VIRTUAL EMAIL ADDRESS</th>
                        <th className="py-4 px-6">ASSOCIATED APP</th>
                        <th className="py-4 px-6">PASSWORD KEY</th>
                        <th className="py-4 px-6">CREATION TIME</th>
                        <th className="py-4 px-6 text-right">STATUS</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-900 text-xs">
                      {filteredUsers.map((user) => {
                        const associatedApp = apps.find(a => a.id === user.app_id);
                        const isEditing = editingUserId === user.id;

                        return (
                          <tr key={user.id} className="hover:bg-zinc-900/30 transition-colors">
                            <td className="py-4 px-6 font-bold text-white select-all">
                              {user.email}
                            </td>
                            <td className="py-4 px-6 text-zinc-400">
                              {associatedApp ? associatedApp.name : 'Unknown Application'}
                            </td>
                            <td className="py-4 px-6">
                              {isEditing ? (
                                <div className="flex items-center gap-2">
                                  <input
                                    type="text"
                                    value={editingPassword}
                                    onChange={(e) => setEditingPassword(e.target.value)}
                                    className="bg-black border border-zinc-800 rounded px-2 py-1 text-xs text-green-400 font-bold focus:outline-none focus:border-green-500 w-32"
                                  />
                                  <button
                                    onClick={() => handleUpdatePassword(user.id)}
                                    className="px-2 py-1 bg-green-950 hover:bg-green-900 text-green-400 border border-green-500/30 rounded text-[10px] font-bold"
                                  >
                                    SAVE
                                  </button>
                                  <button
                                    onClick={() => setEditingUserId(null)}
                                    className="px-2 py-1 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 rounded text-[10px]"
                                  >
                                    CANCEL
                                  </button>
                                </div>
                              ) : (
                                <div className="flex items-center gap-2">
                                  <code className="bg-black border border-zinc-900 px-2 py-1 rounded text-[11px] text-green-500 select-all">
                                    {user.password_hash}
                                  </code>
                                  <button
                                    onClick={() => {
                                      setEditingUserId(user.id);
                                      setEditingPassword(user.password_hash);
                                    }}
                                    className="p-1 text-zinc-600 hover:text-green-400 rounded transition-colors"
                                    title="Edit Password"
                                  >
                                    <Edit className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              )}
                            </td>
                            <td className="py-4 px-6 text-zinc-500">
                              {new Date(user.created_at).toLocaleString()}
                            </td>
                            <td className="py-4 px-6 text-right">
                              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-green-950/60 border border-green-500/20 text-green-400 rounded text-[10px] font-bold">
                                <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-ping" />
                                VERIFIED & ACTIVE
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* SdkHub Tab */}
          {activeTab === 'sdk' && <SdkHub apps={apps} />}

          {/* ClientSimulator Tab */}
          {activeTab === 'simulator' && <ClientSimulator apps={apps} />}

          {/* Logs Tab */}
          {activeTab === 'logs' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-xl font-bold text-white tracking-wide">SECURITY AUDIT LOGS</h2>
                  <p className="text-xs text-zinc-500">Real-time tracking of signups, logins, and API calls</p>
                </div>
                <button 
                  onClick={fetchLogs} 
                  className="p-2 hover:bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-400 hover:text-green-400 transition-all"
                  title="Refresh Logs"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>

              {loadingLogs ? (
                <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-12 text-center text-zinc-500 animate-pulse">
                  FETCHING FIREWALL LOGS...
                </div>
              ) : logs.length === 0 ? (
                <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-12 text-center text-zinc-600">
                  NO SECURITY LOGS RECORDED YET.
                </div>
              ) : (
                <div className="bg-zinc-950 border border-zinc-900 rounded-xl overflow-hidden">
                  <div className="bg-black/60 p-4 border-b border-zinc-900 flex justify-between items-center text-xs">
                    <span className="text-zinc-500 font-bold uppercase tracking-widest">REALTIME SECURITY MONITOR</span>
                    <span className="text-green-500 font-bold">LIVE FEED</span>
                  </div>
                  <div className="p-4 max-h-[600px] overflow-y-auto font-mono text-[11px] space-y-3 scrollbar-none">
                    {logs.map((log) => {
                      const isSuccess = log.status === 'SUCCESS';
                      const isFailure = log.status === 'FAILURE' || log.status === 'FAILED';
                      const isSystem = log.event_type.startsWith('SYSTEM_') || log.event_type === 'APP_CREATED';
                      
                      let color = 'text-green-400';
                      if (isFailure) color = 'text-red-400';
                      else if (isSystem) color = 'text-cyan-400';

                      return (
                        <div key={log.id} className="bg-black/40 border border-zinc-900/50 p-3 rounded hover:border-zinc-800 transition-all">
                          <div className="flex flex-col sm:flex-row justify-between gap-1 mb-1.5">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-zinc-600">[{new Date(log.created_at).toLocaleTimeString()}]</span>
                              <span className={`font-bold px-1.5 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-[10px] ${color}`}>
                                {log.event_type}
                              </span>
                              <span className="text-zinc-500">IP: {log.ip_address}</span>
                            </div>
                            <span className={`text-[10px] font-bold uppercase ${isSuccess ? 'text-green-500' : 'text-red-500'}`}>
                              {log.status}
                            </span>
                          </div>
                          <p className="text-zinc-300 leading-relaxed font-sans">{log.details}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

      </main>
    </div>
  );
}
