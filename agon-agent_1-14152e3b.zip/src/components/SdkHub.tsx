import React, { useState } from 'react';
import { 
  Code, 
  Terminal, 
  Copy, 
  CheckCircle2, 
  Sparkles, 
  HelpCircle,
  ExternalLink,
  Database,
  ShieldCheck
} from 'lucide-react';

interface AppItem {
  id: string;
  name: string;
  url: string;
  custom_domain: string;
  api_key: string;
  created_at: string;
}

interface SdkHubProps {
  apps: AppItem[];
}

export default function SdkHub({ apps }: SdkHubProps) {
  const [selectedApp, setSelectedApp] = useState<AppItem | null>(apps[0] || null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  React.useEffect(() => {
    if (apps.length > 0 && !selectedApp) {
      setSelectedApp(apps[0]);
    }
  }, [apps]);

  const activeApp = selectedApp || {
    id: 'YOUR_APP_ID',
    name: 'Nikku Portfolio',
    custom_domain: 'nikku.com',
    api_key: 'nk_live_xxxxxxxxxxxxxxxxxxxxxxxx',
  };

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const hostUrl = typeof window !== 'undefined' ? window.location.host : 'nikku-auth.vercel.app';
  const protocol = typeof window !== 'undefined' ? window.location.protocol : 'https:';

  const integrationCode = {
    getInfoCheck: `// 1. Real-time check if Virtual Email exists (Perfect for keypress / blur / click events)
async function checkVirtualEmailExists(email) {
  try {
    const response = await fetch('${protocol}//${hostUrl}/api/get-info?api_key=${activeApp.api_key}&email=' + encodeURIComponent(email));
    const result = await response.json();
    
    if (result.exists) {
      console.log('Account exists. Proceeding with standard login check.');
      return true;
    } else {
      console.log('Account does not exist. Prompting user to redirect to Nikku Portal for verification.');
      return false;
    }
  } catch (error) {
    console.error('API Error checking email:', error);
    return false;
  }
}`,

    htmlRedirect: `<!-- 2. Direct HTML Form Submission with Auto-Redirect (No JS Required!) -->
<form action="${protocol}//${hostUrl}/api/auth-gateway" method="POST">
  <!-- Secure API Credentials -->
  <input type="hidden" name="api_key" value="${activeApp.api_key}" />
  <input type="hidden" name="redirect" value="true" />
  
  <!-- URL to send user back to on successful login -->
  <input type="hidden" name="redirect_back" value="https://your-client-app.com/dashboard" />

  <div class="form-group">
    <label>Virtual Email Address (@${activeApp.custom_domain})</label>
    <input type="email" name="email" required placeholder="name@${activeApp.custom_domain}" />
  </div>

  <div class="form-group">
    <label>Password Key</label>
    <input type="password" name="password" required />
  </div>

  <button type="submit">Sign In / Register</button>
</form>`,

    javascript: `// 3. AJAX Fetch Method with Manual Redirect
async function handleLogin(email, password) {
  try {
    const response = await fetch('${protocol}//${hostUrl}/api/auth-gateway', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': '${activeApp.api_key}'
      },
      body: JSON.stringify({ email, password })
    });

    const result = await response.json();

    if (response.ok && result.status === 'LOGIN_SUCCESS') {
      // Login OK -> Set session & redirect to dashboard
      console.log('Login successful!', result.user);
      localStorage.setItem('user_session', JSON.stringify(result.user));
      window.location.href = '/dashboard';
    } else if (response.status === 404 && result.status === 'USER_NOT_FOUND') {
      // Virtual email does not exist yet -> Redirect to Nikku Portal for Verification / Signup
      alert(result.message);
      
      // Calculate Verification Redirect URL
      const redirectUrl = \`\${window.location.protocol}//\${window.location.host}\${result.redirect_url}&redirect_back=\${encodeURIComponent(window.location.href)}\`;
      
      window.location.href = redirectUrl;
    } else {
      alert(result.error || 'Authentication failed');
    }
  } catch (error) {
    console.error('Network security error:', error);
  }
}`,

    nodejs: `// 4. Node.js Express Backend Integration
const express = require('express');
const axios = require('axios');
const app = express();

app.use(express.json());

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const response = await axios.post('${protocol}//${hostUrl}/api/auth-gateway', {
      email,
      password
    }, {
      headers: {
        'x-api-key': '${activeApp.api_key}'
      }
    });

    return res.status(200).json(response.data);
  } catch (error) {
    if (error.response) {
      return res.status(error.response.status).json(error.response.data);
    }
    return res.status(500).json({ error: 'Internal server gateway error' });
  }
});`
  };

  const aiPrompt = `Act as an expert Fullstack Developer. I want you to integrate the "Nikku Secure Auth SSO Gateway" into my website login page.
My custom email domain is: @${activeApp.custom_domain}
My API Key is: ${activeApp.api_key}
My App ID is: ${activeApp.id}
My Server Host is: ${hostUrl}

Please write the complete login page code (Frontend + API calls) with the following rules:

1. EMAIL VALIDATION:
   - When the user types or unfocuses the email input, verify that it ends with "@${activeApp.custom_domain}". If not, show an error: "Only @${activeApp.custom_domain} virtual domains are allowed."

2. REAL-TIME ACCOUNT CHECK (get-info API):
   - Make an API call to: "${protocol}//${hostUrl}/api/get-info?api_key=${activeApp.api_key}&email=\${encodeURIComponent(email)}"
   - If the account DOES NOT exist ({ exists: false }), show a dynamic helper badge: "✨ New virtual email! Registration will trigger on submit."
   - If the account DOES exist ({ exists: true }), show: "🔒 Secure virtual account found. Enter password."

3. FORM SUBMISSION (auth-gateway API):
   - Send a POST request to: "${protocol}//${hostUrl}/api/auth-gateway" with header 'x-api-key': '${activeApp.api_key}' and body JSON: { email, password }.
   - If response status is 200 (LOGIN_SUCCESS), save the session and log the user in.
   - If response status is 404 (USER_NOT_FOUND), redirect the user immediately to the secure Nikku Verification Portal using the 'redirect_url' returned in the JSON:
     Redirect URL: "${protocol}//${hostUrl}" + result.redirect_url + "&redirect_back=" + encodeURIComponent(window.location.href)
   - On the portal, they will complete verification, and then be redirected back to our site automatically.
   
4. ULTRA SECURITY:
   - No database queries must be executed on the client side. All data must be fetched through the secure server APIs to prevent code scrapers or extensions from stealing credentials.`;

  return (
    <div className="space-y-8">
      {/* Selector */}
      <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-6 flex flex-col sm:flex-row justify-between items-center gap-4">
        <div>
          <h3 className="text-sm font-bold text-white tracking-widest uppercase mb-1">SELECT APPLICATION CONFIGURATION</h3>
          <p className="text-xs text-zinc-500">Choose an app to populate its specific API Key and Custom Domain in the templates</p>
        </div>

        <select
          value={selectedApp?.id || ''}
          onChange={(e) => {
            const app = apps.find(a => a.id === e.target.value);
            if (app) setSelectedApp(app);
          }}
          className="bg-black border border-zinc-800 rounded px-4 py-2 text-xs text-green-400 font-bold focus:outline-none focus:border-green-500"
        >
          {apps.map(app => (
            <option key={app.id} value={app.id}>{app.name} (@{app.custom_domain})</option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left column: SDK Templates */}
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-base font-bold text-white tracking-wide uppercase flex items-center gap-2">
              <Code className="w-5 h-5 text-green-400" />
              POWERFUL BACKEND INTEGRATIONS
            </h3>
          </div>

          {/* Real-time get-info check */}
          <div className="bg-zinc-950 border border-zinc-900 rounded-xl overflow-hidden">
            <div className="bg-black/60 px-4 py-3 border-b border-zinc-900 flex justify-between items-center">
              <span className="text-xs font-bold text-green-400 flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5 text-green-500" />
                REAL-TIME EMAIL CHECK (GET_INFO API)
              </span>
              <button
                onClick={() => handleCopy(integrationCode.getInfoCheck, 0)}
                className="text-[10px] bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white px-2.5 py-1 rounded flex items-center gap-1 border border-zinc-800"
              >
                {copiedIndex === 0 ? <CheckCircle2 className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedIndex === 0 ? 'COPIED' : 'COPY'}
              </button>
            </div>
            <pre className="p-4 text-[10px] text-zinc-400 overflow-x-auto max-h-[350px] font-mono leading-relaxed bg-black/30">
              <code>{integrationCode.getInfoCheck}</code>
            </pre>
          </div>

          {/* Direct HTML Form Redirect */}
          <div className="bg-zinc-950 border border-zinc-900 rounded-xl overflow-hidden">
            <div className="bg-black/60 px-4 py-3 border-b border-zinc-900 flex justify-between items-center">
              <span className="text-xs font-bold text-yellow-500 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-yellow-500" />
                DIRECT HTML FORM REDIRECT (NO JAVASCRIPT)
              </span>
              <button
                onClick={() => handleCopy(integrationCode.htmlRedirect, 1)}
                className="text-[10px] bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white px-2.5 py-1 rounded flex items-center gap-1 border border-zinc-800"
              >
                {copiedIndex === 1 ? <CheckCircle2 className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedIndex === 1 ? 'COPIED' : 'COPY'}
              </button>
            </div>
            <pre className="p-4 text-[10px] text-zinc-400 overflow-x-auto max-h-[350px] font-mono leading-relaxed bg-black/30">
              <code>{integrationCode.htmlRedirect}</code>
            </pre>
          </div>

          {/* Javascript Template */}
          <div className="bg-zinc-950 border border-zinc-900 rounded-xl overflow-hidden">
            <div className="bg-black/60 px-4 py-3 border-b border-zinc-900 flex justify-between items-center">
              <span className="text-xs font-bold text-cyan-400">AJAX FETCH METHOD (FRONTEND)</span>
              <button
                onClick={() => handleCopy(integrationCode.javascript, 2)}
                className="text-[10px] bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white px-2.5 py-1 rounded flex items-center gap-1 border border-zinc-800"
              >
                {copiedIndex === 2 ? <CheckCircle2 className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedIndex === 2 ? 'COPIED' : 'COPY'}
              </button>
            </div>
            <pre className="p-4 text-[10px] text-zinc-400 overflow-x-auto max-h-[350px] font-mono leading-relaxed bg-black/30">
              <code>{integrationCode.javascript}</code>
            </pre>
          </div>

          {/* Node.js Template */}
          <div className="bg-zinc-950 border border-zinc-900 rounded-xl overflow-hidden">
            <div className="bg-black/60 px-4 py-3 border-b border-zinc-900 flex justify-between items-center">
              <span className="text-xs font-bold text-blue-400">NODE.JS EXPRESS CONTROLLER</span>
              <button
                onClick={() => handleCopy(integrationCode.nodejs, 3)}
                className="text-[10px] bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white px-2.5 py-1 rounded flex items-center gap-1 border border-zinc-800"
              >
                {copiedIndex === 3 ? <CheckCircle2 className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedIndex === 3 ? 'COPIED' : 'COPY'}
              </button>
            </div>
            <pre className="p-4 text-[10px] text-zinc-400 overflow-x-auto max-h-[350px] font-mono leading-relaxed bg-black/30">
              <code>{integrationCode.nodejs}</code>
            </pre>
          </div>
        </div>

        {/* Right column: AI Prompt Hub & System Flow */}
        <div className="space-y-6">
          <h3 className="text-base font-bold text-white tracking-wide uppercase flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-yellow-400 animate-pulse" />
            UPDATED POWER-USER AI PROMPT
          </h3>

          <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-6 relative">
            <div className="absolute top-4 right-4">
              <span className="bg-yellow-950/40 text-yellow-400 text-[9px] font-bold px-2 py-0.5 rounded-full border border-yellow-500/20">
                AI OPTIMIZED
              </span>
            </div>

            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-2">
              How to use AI to integrate your login page:
            </h4>
            <p className="text-xs text-zinc-500 mb-6 leading-relaxed">
              This updated system prompt instructs AI to utilize the real-time <code className="text-green-400">get-info</code> lookup API and handle the direct SSO Redirection. Copy and paste this directly into your AI workspace (Cursor, GPT-4o, Claude).
            </p>

            <div className="relative">
              <textarea
                readOnly
                value={aiPrompt}
                className="w-full h-96 bg-black border border-zinc-900 rounded-lg p-4 text-[11px] text-zinc-400 font-mono leading-relaxed focus:outline-none"
              />
              <button
                onClick={() => handleCopy(aiPrompt, 4)}
                className="absolute bottom-4 right-4 px-4 py-2 bg-yellow-950 hover:bg-yellow-900 text-yellow-400 border border-yellow-500/30 hover:border-yellow-400 rounded text-[10px] font-bold tracking-widest transition-all"
              >
                {copiedIndex === 4 ? 'COPIED UPDATED PROMPT!' : 'COPY AI PROMPT'}
              </button>
            </div>
          </div>

          {/* Security Architecture Flow */}
          <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-6 space-y-4">
            <h4 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-green-400" />
              REAL-TIME SECURITY ASSURANCE
            </h4>

            <div className="space-y-4 text-xs text-zinc-400 leading-relaxed font-sans">
              <p>
                <strong>No Local Database Code:</strong> Scraper scripts and browser extensions look for database connection strings, local SQL queries, or client-side keys. By routing everything through our secure API gateways, client-side code only contains standard HTTPS fetch calls, keeping your database completely hidden and ultra-secure.
              </p>
              <p>
                <strong>Automatic 302 Redirect:</strong> With our new Direct HTML Redirect method, you do not even need JavaScript. Form submissions can post directly to the Nikku Gateway, which handles the redirection automatically!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
