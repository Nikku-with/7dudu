import React, { useState, useEffect } from 'react';
import { Lock, ShieldAlert, KeyRound, Eye, EyeOff, ShieldCheck } from 'lucide-react';

interface LockScreenProps {
  onUnlock: (passcode: string) => void;
}

export default function LockScreen({ onUnlock }: LockScreenProps) {
  const [passcode, setPasscode] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [isChecking, setIsChecking] = useState(false);
  const [matrixText, setMatrixText] = useState('');

  // Cyberpunk hacking aesthetic text decoration
  useEffect(() => {
    const chars = '0123456789ABCDEF@#$%&*+=-';
    const interval = setInterval(() => {
      let str = '';
      for (let i = 0; i < 20; i++) {
        str += chars[Math.floor(Math.random() * chars.length)];
      }
      setMatrixText(str);
    }, 100);
    return () => clearInterval(interval);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!passcode) return;

    setIsChecking(true);
    setError('');

    // Simulate cryptographic validation delay
    setTimeout(() => {
      if (passcode === 'Nikku@099') {
        localStorage.setItem('nikku_passcode', passcode);
        onUnlock(passcode);
      } else {
        setError('ACCESS DENIED: INVALID DECRYPTION KEY');
        setPasscode('');
      }
      setIsChecking(false);
    }, 800);
  };

  const handleKeyPress = (num: string) => {
    setError('');
    setPasscode(prev => prev + num);
  };

  const handleBackspace = () => {
    setPasscode(prev => prev.slice(0, -1));
  };

  return (
    <div className="min-h-screen bg-black text-green-500 font-mono flex flex-col justify-center items-center relative overflow-hidden px-4 select-none">
      {/* Background Matrix Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-zinc-900/40 via-black to-black opacity-90 z-0" />
      <div className="absolute top-4 left-4 text-xs text-zinc-700 pointer-events-none">
        SYS_STATUS: PROTECTED // DECRYPT_LEVEL_5 // ADDR_0x99
      </div>
      <div className="absolute top-4 right-4 text-xs text-green-600 pointer-events-none animate-pulse">
        {matrixText}
      </div>

      <div className="w-full max-w-md bg-zinc-950 border-2 border-green-500/30 rounded-xl p-8 shadow-[0_0_40px_rgba(34,197,94,0.15)] z-10 relative">
        {/* Glow corner decorations */}
        <div className="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-green-500" />
        <div className="absolute -top-1 -right-1 w-4 h-4 border-t-2 border-r-2 border-green-500" />
        <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-2 border-l-2 border-green-500" />
        <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-green-500" />

        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center p-4 bg-green-950/40 border border-green-500/30 rounded-full mb-4 animate-pulse shadow-[0_0_15px_rgba(34,197,94,0.1)]">
            <Lock className="w-8 h-8 text-green-400" />
          </div>
          <h1 className="text-2xl font-bold tracking-widest text-white uppercase">
            Nikku Gatekeeper
          </h1>
          <p className="text-xs text-zinc-400 mt-2 tracking-wider">
            DECRYPTION PASSCODE REQUIRED FOR ACCESS
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <KeyRound className="h-5 w-5 text-green-600" />
            </div>
            <input
              type={showPass ? 'text' : 'password'}
              value={passcode}
              onChange={(e) => {
                setError('');
                setPasscode(e.target.value);
              }}
              placeholder="ENTER PASSCODE..."
              className="w-full bg-black border-2 border-green-500/30 rounded-lg py-3 pl-10 pr-12 text-center text-xl tracking-widest text-green-400 focus:outline-none focus:border-green-400 transition-colors placeholder:text-zinc-700 font-bold"
              disabled={isChecking}
              autoFocus
            />
            <button
              type="button"
              onClick={() => setShowPass(!showPass)}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-green-600 hover:text-green-400"
            >
              {showPass ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
          </div>

          {error && (
            <div className="bg-red-950/30 border border-red-500/40 rounded-lg p-3 flex items-center gap-3 text-red-400 text-xs animate-bounce">
              <ShieldAlert className="w-5 h-5 shrink-0" />
              <span className="font-bold">{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={isChecking || !passcode}
            className={`w-full py-3 rounded-lg font-bold tracking-widest transition-all text-sm border-2 ${
              isChecking
                ? 'bg-zinc-900 border-zinc-700 text-zinc-500 cursor-not-allowed'
                : 'bg-green-950 hover:bg-green-900 text-green-400 border-green-500/40 hover:border-green-400 hover:shadow-[0_0_20px_rgba(34,197,94,0.3)]'
            }`}
          >
            {isChecking ? 'AUTHENTICATING...' : 'INITIALIZE SYSTEM'}
          </button>
        </form>

        {/* Cyberpunk Numeric Keypad for convenience */}
        <div className="grid grid-cols-3 gap-2 mt-6 border-t border-zinc-900 pt-6">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map((char, idx) => {
            let action = () => handleKeyPress(char);
            let style = "bg-zinc-900/50 text-zinc-300 hover:bg-zinc-900 hover:text-green-400 border border-zinc-800/60";
            
            if (char === 'C') {
              action = () => setPasscode('');
              style = "bg-red-950/20 text-red-400 hover:bg-red-950/40 border border-red-900/40";
            } else if (char === '⌫') {
              action = handleBackspace;
              style = "bg-zinc-900/50 text-zinc-400 hover:bg-zinc-900 hover:text-green-400 border border-zinc-800/60";
            }

            return (
              <button
                key={idx}
                type="button"
                onClick={action}
                className={`py-2 text-sm font-bold rounded transition-colors ${style}`}
              >
                {char}
              </button>
            );
          })}
        </div>

        <div className="mt-6 text-center">
          <span className="text-[10px] text-zinc-600 uppercase tracking-widest block">
            IP Audited & Verified By Nikku Firewall 🛡️
          </span>
        </div>
      </div>
    </div>
  );
}
