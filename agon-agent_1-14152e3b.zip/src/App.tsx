import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import LockScreen from './components/LockScreen';
import AdminDashboard from './components/AdminDashboard';
import VerifyPortal from './pages/VerifyPortal';

function App() {
  const [passcode, setPasscode] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [apps, setApps] = useState<any[]>([]);

  // Check if passcode is saved in localStorage
  useEffect(() => {
    const savedPass = localStorage.getItem('nikku_passcode');
    if (savedPass === 'Nikku@099') {
      setPasscode(savedPass);
    }
  }, []);

  // Fetch apps periodically
  useEffect(() => {
    if (passcode === 'Nikku@099') {
      const fetchApps = async () => {
        try {
          const res = await fetch(`/api/apps?passcode=${encodeURIComponent(passcode)}`);
          if (res.ok) {
            const data = await res.json();
            setApps(data);
          }
        } catch (err) {
          console.error('Error fetching apps:', err);
        }
      };

      fetchApps();
      const interval = setInterval(fetchApps, 15000);
      return () => clearInterval(interval);
    }
  }, [passcode]);

  const handleUnlock = (enteredPass: string) => {
    setPasscode(enteredPass);
  };

  const handleLogout = () => {
    localStorage.removeItem('nikku_passcode');
    setPasscode(null);
  };

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={
          !passcode ? (
            <LockScreen onUnlock={handleUnlock} />
          ) : (
            <div className="bg-zinc-950 min-h-screen text-zinc-100 font-mono">
              {/* Pass activeTab and apps directly so it renders inside the exact same layout container */}
              <AdminDashboard 
                passcode={passcode} 
                onLogout={handleLogout} 
                activeTab={activeTab} 
                setActiveTab={setActiveTab} 
                apps={apps}
                setApps={setApps}
              />
            </div>
          )
        } />
        <Route path="/verify-portal" element={<VerifyPortal />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
