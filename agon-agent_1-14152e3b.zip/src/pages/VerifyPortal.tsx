import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { 
  ShieldCheck, 
  Cpu, 
  Mail, 
  KeyRound, 
  ArrowRight, 
  CheckCircle, 
  ShieldAlert, 
  Lock,
  ExternalLink,
  ChevronRight
} from 'lucide-react';

export default function VerifyPortal() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const appId = searchParams.get('app_id') || '';
  const initialEmail = searchParams.get('email') || '';
  const initialPassword = searchParams.get('req_pass') || '';
  const redirectBack = searchParams.get('redirect_back') || '';

  // App details
  const [appDetails, setAppDetails] = useState<any>(null);
  const [loadingApp, setLoadingApp] = useState(true);

  // Form states
  const [email, setEmail] = useState(initialEmail);
  const [password, setPassword] = useState(initialPassword);
  const [step, setStep] = useState<1 | 2>(1); // Step 1: Confirm Details, Step 2: Verification Complete
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [inputCode, setInputCode] = useState('');
  const [codeSent, setCodeSent] = useState(false);

  useEffect(() => {
    if (!appId) {
      setError('Invalid redirect. Missing "app_id" parameters.');
      setLoadingApp(false);
      return;
    }

    // Fetch App Suffix details (publicly accessible info)
    const fetchAppDetails = async () => {
      try {
        const res = await fetch(`/api/app-info?app_id=${appId}`);
        const data = await res.json();
        if (res.ok) {
          setAppDetails(data);
        } else {
          setError(data.error || 'The target client application could not be verified in Nikku Registry.');
        }
      } catch (err) {
        console.error('Error fetching details:', err);
        setError('Failed to load application details from the secure server.');
      } finally {
        setLoadingApp(false);
      }
    };

    fetchAppDetails();
  }, [appId]);

  // Generate a random 6-digit verification code to simulate "verification and documentary"
  const sendVerificationCode = () => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setVerificationCode(code);
    setCodeSent(true);
    setError('');
    alert(`[SIMULATED SECURE SMTP] Verification OTP sent to Nikku gateway: ${code}`);
  };

  const handleVerifyAndRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    if (!codeSent) {
      setError('Please request a secure verification passcode first.');
      return;
    }

    if (inputCode !== verificationCode) {
      setError('Security Code mismatch. Verification failed.');
      return;
    }

    setIsVerifying(true);
    setError('');

    try {
      const res = await fetch('/api/verify-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          app_id: appId,
          email,
          password
        })
      });

      const data = await res.json();

      if (res.ok) {
        setStep(2);
      } else {
        setError(data.error || 'Failed to complete secure registration.');
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred during verification.');
    } finally {
      setIsVerifying(false);
    }
  };

  const handleReturnToClient = () => {
    if (redirectBack) {
      window.location.href = redirectBack;
    } else {
      // Fallback to dashboard simulator
      navigate('/');
    }
  };

  if (loadingApp) {
    return (
      <div className="min-h-screen bg-black text-green-500 font-mono flex flex-col justify-center items-center px-4">
        <Cpu className="w-12 h-12 text-green-400 animate-spin mb-4" />
        <p className="text-sm tracking-widest uppercase">ESTABLISHING SECURE CONNECTION TO NIKKU SERVER...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-zinc-100 font-mono flex flex-col justify-center items-center px-4 relative select-none">
      {/* Background aesthetics */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-zinc-900/40 via-black to-black opacity-95 z-0" />
      
      <div className="w-full max-w-xl bg-zinc-950 border-2 border-green-500/20 rounded-xl p-8 shadow-[0_0_50px_rgba(34,197,94,0.1)] z-10 relative">
        {/* Glow corners */}
        <div className="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-green-500" />
        <div className="absolute -top-1 -right-1 w-4 h-4 border-t-2 border-r-2 border-green-500" />
        <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-2 border-l-2 border-green-500" />
        <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-green-500" />

        {/* Header */}
        <div className="text-center mb-8 border-b border-zinc-900 pb-6">
          <div className="inline-flex items-center justify-center p-3 bg-green-950/30 border border-green-500/20 rounded-full mb-3">
            <ShieldCheck className="w-8 h-8 text-green-400" />
          </div>
          <h1 className="text-xl font-bold tracking-widest text-white uppercase">
            NIKKU CENTRAL AUTH PORTAL
          </h1>
          <p className="text-xs text-zinc-500 mt-1 uppercase tracking-wider">
            SECURE VIRTUAL DOMAIN REGISTRATION & VERIFICATION SERVICE
          </p>
        </div>

        {error && (
          <div className="bg-red-950/20 border border-red-900/40 rounded-lg p-4 text-xs text-red-400 mb-6 flex gap-3 font-bold">
            <ShieldAlert className="w-5 h-5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {step === 1 ? (
          <div className="space-y-6">
            <div className="bg-green-950/10 border border-green-500/20 rounded-lg p-4 space-y-2">
              <div className="text-xs text-green-400 font-bold uppercase tracking-wider">
                Target Client Application Verified
              </div>
              <div className="text-sm text-white font-bold flex items-center gap-2">
                {appDetails?.name || 'Unknown Application'}
                <span className="text-xs bg-zinc-900 border border-zinc-800 text-green-400 px-2 py-0.5 rounded">
                  @{appDetails?.custom_domain}
                </span>
              </div>
              <p className="text-[11px] text-zinc-500 leading-relaxed">
                You were redirected here because you requested to sign up with a custom virtual email Ending with <strong className="text-green-500">@{appDetails?.custom_domain}</strong> on our partner site. Complete verification below to create this email permanently.
              </p>
            </div>

            <form onSubmit={handleVerifyAndRegister} className="space-y-4">
              <div>
                <label className="block text-[10px] text-zinc-400 uppercase tracking-wider mb-1.5 font-bold">
                  Virtual Email Address
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-600">
                    <Mail className="w-4 h-4" />
                  </span>
                  <input
                    type="email"
                    readOnly
                    value={email}
                    className="w-full bg-black border border-zinc-900 rounded pl-10 pr-3 py-2 text-xs text-green-400 font-bold focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-zinc-400 uppercase tracking-wider mb-1.5 font-bold">
                  Secure Password Key
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-600">
                    <Lock className="w-4 h-4" />
                  </span>
                  <input
                    type="password"
                    readOnly
                    value={password}
                    className="w-full bg-black border border-zinc-900 rounded pl-10 pr-3 py-2 text-xs text-green-400 font-bold focus:outline-none tracking-widest"
                  />
                </div>
              </div>

              <div className="border-t border-zinc-900 pt-4 mt-4">
                <label className="block text-[10px] text-zinc-400 uppercase tracking-wider mb-1.5 font-bold">
                  Virtual SMTP Gateway Verification
                </label>
                
                <div className="flex gap-3">
                  <input
                    type="text"
                    placeholder="ENTER 6-DIGIT CODE..."
                    value={inputCode}
                    onChange={(e) => setInputCode(e.target.value)}
                    maxLength={6}
                    className="bg-black border border-zinc-800 rounded px-3 py-2 text-xs text-green-400 focus:outline-none focus:border-green-500 font-bold tracking-widest w-full text-center"
                    disabled={!codeSent}
                  />
                  <button
                    type="button"
                    onClick={sendVerificationCode}
                    className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-green-400 border border-zinc-800 rounded text-[10px] font-bold tracking-wider shrink-0 transition-all uppercase"
                  >
                    {codeSent ? 'RESEND CODE' : 'REQUEST OTP'}
                  </button>
                </div>
                <p className="text-[10px] text-zinc-600 mt-2">
                  Click 'Request OTP' to simulate secure verification bypass check.
                </p>
              </div>

              <button
                type="submit"
                disabled={isVerifying || !inputCode}
                className={`w-full py-3 rounded font-bold tracking-widest transition-all text-xs border uppercase mt-6 ${
                  isVerifying
                    ? 'bg-zinc-900 border-zinc-800 text-zinc-500 cursor-not-allowed'
                    : 'bg-green-950 hover:bg-green-900 text-green-400 border-green-500/30 hover:border-green-400 shadow-[0_0_15px_rgba(34,197,94,0.1)]'
                }`}
              >
                {isVerifying ? 'VERIFYING SECURITY CREDENTIALS...' : 'CONFIRM & REGISTER EMAIL'}
              </button>
            </form>
          </div>
        ) : (
          <div className="text-center space-y-6 py-6">
            <div className="inline-flex items-center justify-center p-4 bg-green-950/40 border-2 border-green-500 rounded-full animate-bounce">
              <CheckCircle className="w-10 h-10 text-green-400" />
            </div>

            <div className="space-y-2">
              <h2 className="text-lg font-bold text-white uppercase tracking-wider">
                Virtual Email Verified Successfully!
              </h2>
              <p className="text-xs text-zinc-400 leading-relaxed max-w-sm mx-auto">
                Your secure virtual account <strong className="text-green-400">{email}</strong> has been created in the Nikku Main SSO Database. You can now use it to sign in to <strong className="text-white">{appDetails?.name}</strong>.
              </p>
            </div>

            <div className="bg-black/50 border border-zinc-900 p-4 rounded-lg max-w-md mx-auto text-left space-y-2 font-mono text-[10px] text-zinc-500">
              <div className="flex justify-between">
                <span>VIRTUAL ACCOUNT ID:</span>
                <span className="text-white font-bold">NK_USR_{Math.random().toString(36).substring(2, 10).toUpperCase()}</span>
              </div>
              <div className="flex justify-between">
                <span>ASSOCIATED CLIENT:</span>
                <span className="text-white">{appDetails?.name}</span>
              </div>
              <div className="flex justify-between">
                <span>SECURITY ENCRYPTION:</span>
                <span className="text-green-500">SHA-256 SYSTEM LOCK</span>
              </div>
            </div>

            <button
              onClick={handleReturnToClient}
              className="px-6 py-3 bg-green-950 hover:bg-green-900 text-green-400 border border-green-500/30 hover:border-green-400 rounded text-xs font-bold tracking-widest transition-all inline-flex items-center gap-2 uppercase"
            >
              CONTINUE TO WEBSITE <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}

        <div className="mt-8 text-center border-t border-zinc-900 pt-6">
          <span className="text-[9px] text-zinc-600 uppercase tracking-widest block">
            🔒 Nikku Shield SSO Protocol v1.2 // AES-256 Cryptographic Lock
          </span>
        </div>
      </div>
    </div>
  );
}
