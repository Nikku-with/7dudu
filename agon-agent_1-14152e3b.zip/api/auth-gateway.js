import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-api-key');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const apiKey = req.headers['x-api-key'] || req.query.api_key || (req.body && req.body.api_key);
  const email = req.body?.email || req.query.email;
  const password = req.body?.password || req.query.password;

  // If visited directly in browser without API Key, show a beautiful, interactive API Gateway Page
  const acceptsHtml = req.headers.accept && req.headers.accept.includes('text/html');
  if (acceptsHtml && !apiKey) {
    res.setHeader('Content-Type', 'text/html');
    return res.status(200).send(`
      <!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Nikku Secure SSO Auth Gateway</title>
          <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
          <style>
            body {
              background-color: #030712;
              color: #10b981;
              font-family: 'Courier New', Courier, monospace;
            }
            .glow {
              box-shadow: 0 0 25px rgba(16, 185, 129, 0.2);
            }
          </style>
        </head>
        <body class="min-h-screen flex flex-col justify-center items-center p-6">
          <div class="max-w-lg w-full bg-gray-950 border-2 border-green-500/30 rounded-2xl p-8 glow relative">
            <!-- Corners -->
            <div class="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-green-500"></div>
            <div class="absolute -top-1 -right-1 w-4 h-4 border-t-2 border-r-2 border-green-500"></div>
            <div class="absolute -bottom-1 -left-1 w-4 h-4 border-b-2 border-l-2 border-green-500"></div>
            <div class="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-green-500"></div>

            <div class="text-center mb-6">
              <div class="inline-flex items-center justify-center p-3 bg-green-950/40 border border-green-500/30 rounded-full mb-3 animate-pulse">
                <svg class="w-8 h-8 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                </svg>
              </div>
              <h1 class="text-2xl font-bold tracking-widest text-white">NIKKU SECURE GATEWAY</h1>
              <p class="text-xs text-gray-400 mt-1 uppercase tracking-wider">SSO AUTH GATEWAY // ONLINE & PROTECTED</p>
            </div>

            <div class="bg-black/50 border border-gray-900 rounded-lg p-5 space-y-3 text-xs text-gray-400 mb-6">
              <div class="flex justify-between border-b border-gray-900 pb-2">
                <span class="text-green-500 font-bold">API STATUS:</span>
                <span class="text-white font-bold">ACTIVE (200 OK)</span>
              </div>
              <div class="flex justify-between border-b border-gray-900 pb-2">
                <span class="text-green-500 font-bold">ENDPOINT:</span>
                <span class="text-white">/api/auth-gateway</span>
              </div>
              <div class="flex justify-between border-b border-gray-900 pb-2">
                <span class="text-green-500 font-bold">SECURITY:</span>
                <span class="text-white">AES-GCM-256 ENCRYPTED</span>
              </div>
              <div class="flex justify-between">
                <span class="text-green-500 font-bold">YOUR IP:</span>
                <span class="text-white">${req.headers['x-forwarded-for'] || '127.0.0.1'}</span>
              </div>
            </div>

            <div class="text-center">
              <p class="text-xs text-gray-500 mb-4">This API handles secure single sign-on (SSO) and virtual email registration redirection. It requires a valid <code class="bg-gray-900 text-green-400 px-1.5 py-0.5 rounded">api_key</code>.</p>
              <a href="/" class="inline-block px-6 py-2 bg-green-950 hover:bg-green-900 text-green-400 border border-green-500/30 hover:border-green-400 rounded-lg text-xs font-bold tracking-wider transition-all uppercase">
                Go to Admin Dashboard
              </a>
            </div>
          </div>
        </body>
      </html>
    `);
  }

  if (!apiKey) {
    return res.status(401).json({ error: 'Unauthorized. x-api-key header, body parameter, or query parameter is missing.' });
  }

  // Validate API Key and fetch App
  const { data: appData, error: appError } = await supabase
    .from('nikku_apps')
    .select('*')
    .eq('api_key', apiKey)
    .single();

  if (appError || !appData) {
    return res.status(401).json({ error: 'Unauthorized. Invalid API Key.' });
  }

  const redirectBack = req.body?.redirect_back || req.query.redirect_back || appData.url || '';
  const forceRedirect = req.body?.force_redirect === 'true' || req.query.force_redirect === 'true' || req.body?.force_redirect === true;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  // Enforce that email domain matches the app's custom domain
  const emailParts = email.split('@');
  if (emailParts.length < 2) {
    return res.status(400).json({ error: 'Invalid email format.' });
  }
  const emailDomain = emailParts[1];
  if (emailDomain !== appData.custom_domain) {
    return res.status(400).json({
      error: `Invalid email domain. This app only accepts emails ending with @${appData.custom_domain}`
    });
  }

  try {
    // 1. Check if the user already exists
    const { data: existingUser, error: findError } = await supabase
      .from('nikku_users')
      .select('*')
      .eq('app_id', appData.id)
      .eq('email', email)
      .single();

    if (existingUser) {
      // User exists -> Attempt Login
      if (existingUser.password_hash === password) {
        // Log the successful login
        await supabase.from('nikku_logs').insert({
          app_id: appData.id,
          event_type: 'USER_LOGIN',
          status: 'SUCCESS',
          details: `User ${email} logged in successfully.`,
          ip_address: req.headers['x-forwarded-for'] || 'unknown',
          created_at: new Date().toISOString()
        });

        if (forceRedirect && redirectBack) {
          try {
            const targetUrl = new URL(redirectBack);
            targetUrl.searchParams.set('status', 'success');
            targetUrl.searchParams.set('email', email);
            targetUrl.searchParams.set('userId', existingUser.id);
            res.writeHead(302, { Location: targetUrl.toString() });
            res.end();
            return;
          } catch (urlErr) {
            // Fallback redirect
            res.writeHead(302, { Location: `${redirectBack}?status=success&email=${encodeURIComponent(email)}&userId=${existingUser.id}` });
            res.end();
            return;
          }
        }

        return res.status(200).json({
          status: 'LOGIN_SUCCESS',
          message: 'Login successful',
          user: { id: existingUser.id, email: existingUser.email }
        });
      } else {
        // Log failed login
        await supabase.from('nikku_logs').insert({
          app_id: appData.id,
          event_type: 'USER_LOGIN_FAILED',
          status: 'FAILURE',
          details: `Failed login attempt for ${email} (incorrect password).`,
          ip_address: req.headers['x-forwarded-for'] || 'unknown',
          created_at: new Date().toISOString()
        });

        if (forceRedirect && redirectBack) {
          try {
            const targetUrl = new URL(redirectBack);
            targetUrl.searchParams.set('status', 'error');
            targetUrl.searchParams.set('error', 'Invalid password credentials');
            res.writeHead(302, { Location: targetUrl.toString() });
            res.end();
            return;
          } catch (urlErr) {
            res.writeHead(302, { Location: `${redirectBack}?status=error&error=Invalid%20credentials` });
            res.end();
            return;
          }
        }

        return res.status(401).json({ error: 'Invalid password. Check credentials.' });
      }
    } else {
      // User does NOT exist -> Redirect to verification page
      const host = req.headers.host || 'nikku-auth-sso.vercel.app';
      const protocol = req.headers['x-forwarded-proto'] || 'https';
      
      const portalUrl = `${protocol}://${host}/verify-portal?app_id=${appData.id}&email=${encodeURIComponent(email)}&req_pass=${encodeURIComponent(password)}&redirect_back=${encodeURIComponent(redirectBack)}`;

      await supabase.from('nikku_logs').insert({
        app_id: appData.id,
        event_type: 'REDIRECT_TO_PORTAL',
        status: 'SUCCESS',
        details: `Redirecting unverified virtual account ${email} to Nikku Auth Portal.`,
        ip_address: req.headers['x-forwarded-for'] || 'unknown',
        created_at: new Date().toISOString()
      });

      if (forceRedirect) {
        res.writeHead(302, { Location: portalUrl });
        res.end();
        return;
      }

      return res.status(404).json({
        status: 'USER_NOT_FOUND',
        message: 'Account does not exist. Redirecting to Nikku Main Server Auth Portal for virtual email creation and verification.',
        redirect_url: portalUrl
      });
    }

  } catch (err) {
    console.error('Auth handler error:', err);
    if (forceRedirect && redirectBack) {
      res.writeHead(302, { Location: `${redirectBack}?status=error&error=${encodeURIComponent(err.message)}` });
      res.end();
      return;
    }
    return res.status(500).json({ error: err.message });
  }
}
