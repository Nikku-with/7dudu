import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-passcode');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const passcode = req.headers['x-passcode'] || req.query.passcode;
  if (passcode !== 'Nikku@099') {
    return res.status(401).json({ error: 'Unauthorized. Invalid passcode.' });
  }

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('nikku_settings')
        .select('*')
        .eq('id', 'global')
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { shield_level, rate_limiting } = req.body;
      const { data, error } = await supabase
        .from('nikku_settings')
        .update({
          shield_level,
          rate_limiting,
          updated_at: new Date().toISOString()
        })
        .eq('id', 'global')
        .select()
        .single();

      if (error) throw error;

      // Log the security change
      await supabase.from('nikku_logs').insert({
        event_type: 'SECURITY_UPDATE',
        status: 'SUCCESS',
        details: `Security settings updated: Shield Level set to "${shield_level}", Rate Limiting: ${rate_limiting ? 'ENABLED' : 'DISABLED'}.`,
        ip_address: req.headers['x-forwarded-for'] || 'unknown',
        created_at: new Date().toISOString()
      });

      return res.status(200).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Settings API error:', err);
    res.status(500).json({ error: err.message });
  }
}
