import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-passcode');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const passcode = req.headers['x-passcode'] || req.body.passcode;
  if (passcode !== 'Nikku@099') {
    return res.status(401).json({ error: 'Unauthorized. Invalid passcode.' });
  }

  const { app_id, email, password } = req.body;
  if (!app_id || !email || !password) {
    return res.status(400).json({ error: 'app_id, email, and password are required.' });
  }

  try {
    // Verify app exists
    const { data: appData, error: appError } = await supabase
      .from('nikku_apps')
      .select('*')
      .eq('id', app_id)
      .single();

    if (appError || !appData) {
      return res.status(404).json({ error: 'App not found in Nikku Registry.' });
    }

    // Verify email domain suffix matches the app domain
    const emailParts = email.split('@');
    if (emailParts.length < 2) {
      return res.status(400).json({ error: 'Invalid email format.' });
    }
    const emailDomain = emailParts[1];
    if (emailDomain !== appData.custom_domain) {
      return res.status(400).json({ error: `Invalid email domain. For this app, the email must end with @${appData.custom_domain}` });
    }

    // Check if user already exists
    const { data: existingUser } = await supabase
      .from('nikku_users')
      .select('*')
      .eq('app_id', app_id)
      .eq('email', email)
      .single();

    if (existingUser) {
      return res.status(400).json({ error: 'Virtual email account already exists.' });
    }

    // Create the Virtual User
    const userId = crypto.randomUUID();
    const { data: newUser, error: createError } = await supabase
      .from('nikku_users')
      .insert({
        id: userId,
        app_id,
        email,
        password_hash: password,
        created_at: new Date().toISOString()
      })
      .select()
      .single();

    if (createError) throw createError;

    // Log the event
    await supabase.from('nikku_logs').insert({
      app_id,
      event_type: 'USER_CREATED_MANUALLY',
      status: 'SUCCESS',
      details: `Virtual User ${email} was manually created by Admin from Dashboard.`,
      ip_address: req.headers['x-forwarded-for'] || 'unknown',
      created_at: new Date().toISOString()
    });

    return res.status(201).json({
      success: true,
      message: 'Virtual email created successfully by Admin!',
      user: newUser
    });

  } catch (err) {
    console.error('Create user error:', err);
    return res.status(500).json({ error: err.message });
  }
}
