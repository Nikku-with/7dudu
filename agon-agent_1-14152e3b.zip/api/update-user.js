import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-passcode');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const passcode = req.headers['x-passcode'] || req.query.passcode;
  if (passcode !== 'Nikku@099') {
    return res.status(401).json({ error: 'Unauthorized. Invalid passcode.' });
  }

  const { id, password_hash } = req.body;
  if (!id || !password_hash) {
    return res.status(400).json({ error: 'User ID and password_hash are required.' });
  }

  try {
    const { data, error } = await supabase
      .from('nikku_users')
      .update({ password_hash })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log the update
    await supabase.from('nikku_logs').insert({
      app_id: data.app_id,
      event_type: 'USER_PASSWORD_UPDATED',
      status: 'SUCCESS',
      details: `Password updated for virtual user "${data.email}" via Admin Dashboard.`,
      ip_address: req.headers['x-forwarded-for'] || 'unknown',
      created_at: new Date().toISOString()
    });

    return res.status(200).json(data);
  } catch (err) {
    console.error('Update user error:', err);
    return res.status(500).json({ error: err.message });
  }
}
