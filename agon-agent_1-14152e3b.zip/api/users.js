import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-passcode, x-api-key');
  if (req.method === 'OPTIONS') return res.status(204).end();

  // For Admin UI, we check passcode. For third-party apps, we check x-api-key.
  const passcode = req.headers['x-passcode'] || req.query.passcode;
  const apiKey = req.headers['x-api-key'] || req.query.api_key;

  let isAdmin = passcode === 'Nikku@099';
  let authorizedApp = null;

  if (!isAdmin && apiKey) {
    const { data: appData, error: appError } = await supabase
      .from('nikku_apps')
      .select('*')
      .eq('api_key', apiKey)
      .single();
    if (!appError && appData) {
      authorizedApp = appData;
    }
  }

  if (!isAdmin && !authorizedApp) {
    return res.status(401).json({ error: 'Unauthorized. Invalid API Key or Passcode.' });
  }

  try {
    if (req.method === 'GET') {
      // Admin dashboard wants all users, optionally filtered by app_id
      const { app_id } = req.query;
      let query = supabase.from('nikku_users').select('*').order('created_at', { ascending: false });
      if (app_id) {
        query = query.eq('app_id', app_id);
      } else if (!isAdmin && authorizedApp) {
        query = query.eq('app_id', authorizedApp.id);
      }

      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
