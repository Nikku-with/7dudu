import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-passcode');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const passcode = req.headers['x-passcode'] || req.query.passcode;
  if (passcode !== 'Nikku@099') {
    return res.status(401).json({ error: 'Unauthorized. Invalid passcode.' });
  }

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('nikku_apps')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { name, url, custom_domain } = req.body;
      if (!name || !custom_domain) {
        return res.status(400).json({ error: 'App Name and Custom Domain are required.' });
      }

      // Generate a secure API Key
      const apiKey = 'nk_live_' + [...Array(24)].map(() => Math.floor(Math.random() * 16).toString(16)).join('');
      const id = crypto.randomUUID();

      const { data, error } = await supabase
        .from('nikku_apps')
        .insert({
          id,
          name,
          url: url || '',
          custom_domain,
          api_key: apiKey,
          created_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) throw error;

      // Log the creation
      await supabase.from('nikku_logs').insert({
        app_id: id,
        event_type: 'APP_CREATED',
        status: 'SUCCESS',
        details: `App "${name}" registered with custom domain "${custom_domain}".`,
        ip_address: req.headers['x-forwarded-for'] || 'unknown',
        created_at: new Date().toISOString()
      });

      return res.status(201).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'App ID is required.' });

      const { error } = await supabase
        .from('nikku_apps')
        .delete()
        .eq('id', id);

      if (error) throw error;

      return res.status(200).json({ success: true, message: 'App deleted.' });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
