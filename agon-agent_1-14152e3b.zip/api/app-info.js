import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const { app_id } = req.query;
  if (!app_id) {
    return res.status(400).json({ error: 'app_id parameter is required.' });
  }

  try {
    const { data: appData, error } = await supabase
      .from('nikku_apps')
      .select('id, name, custom_domain, url, created_at')
      .eq('id', app_id)
      .single();

    if (error || !appData) {
      return res.status(404).json({ error: 'Application not found in Nikku Registry.' });
    }

    return res.status(200).json(appData);
  } catch (err) {
    console.error('App info API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
