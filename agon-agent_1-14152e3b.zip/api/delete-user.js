import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-passcode');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const passcode = req.headers['x-passcode'] || req.query.passcode;
  if (passcode !== 'Nikku@099') {
    return res.status(401).json({ error: 'Unauthorized. Invalid passcode.' });
  }

  const { id } = req.body;
  if (!id) {
    return res.status(400).json({ error: 'User ID is required.' });
  }

  try {
    const { data: userData, error: fetchError } = await supabase
      .from('nikku_users')
      .select('*')
      .eq('id', id)
      .single();

    if (fetchError) throw fetchError;

    const { error } = await supabase
      .from('nikku_users')
      .delete()
      .eq('id', id);

    if (error) throw error;

    // Log the deletion
    await supabase.from('nikku_logs').insert({
      app_id: userData.app_id,
      event_type: 'USER_DELETED',
      status: 'SUCCESS',
      details: `Virtual user "${userData.email}" permanently deleted via Admin Dashboard.`,
      ip_address: req.headers['x-forwarded-for'] || 'unknown',
      created_at: new Date().toISOString()
    });

    return res.status(200).json({ success: true, message: 'User deleted.' });
  } catch (err) {
    console.error('Delete user error:', err);
    return res.status(500).json({ error: err.message });
  }
}
