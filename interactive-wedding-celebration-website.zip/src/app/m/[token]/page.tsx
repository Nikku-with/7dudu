import ShareView from "@/components/ShareView";

export const dynamic = "force-dynamic";

export default async function MemorySharePage({
  params,
}: {
  params: Promise<{ token: string }>;
}) {
  const { token } = await params;
  return <ShareView token={token} />;
}
