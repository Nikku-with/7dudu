import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { NextResponse } from "next/server";
import { readSession } from "@/lib/session";

export const dynamic = "force-dynamic";

function isAllowedType(type: string) {
  return (
    type.startsWith("image/") ||
    type.startsWith("video/") ||
    type.startsWith("audio/")
  );
}

export async function POST(request: Request) {
  const { unlocked, identity } = await readSession();
  if (!unlocked || !identity) {
    return NextResponse.json({ ok: false }, { status: 401 });
  }

  const form = await request.formData();
  const file = form.get("file");
  if (!(file instanceof File)) {
    return NextResponse.json({ ok: false, error: "No file" }, { status: 400 });
  }
  if (file.size > 40 * 1024 * 1024) {
    return NextResponse.json({ ok: false, error: "File too large" }, { status: 400 });
  }

  const type = file.type || "application/octet-stream";
  if (!isAllowedType(type)) {
    return NextResponse.json({ ok: false, error: "Type not allowed" }, { status: 400 });
  }

  const extFromName = file.name.split(".").pop()?.toLowerCase();
  const mimeExt = (type.split("/")[1] || "bin").split(";")[0];
  const ext =
    extFromName && /^[a-z0-9]+$/.test(extFromName) ? extFromName : mimeExt;

  const dir = path.join(process.cwd(), "public", "uploads");
  await mkdir(dir, { recursive: true });
  const filename = `${crypto.randomUUID()}.${ext}`;
  const buf = Buffer.from(await file.arrayBuffer());
  await writeFile(path.join(dir, filename), buf);

  return NextResponse.json({ ok: true, path: `/uploads/${filename}` });
}
