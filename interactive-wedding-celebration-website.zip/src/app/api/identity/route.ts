import { NextResponse } from "next/server";
import { COOKIE_OPTS, readSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const { unlocked } = await readSession();
  if (!unlocked) {
    return NextResponse.json({ ok: false }, { status: 401 });
  }
  const body = (await request.json()) as { identity?: string };
  if (body.identity !== "nik" && body.identity !== "rumi") {
    return NextResponse.json({ ok: false }, { status: 400 });
  }
  const res = NextResponse.json({ ok: true, identity: body.identity });
  res.cookies.set("nr_identity", body.identity, COOKIE_OPTS);
  return res;
}
