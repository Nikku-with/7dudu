import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { memories, memoryTabs, pings } from "@/db/schema";
import { buildState, ensureCeremony } from "@/lib/ceremony-server";
import { readSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const { unlocked, identity } = await readSession();
  if (!unlocked || !identity) {
    return NextResponse.json({ ok: false }, { status: 401 });
  }
  await ensureCeremony();

  const body = (await request.json()) as {
    action?: string;
    name?: string;
    tabId?: number;
    type?: string;
    title?: string;
    content?: string;
    mediaPath?: string | null;
    locked?: boolean;
    lockPassword?: string;
  };

  if (body.action === "tab") {
    const name = (body.name ?? "").trim();
    if (!name) {
      return NextResponse.json({ ok: false, error: "Name required" }, { status: 400 });
    }
    await db.insert(memoryTabs).values({
      name,
      createdBy: identity,
      shareToken: crypto.randomUUID(),
    });
  } else if (body.action === "memory") {
    const tabId = body.tabId;
    const type = body.type ?? "note";
    if (!tabId) {
      return NextResponse.json({ ok: false, error: "Tab required" }, { status: 400 });
    }
    await db.insert(memories).values({
      tabId,
      author: identity,
      type,
      title: body.title?.trim() || null,
      content: body.content?.trim() || null,
      mediaPath: body.mediaPath ?? null,
      locked: Boolean(body.locked),
      lockPassword: body.locked ? body.lockPassword || null : null,
      shareToken: crypto.randomUUID(),
    });
  } else if (body.action === "ping") {
    await db.insert(pings).values({
      fromWho: identity,
      message: body.content?.trim() || "thinking of you",
    });
  } else if (body.action === "seenPings") {
    const unseen = await db.select().from(pings);
    for (const p of unseen) {
      if (!p.seen && p.fromWho !== identity) {
        await db.update(pings).set({ seen: true }).where(eq(pings.id, p.id));
      }
    }
  } else {
    return NextResponse.json({ ok: false }, { status: 400 });
  }

  const state = await buildState(unlocked, identity);
  return NextResponse.json({ ok: true, state });
}
