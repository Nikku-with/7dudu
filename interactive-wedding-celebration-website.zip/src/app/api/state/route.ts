import { buildState, ensureCeremony } from "@/lib/ceremony-server";
import { readSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureCeremony();
    const { unlocked, identity } = await readSession();
    const state = await buildState(unlocked, identity);
    return Response.json(state);
  } catch (error) {
    console.error(error);
    return Response.json({ ok: false, error: "state failed" }, { status: 500 });
  }
}
