import { eq } from "drizzle-orm";
import { db } from "@/db";
import { memories } from "@/db/schema";
import { readSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ token: string }> },
) {
  const { token } = await params;
  const { unlocked, identity } = await readSession();
  const url = new URL(request.url);
  const password = url.searchParams.get("password") ?? "";

  const rows = await db.select().from(memories).where(eq(memories.shareToken, token));
  const memory = rows[0];
  if (!memory) {
    return Response.json({ ok: false, error: "Not found" }, { status: 404 });
  }

  const partnerInside = unlocked && (identity === "nik" || identity === "rumi");
  if (memory.locked && !partnerInside) {
    if (!password || password !== (memory.lockPassword ?? "")) {
      return Response.json({ ok: true, locked: true, needsPassword: true });
    }
  }

  return Response.json({
    ok: true,
    locked: false,
    memory: {
      id: memory.id,
      author: memory.author,
      type: memory.type,
      title: memory.title,
      content: memory.content,
      mediaPath: memory.mediaPath,
      createdAt: memory.createdAt.toISOString(),
    },
  });
}
