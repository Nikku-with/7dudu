import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { ceremony, vowResponses } from "@/db/schema";
import { VOWS } from "@/lib/content";
import {
  buildState,
  ensureCeremony,
  syncCeremonyPhase,
} from "@/lib/ceremony-server";
import { readSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const { unlocked, identity } = await readSession();
  if (!unlocked || !identity) {
    return NextResponse.json({ ok: false }, { status: 401 });
  }

  const body = (await request.json()) as {
    action?: string;
    token?: string;
    vowKey?: string;
    accepted?: boolean;
  };

  const row = await ensureCeremony();

  if (body.action === "accept") {
    const token = body.token ?? "";
    if (token === row.nikInviteToken && identity === "rumi") {
      await db
        .update(ceremony)
        .set({ nikAccepted: true, updatedAt: new Date() })
        .where(eq(ceremony.id, row.id));
    } else if (token === row.rumiInviteToken && identity === "nik") {
      await db
        .update(ceremony)
        .set({ rumiAccepted: true, updatedAt: new Date() })
        .where(eq(ceremony.id, row.id));
    } else {
      return NextResponse.json(
        { ok: false, error: "This link is for your partner." },
        { status: 400 },
      );
    }
  } else if (body.action === "vow") {
    const vow = VOWS.find((v) => v.key === body.vowKey);
    if (!vow) {
      return NextResponse.json({ ok: false }, { status: 400 });
    }
    if (vow.author === identity) {
      return NextResponse.json(
        { ok: false, error: "Partner answers your vachan." },
        { status: 400 },
      );
    }
    if (body.accepted !== true) {
      return NextResponse.json({
        ok: false,
        error: "Soch lo phir se… haa bolna hai 💗",
      });
    }
    const existing = await db
      .select()
      .from(vowResponses)
      .where(eq(vowResponses.vowKey, vow.key));
    if (existing[0]) {
      await db
        .update(vowResponses)
        .set({ accepted: true, responder: identity })
        .where(eq(vowResponses.id, existing[0].id));
    } else {
      await db.insert(vowResponses).values({
        vowKey: vow.key,
        responder: identity,
        accepted: true,
      });
    }
  } else if (body.action === "ring") {
    if (identity === "nik") {
      await db
        .update(ceremony)
        .set({ nikRingDone: true, updatedAt: new Date() })
        .where(eq(ceremony.id, row.id));
    } else {
      await db
        .update(ceremony)
        .set({ rumiRingDone: true, updatedAt: new Date() })
        .where(eq(ceremony.id, row.id));
    }
  } else {
    return NextResponse.json({ ok: false }, { status: 400 });
  }

  await syncCeremonyPhase();
  const state = await buildState(unlocked, identity);
  return NextResponse.json({ ok: true, state });
}
