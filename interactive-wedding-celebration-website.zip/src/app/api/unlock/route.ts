import { NextResponse } from "next/server";
import { isUnlockDate } from "@/lib/content";
import { COOKIE_OPTS } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json()) as { date?: string };
  const date = body.date ?? "";
  if (!isUnlockDate(date)) {
    return NextResponse.json({ ok: false, error: "wrong-date" }, { status: 401 });
  }
  const res = NextResponse.json({ ok: true, unlocked: true });
  res.cookies.set("nr_unlocked", "1", COOKIE_OPTS);
  return res;
}
