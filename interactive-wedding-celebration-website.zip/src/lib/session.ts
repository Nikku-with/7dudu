import { cookies } from "next/headers";
import type { Identity } from "@/lib/content";

export async function readSession() {
  const jar = await cookies();
  const unlockedCookie = jar.get("nr_unlocked")?.value;
  const unlocked = unlockedCookie === "1" || unlockedCookie === "true";
  const raw = jar.get("nr_identity")?.value;
  const identity: Identity | null = raw === "nik" || raw === "rumi" ? raw : null;
  return { unlocked, identity };
}

export const COOKIE_OPTS = {
  path: "/",
  maxAge: 60 * 60 * 24 * 365,
  sameSite: "lax" as const,
};
