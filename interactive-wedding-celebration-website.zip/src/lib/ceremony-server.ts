import { db } from "@/db";
import {
  ceremony,
  memories,
  memoryTabs,
  pings,
  vowResponses,
} from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { VOWS } from "@/lib/content";
import type { Identity } from "@/lib/content";

export async function ensureCeremony() {
  const existing = await db.select().from(ceremony).limit(1);
  let row = existing[0];
  if (!row) {
    const inserted = await db
      .insert(ceremony)
      .values({
        nikInviteToken: crypto.randomUUID(),
        rumiInviteToken: crypto.randomUUID(),
      })
      .returning();
    row = inserted[0];
  }
  if (!row) {
    throw new Error("Could not create ceremony");
  }

  const tabs = await db.select().from(memoryTabs).limit(1);
  if (!tabs[0]) {
    await db.insert(memoryTabs).values({
      name: "Shaadi Night · 13 Sep 2026",
      createdBy: "nik",
      shareToken: crypto.randomUUID(),
    });
  }

  return row;
}

export async function syncCeremonyPhase() {
  const row = await ensureCeremony();
  if (row.phase === "complete") return row;

  const responses = await db.select().from(vowResponses);
  const accepted = new Set(
    responses.filter((r) => r.accepted).map((r) => r.vowKey),
  );
  const allVowsYes = VOWS.every((v) => accepted.has(v.key));

  let phase = row.phase;
  let completedAt = row.completedAt;

  if (row.nikAccepted && row.rumiAccepted && phase === "invite") {
    phase = "vows";
  }
  if (
    allVowsYes &&
    row.nikAccepted &&
    row.rumiAccepted &&
    (phase === "vows" || phase === "invite")
  ) {
    phase = "ring";
  }
  if (
    row.nikRingDone &&
    row.rumiRingDone &&
    (phase === "ring" || phase === "vows")
  ) {
    phase = "complete";
    completedAt = completedAt ?? new Date();
  }

  if (phase !== row.phase || completedAt !== row.completedAt) {
    await db
      .update(ceremony)
      .set({ phase, completedAt, updatedAt: new Date() })
      .where(eq(ceremony.id, row.id));
    return { ...row, phase, completedAt };
  }

  return row;
}

export async function buildState(unlocked: boolean, identity: Identity | null) {
  const row = await syncCeremonyPhase();
  const responses = await db.select().from(vowResponses);
  const tabs = await db.select().from(memoryTabs).orderBy(memoryTabs.id);
  const mems = await db.select().from(memories).orderBy(desc(memories.id));
  const pingRows = await db.select().from(pings).orderBy(desc(pings.id)).limit(30);

  const vowMap: Record<string, boolean> = {};
  for (const r of responses) {
    vowMap[r.vowKey] = r.accepted;
  }

  return {
    unlocked,
    identity,
    ceremony: {
      phase: row.phase,
      nikAccepted: row.nikAccepted,
      rumiAccepted: row.rumiAccepted,
      nikInviteToken: row.nikInviteToken,
      rumiInviteToken: row.rumiInviteToken,
      nikRingDone: row.nikRingDone,
      rumiRingDone: row.rumiRingDone,
      completedAt: row.completedAt ? row.completedAt.toISOString() : null,
    },
    vowResponses: vowMap,
    tabs: tabs.map((t) => ({
      id: t.id,
      name: t.name,
      createdBy: t.createdBy,
      shareToken: t.shareToken,
      createdAt: t.createdAt.toISOString(),
    })),
    memories: mems.map((m) => ({
      id: m.id,
      tabId: m.tabId,
      author: m.author,
      type: m.type,
      title: m.title,
      content: m.content,
      mediaPath: m.mediaPath,
      locked: m.locked,
      shareToken: m.shareToken,
      createdAt: m.createdAt.toISOString(),
    })),
    pings: pingRows.map((p) => ({
      id: p.id,
      fromWho: p.fromWho,
      message: p.message,
      seen: p.seen,
      createdAt: p.createdAt.toISOString(),
    })),
  };
}
