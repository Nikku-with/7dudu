import type { Identity } from "@/lib/content";

export type CeremonyPhase = "invite" | "vows" | "ring" | "complete";

export type CeremonyState = {
  phase: CeremonyPhase;
  nikAccepted: boolean;
  rumiAccepted: boolean;
  nikInviteToken: string;
  rumiInviteToken: string;
  nikRingDone: boolean;
  rumiRingDone: boolean;
  completedAt: string | null;
};

export type MemoryTab = {
  id: number;
  name: string;
  createdBy: string;
  shareToken: string;
  createdAt: string;
};

export type MemoryItem = {
  id: number;
  tabId: number;
  author: string;
  type: string;
  title: string | null;
  content: string | null;
  mediaPath: string | null;
  locked: boolean;
  shareToken: string;
  createdAt: string;
};

export type PingItem = {
  id: number;
  fromWho: string;
  message: string | null;
  seen: boolean;
  createdAt: string;
};

export type AppState = {
  unlocked: boolean;
  identity: Identity | null;
  ceremony: CeremonyState;
  vowResponses: Record<string, boolean>;
  tabs: MemoryTab[];
  memories: MemoryItem[];
  pings: PingItem[];
};
