import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const ceremony = pgTable("ceremony", {
  id: serial("id").primaryKey(),
  nikAccepted: boolean("nik_accepted").notNull().default(false),
  rumiAccepted: boolean("rumi_accepted").notNull().default(false),
  nikInviteToken: text("nik_invite_token").notNull(),
  rumiInviteToken: text("rumi_invite_token").notNull(),
  phase: text("phase").notNull().default("invite"),
  nikRingDone: boolean("nik_ring_done").notNull().default(false),
  rumiRingDone: boolean("rumi_ring_done").notNull().default(false),
  completedAt: timestamp("completed_at"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const vowResponses = pgTable("vow_responses", {
  id: serial("id").primaryKey(),
  vowKey: text("vow_key").notNull(),
  responder: text("responder").notNull(),
  accepted: boolean("accepted").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const memoryTabs = pgTable("memory_tabs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  createdBy: text("created_by").notNull(),
  shareToken: text("share_token").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const memories = pgTable("memories", {
  id: serial("id").primaryKey(),
  tabId: integer("tab_id").notNull(),
  author: text("author").notNull(),
  type: text("type").notNull(),
  title: text("title"),
  content: text("content"),
  mediaPath: text("media_path"),
  locked: boolean("locked").notNull().default(false),
  lockPassword: text("lock_password"),
  shareToken: text("share_token").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const pings = pgTable("pings", {
  id: serial("id").primaryKey(),
  fromWho: text("from_who").notNull(),
  message: text("message"),
  seen: boolean("seen").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
