"use client";

import { useEffect, useRef, useState } from "react";
import { CHATS, VOWS, displayName, partnerOf, type Identity } from "@/lib/content";
import type { AppState } from "@/lib/types";
import Petals from "@/components/Petals";

function ConfettiCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);
    const colors = ["#e0b84c", "#c43b5a", "#fff6ea", "#9a1d36", "#f6dd8a", "#ffffff"];
    const bits = Array.from({ length: 150 }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * -canvas.height,
      r: 4 + Math.random() * 6,
      c: colors[Math.floor(Math.random() * colors.length)] ?? "#e0b84c",
      s: 2 + Math.random() * 4,
    }));
    let raf = 0;
    const tick = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (const b of bits) {
        b.y += b.s;
        b.x += Math.sin(b.y / 28) * 1.3;
        if (b.y > canvas.height) b.y = -12;
        ctx.fillStyle = b.c;
        ctx.save();
        ctx.translate(b.x, b.y);
        ctx.rotate(b.y / 18);
        ctx.fillRect(-b.r / 2, -b.r / 2, b.r, b.r * 0.55);
        ctx.restore();
      }
      raf = requestAnimationFrame(tick);
    };
    tick();
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);
  return <canvas ref={ref} className="pointer-events-none fixed inset-0 z-40" />;
}

export default function Rituals({
  state,
  inviteToken,
  onAct,
  onCelebrationDone,
}: {
  state: AppState;
  inviteToken: string | null;
  onAct: (body: Record<string, unknown>) => Promise<string | null>;
  onCelebrationDone: () => void;
}) {
  const identity = state.identity as Identity;
  const c = state.ceremony;
  const [copied, setCopied] = useState(false);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [visibleChats, setVisibleChats] = useState(0);
  const [gifStep, setGifStep] = useState<"none" | "one" | "two" | "done">("none");
  const [placed, setPlaced] = useState(false);
  const dragging = useRef(false);
  const [ringPos, setRingPos] = useState({ x: 48, y: 72 });
  const fingerRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLButtonElement>(null);

  const myLink =
    typeof window === "undefined"
      ? ""
      : identity === "nik"
        ? `${window.location.origin}/invite/${c.nikInviteToken}`
        : `${window.location.origin}/invite/${c.rumiInviteToken}`;

  const isNikLink = inviteToken === c.nikInviteToken;
  const isRumiLink = inviteToken === c.rumiInviteToken;
  const iAmAcceptor =
    (Boolean(isNikLink) && identity === "rumi" && !c.nikAccepted) ||
    (Boolean(isRumiLink) && identity === "nik" && !c.rumiAccepted);
  const openedOwnLink =
    (Boolean(isNikLink) && identity === "nik") ||
    (Boolean(isRumiLink) && identity === "rumi");

  const myRingDone = identity === "nik" ? c.nikRingDone : c.rumiRingDone;
  const partnerRingDone = identity === "nik" ? c.rumiRingDone : c.nikRingDone;
  const partner = partnerOf(identity);
  const partnerHandName = displayName(partner);

  const toAnswer = VOWS.filter((v) => v.author !== identity);
  const unanswered = toAnswer.filter((v) => state.vowResponses[v.key] !== true);
  const currentVow = unanswered[0];

  useEffect(() => {
    if (c.phase !== "complete") return;
    if (visibleChats >= CHATS.length) return;
    const t = setTimeout(() => setVisibleChats((n) => n + 1), visibleChats === 0 ? 2200 : 1600);
    return () => clearTimeout(t);
  }, [c.phase, visibleChats]);

  useEffect(() => {
    if (gifStep === "one") {
      const t = setTimeout(() => setGifStep("two"), 4200);
      return () => clearTimeout(t);
    }
    if (gifStep === "two") {
      const t = setTimeout(async () => {
        setGifStep("done");
        await onAct({ action: "ring" });
      }, 4200);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [gifStep, onAct]);

  useEffect(() => {
    function move(e: PointerEvent) {
      if (!dragging.current) return;
      setRingPos({ x: (e.clientX / window.innerWidth) * 100, y: (e.clientY / window.innerHeight) * 100 });
    }
    function up() {
      if (!dragging.current) return;
      dragging.current = false;
      const ring = ringRef.current?.getBoundingClientRect();
      const finger = fingerRef.current?.getBoundingClientRect();
      if (!ring || !finger) return;
      const cx = ring.left + ring.width / 2;
      const cy = ring.top + ring.height / 2;
      const hit =
        cx > finger.left - 12 &&
        cx < finger.right + 12 &&
        cy > finger.top - 12 &&
        cy < finger.bottom + 12;
      if (hit) {
        setPlaced(true);
        setGifStep("one");
      }
    }
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
  }, []);

  async function run(body: Record<string, unknown>) {
    setBusy(true);
    const err = await onAct(body);
    setBusy(false);
    if (err) setMsg(err);
    else setMsg("");
    return err;
  }

  if (c.phase === "complete") {
    return (
      <section className="scene bg-[radial-gradient(circle_at_top,#7a1830,transparent_40%),#14060a] px-4 py-10">
        <ConfettiCanvas />
        <Petals count={26} />
        <div className="relative z-50 mx-auto max-w-3xl text-center">
          <p className="font-corm tracking-[0.5em] text-amber-200/80 uppercase">13 September 2026</p>
          <h1 className="font-script mt-3 text-6xl text-amber-100 sm:text-8xl">Shaadi Complete</h1>
          <p className="font-serif mt-2 text-2xl text-rose-50">Nikhil Mehra ❤ Rashmika Mehra</p>
          <p className="mt-4 text-rose-100/80">Party bomber on. Ab woh raat ke vachan, line by line.</p>
        </div>
        <div className="relative z-50 mx-auto mt-8 max-w-2xl space-y-4 pb-28">
          {CHATS.slice(0, visibleChats).map((chat) => (
            <article
              key={chat.id}
              className={`chat-in rounded-3xl border border-amber-200/20 p-4 ${
                chat.identity === "nik" ? "ml-8 bg-[#3a1a10]/80" : "mr-8 bg-[#4a1020]/80"
              }`}
            >
              <div className="flex items-baseline justify-between gap-3">
                <p className="font-script text-2xl text-amber-200">{chat.sender}</p>
                <p className="text-[11px] tracking-wide text-rose-100/60">{chat.time}</p>
              </div>
              <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-rose-50">{chat.text}</p>
            </article>
          ))}
        </div>
        {visibleChats >= CHATS.length ? (
          <div className="fixed bottom-6 left-0 right-0 z-50 flex justify-center">
            <button type="button" onClick={onCelebrationDone} className="gold-btn rounded-full px-8 py-3">
              Enter Nik & Rumi World
            </button>
          </div>
        ) : null}
      </section>
    );
  }

  if (c.phase === "ring") {
    if (gifStep === "one" || gifStep === "two") {
      return (
        <section className="scene flex items-center justify-center bg-black">
          <img
            src={gifStep === "one" ? "/gifs/ring1.gif" : "/gifs/ring2.gif"}
            alt="Wedding celebration"
            className="max-h-[90vh] max-w-[92vw] rounded-3xl object-contain"
          />
        </section>
      );
    }

    return (
      <section className="scene bg-[linear-gradient(180deg,#1a0508,#4a0d18)] px-4 py-8">
        <Petals count={16} />
        <div className="relative z-10 mx-auto max-w-lg text-center">
          <p className="font-corm tracking-[0.35em] text-amber-200/80 uppercase">Ring ceremony</p>
          <h2 className="font-script mt-2 text-5xl text-amber-50">Pehnao ring</h2>
          <p className="mt-3 text-sm text-rose-100/80">
            {myRingDone
              ? partnerRingDone
                ? "Dono rings lag gayi…"
                : `Ruk jao… ${displayName(partner)} abhi ring pehna rahe hain.`
              : `Ring ko drag karke ${partnerHandName} ke haath ki ungli par chhod do.`}
          </p>
          <div className="mt-4 flex justify-center gap-6 text-xs text-amber-100/80">
            <span>Nikhil {c.nikRingDone ? "💍 done" : "waiting"}</span>
            <span>Rashmika {c.rumiRingDone ? "💍 done" : "waiting"}</span>
          </div>
        </div>

        {!myRingDone ? (
          <div className="relative z-10 mx-auto mt-6 flex h-[62vh] max-w-xl items-end justify-center">
            <div className="relative">
              <svg viewBox="0 0 280 340" className="h-[52vh] w-auto drop-shadow-2xl">
                <path
                  d="M110 330c-30-10-48-70-40-140 4-34 18-70 38-78 8-4 18-2 26 8 6-28 22-58 48-70 18-8 38-4 48 14 8 16 8 38-2 64 22 8 34 28 32 58-4 48-18 110-44 132-20 16-70 22-106 12z"
                  fill="#f3c2b0"
                />
                <path d="M176 70c18 6 28 28 22 54" fill="none" stroke="#e8a090" strokeWidth="6" />
                <ellipse cx="198" cy="128" rx="16" ry="22" fill="#f7d0c2" />
                <ellipse cx="168" cy="122" rx="15" ry="24" fill="#f3c2b0" />
                <ellipse cx="140" cy="128" rx="14" ry="22" fill="#f0b8a8" />
                <ellipse cx="118" cy="150" rx="13" ry="20" fill="#eeae9e" />
              </svg>
              <div
                ref={fingerRef}
                className={`absolute right-[18%] top-[28%] h-14 w-14 rounded-full border-2 ${placed ? "drop-glow border-amber-300" : "border-amber-200/70"}`}
              />
              <div className="absolute left-1/2 top-[58%] -translate-x-1/2 rounded-full bg-[#2a0b12]/80 px-4 py-1 font-script text-2xl text-amber-200">
                {partnerHandName}
              </div>
            </div>
            {!placed ? (
              <button
                ref={ringRef}
                type="button"
                onPointerDown={() => {
                  dragging.current = true;
                }}
                className="absolute z-20 flex h-16 w-16 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full"
                style={{ left: `${ringPos.x}%`, top: `${ringPos.y}%`, touchAction: "none" }}
              >
                <svg viewBox="0 0 64 64" className="h-16 w-16" style={{ animation: "ring-spin 6s linear infinite" }}>
                  <ellipse cx="32" cy="40" rx="18" ry="10" fill="none" stroke="#e0b84c" strokeWidth="6" />
                  <path d="M24 32l8-14 8 14" fill="#f6dd8a" stroke="#b8860b" strokeWidth="1" />
                  <circle cx="32" cy="16" r="5" fill="#cfe9ff" stroke="#e0b84c" />
                </svg>
              </button>
            ) : null}
          </div>
        ) : (
          <div className="relative z-10 mx-auto mt-16 max-w-md text-center text-amber-100">
            <p className="font-script text-4xl">Ring lag gayi</p>
            <p className="mt-3 text-sm opacity-80">Live wait… partner bhi pehnaye.</p>
          </div>
        )}
      </section>
    );
  }

  if (c.phase === "vows") {
    return (
      <section className="scene overflow-y-auto bg-[linear-gradient(180deg,#14060a,#3a0710)] px-4 py-8">
        <Petals count={12} />
        <div className="relative z-10 mx-auto max-w-3xl pb-16">
          <p className="text-center font-corm tracking-[0.4em] text-amber-200/80 uppercase">Vachan ceremony</p>
          <h2 className="font-script mt-2 text-center text-5xl text-amber-50">Ha ya na?</h2>
          <p className="mx-auto mt-3 max-w-lg text-center text-sm text-rose-100/75">
            Partner ke vachan ek-ek karke aayenge. Haa bolo tabhi aage. Live dikhega dono ko.
          </p>
          {msg ? <p className="mt-3 text-center text-rose-200">{msg}</p> : null}

          {currentVow ? (
            <div className="card-3d mt-8 rounded-[28px] bg-[#2b0b12]/90 p-6 text-rose-50">
              <p className="text-xs uppercase tracking-[0.25em] text-amber-200/70">
                {displayName(currentVow.author)} ka vachan
              </p>
              <h3 className="font-serif mt-2 text-2xl text-amber-100">{currentVow.title}</h3>
              <p className="mt-4 whitespace-pre-wrap leading-relaxed">{currentVow.text}</p>
              <div className="mt-6 grid grid-cols-2 gap-3">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => run({ action: "vow", vowKey: currentVow.key, accepted: true })}
                  className="gold-btn rounded-full py-3"
                >
                  Haa, nibhaungi / nibhaunga
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={async () => {
                    setMsg("Soch lo phir se… haa bolna hai 💗");
                  }}
                  className="maroon-btn rounded-full py-3"
                >
                  Na
                </button>
              </div>
            </div>
          ) : (
            <div className="mt-10 rounded-3xl border border-amber-200/20 bg-black/30 p-6 text-center text-amber-100">
              <p className="font-script text-4xl">Aapne saare vachan haa kar diye</p>
              <p className="mt-2 text-sm opacity-75">Partner ke answers ka wait… live update ho raha hai.</p>
            </div>
          )}

          <div className="mt-8 grid gap-3">
            {VOWS.map((v) => {
              const done = state.vowResponses[v.key] === true;
              return (
                <div
                  key={v.key}
                  className="flex items-center justify-between rounded-2xl border border-amber-200/15 bg-black/25 px-4 py-3 text-sm text-rose-50"
                >
                  <span>
                    <b className="text-amber-200">{displayName(v.author)}</b> · {v.title}
                  </span>
                  <span>{done ? "✅ Haa" : "⏳ pending"}</span>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="scene overflow-y-auto bg-[linear-gradient(180deg,#14060a,#4a0d18)] px-4 py-10">
      <Petals count={14} />
      <div className="relative z-10 mx-auto max-w-2xl text-center">
        <p className="font-corm tracking-[0.4em] text-amber-200/80 uppercase">Wedding invite</p>
        <h2 className="font-script mt-2 text-5xl text-amber-50">
          {identity === "nik" ? "Nikhil" : "Rumi"}, apni link bhejo
        </h2>
        <p className="mt-3 text-sm text-rose-100/75">
          Apni wedding link copy karke partner ko do. Unke click par unhe accept ka option milega — live update yahan dikhega.
        </p>

        {iAmAcceptor ? (
          <div className="card-3d mt-8 rounded-[28px] bg-[#2b0b12] p-6">
            <p className="font-serif text-2xl text-amber-100">
              {isNikLink ? "Nikhil Mehra" : "Rashmika Mehra"} ne shaadi ka haath badhaya hai
            </p>
            <p className="mt-2 text-sm text-rose-100/75">Accept karo toh mandap live unlock hoga.</p>
            <button
              type="button"
              disabled={busy}
              onClick={() => run({ action: "accept", token: inviteToken })}
              className="gold-btn mt-5 rounded-full px-8 py-3"
            >
              Accept wedding
            </button>
          </div>
        ) : null}
        {openedOwnLink ? (
          <p className="mt-4 text-sm text-amber-100/80">
            Ye tumhari khud ki link hai — isko partner ko bhejo, yahan accept nahi hota.
          </p>
        ) : null}

        <div className="mt-8 rounded-3xl border border-amber-200/20 bg-black/30 p-5 text-left">
          <p className="text-xs uppercase tracking-[0.25em] text-amber-200/70">Your link</p>
          <p className="mt-2 break-all text-sm text-rose-50">{myLink}</p>
          <button
            type="button"
            className="maroon-btn mt-4 rounded-full px-5 py-2 text-sm"
            onClick={async () => {
              await navigator.clipboard.writeText(myLink);
              setCopied(true);
              setTimeout(() => setCopied(false), 1600);
            }}
          >
            {copied ? "Copied" : "Copy link"}
          </button>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-3">
          <div className="rounded-2xl border border-amber-200/20 bg-black/30 p-4">
            <p className="font-script text-3xl text-amber-200">Nikhil</p>
            <p className="text-sm text-rose-50">{c.nikAccepted ? "Accepted 💗" : "Waiting for Rumi"}</p>
          </div>
          <div className="rounded-2xl border border-amber-200/20 bg-black/30 p-4">
            <p className="font-script text-3xl text-amber-200">Rashmika</p>
            <p className="text-sm text-rose-50">{c.rumiAccepted ? "Accepted 💗" : "Waiting for Nik"}</p>
          </div>
        </div>
        {msg ? <p className="mt-4 text-rose-200">{msg}</p> : null}
      </div>
    </section>
  );
}
