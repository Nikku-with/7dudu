# 🍌 Banana Agent — Enhanced AI Edition

A full-stack agentic AI chat built on **Next.js 16 + Vercel AI SDK v6**, with multi-round web search, live reasoning-token streaming, and a growing arsenal of 100 tools — all running on **100% free models**.

---

## ✨ What's New in This Build

| Before | After |
|---|---|
| Raw `fetch` to OpenAI-compat endpoints | **Vercel AI SDK `streamText`/`generateText`/`generateObject`** |
| Manual JSON streaming + regex parsing | **AI SDK `fullStream` with typed `text-delta` + `reasoning-delta` parts** |
| `<thinking>` tag prompt hack | **Native reasoning tokens** for DeepSeek R1, GLM-4.5-Air, GPT-OSS, Gemma 4 + tag-splitter fallback for others |
| Hardcoded 5 model IDs | **Rich model catalog** with 🧠 THINKING badges, context size, good-for tags |
| React Context with `useRef` stale-closure hacks | **Zustand v5 store** — persist middleware auto-saves settings, `get()` solves staleness |
| Fixed Groq/OpenRouter fetch URLs | **`@ai-sdk/groq` + `@openrouter/ai-sdk-provider`** typed providers |
| Simple search analysis | **`generateObject` + Zod schema** — fully typed structured planning |
| No thinking UI for native reasoning | **Live collapsible 🧠 reasoning panel** in `ThinkingCard` |

---

## 🧠 Reasoning Models (Native Thinking Tokens)

These free models stream real chain-of-thought tokens visible live in the UI:

| Model | Provider | Notes |
|---|---|---|
| `deepseek/deepseek-r1-0528:free` | OpenRouter | Flagship reasoning — 164K ctx |
| `z-ai/glm-4.5-air:free` | OpenRouter | Hybrid think/non-think mode |
| `openai/gpt-oss-120b:free` | OpenRouter | MoE, configurable effort |
| `nvidia/nemotron-3-super-120b:free` | OpenRouter | 1M context |
| `google/gemma-4-31b-it:free` | OpenRouter | Configurable thinking |
| `qwen/qwen3-32b` | Groq | Fast LPU reasoning |

For models without native reasoning, the app falls back to `<thinking>` tag parsing via `ThinkingTagSplitter`.

---

## 🚀 Quick Start

```bash
# 1. Install
npm install

# 2. Set up env
cp .env.example .env.local
# Add DATABASE_URL and optionally GROQ_API_KEY / OPENROUTER_API_KEY

# 3. Run DB migrations
npx drizzle-kit push

# 4. Dev server
npm run dev
```

Then open http://localhost:3000 and add your API key in ⚙️ Settings.

---

## 📦 Tech Stack

```
Next.js 16 (App Router)       — framework
Vercel AI SDK v6              — streamText · generateText · generateObject
@openrouter/ai-sdk-provider   — OpenRouter (300+ free & paid models)
@ai-sdk/groq                  — Groq LPU (ultra-fast)
Zustand v5 + persist          — state management
Zod v4                        — runtime schema validation for structured AI output
Drizzle ORM + PostgreSQL      — persistent sessions, messages, files, memory
Tailwind CSS v4               — styling
Wandbox API                   — free code execution sandbox (JS · TS · Python · Go · Rust…)
```

---

## 🔑 API Keys (both free)

| Provider | Link | Notes |
|---|---|---|
| Groq | https://console.groq.com/keys | Free tier, no CC needed |
| OpenRouter | https://openrouter.ai/keys | All `:free` models cost $0 |

Keys stay in your browser (localStorage) — never sent to any server other than the provider you chose.

---

## 📁 Key Files Changed

```
src/lib/free-models.ts         ← new: curated free model catalog with metadata
src/lib/ai-providers.ts        ← new: Vercel AI SDK provider wiring + reasoning opts
src/lib/prompt.ts              ← updated: ThinkingTagSplitter, native-reasoning-aware prompts
src/store/agent-store.ts       ← new: Zustand v5 store (replaces React Context)
src/app/api/agent/route.ts     ← rewritten: AI SDK streamText + fullStream reasoning
src/app/api/analyze/route.ts   ← rewritten: generateObject + Zod structured planning
src/app/api/execute/route.ts   ← updated: AI SDK generateText for auto-fix
src/app/api/models/route.ts    ← new: /api/models?provider=openrouter&live=1
src/components/thinking-card.tsx  ← updated: live native reasoning panel
src/components/panels.tsx      ← updated: rich model picker + thinking-effort selector
```
