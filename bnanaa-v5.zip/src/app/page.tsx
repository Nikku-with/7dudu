"use client";

import { useState, Suspense, lazy } from "react";
import { useAgent } from "@/store/agent-store";
import Sidebar from "@/components/sidebar";
import ChatPanel from "@/components/chat-panel";
import { ToolsPanel, FilesPanel, SettingsModal } from "@/components/panels";

// Monaco is heavy — lazy load it
const MonacoPanel = lazy(() => import("@/components/monaco-panel"));

function Shell() {
  const { activeTab, monacoOpen, setMonacoOpen, monacoJumpFile } = useAgent();
  const [navOpen, setNavOpen] = useState(false);

  return (
    <div className="h-dvh flex bg-zinc-950 text-zinc-100 overflow-hidden">
      {/* Sidebar */}
      <aside className="hidden md:block w-72 shrink-0">
        <Sidebar />
      </aside>

      {/* Mobile nav drawer */}
      {navOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setNavOpen(false)}
          />
          <div className="absolute left-0 top-0 bottom-0 w-72 animate-slide-in">
            <Sidebar onNavigate={() => setNavOpen(false)} />
          </div>
        </div>
      )}

      {/* Main content */}
      <main className="flex-1 flex flex-col min-w-0 min-h-0">
        {/* Mobile top bar */}
        <div className="md:hidden flex items-center gap-2 px-3 py-2 border-b border-zinc-800/80 bg-zinc-950/95 shrink-0">
          <button
            onClick={() => setNavOpen(true)}
            className="w-9 h-9 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-300"
          >
            ☰
          </button>
          <span className="font-black text-[14px] truncate">
            🍌 BANANA <span className="text-yellow-400">AGENT</span>
          </span>
          {monacoOpen && (
            <button
              onClick={() => setMonacoOpen(false)}
              className="ml-auto px-2 py-1 rounded-lg bg-zinc-800 text-zinc-400 text-[11px]"
            >
              ✕ IDE
            </button>
          )}
        </div>

        {/* Split view: Chat | Monaco */}
        <div className="flex-1 flex min-h-0 overflow-hidden">
          {/* Left pane — always visible */}
          <div
            className={`flex flex-col min-h-0 transition-all duration-300 ${
              monacoOpen ? "w-[45%] shrink-0 border-r border-zinc-800" : "flex-1"
            }`}
          >
            <div className="flex-1 min-h-0 overflow-hidden">
              {activeTab === "tools" ? (
                <ToolsPanel />
              ) : activeTab === "files" ? (
                <FilesPanel />
              ) : (
                <ChatPanel />
              )}
            </div>
          </div>

          {/* Right pane — Monaco IDE */}
          {monacoOpen && (
            <div className="flex-1 min-w-0 min-h-0 overflow-hidden">
              <Suspense
                fallback={
                  <div className="flex h-full items-center justify-center text-zinc-500 text-sm bg-[#0d0d10]">
                    <span className="animate-pulse">Loading Monaco IDE…</span>
                  </div>
                }
              >
                <MonacoPanel
                  initialFile={monacoJumpFile}
                  onClose={() => setMonacoOpen(false)}
                />
              </Suspense>
            </div>
          )}
        </div>
      </main>

      <SettingsModal />
    </div>
  );
}

export default function Page() {
  return <Shell />;
}
