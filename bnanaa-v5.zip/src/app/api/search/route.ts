export const dynamic = "force-dynamic";
export const maxDuration = 60;

interface SearchResult {
  title: string;
  url: string;
  snippet: string;
  domain: string;
}

// ── SearXNG public instances ──────────────────────────────────────────────────
// All support ?format=json and don't block Vercel IPs. Tried in order.
const SEARX_INSTANCES = [
  "https://searx.be",
  "https://paulgo.io",
  "https://search.sapti.me",
  "https://searx.tiekoetter.com",
  "https://search.privacyguide.community",
  "https://etsi.me",
];

const UA = "Mozilla/5.0 (compatible; BananaAgent/1.0; +https://banana-agent.app)";

interface SearxResult {
  title?: string;
  url?: string;
  content?: string;
}

async function searxSearch(query: string): Promise<SearchResult[]> {
  const params = new URLSearchParams({
    q: query,
    format: "json",
    categories: "general",
    language: "en",
    time_range: "",
    safesearch: "0",
  });

  for (const instance of SEARX_INSTANCES) {
    try {
      const r = await fetch(`${instance}/search?${params}`, {
        headers: { "User-Agent": UA, Accept: "application/json" },
        signal: AbortSignal.timeout(10_000),
      });
      if (!r.ok) continue;
      const data = await r.json();
      const results: SearchResult[] = (data.results || [])
        .filter(
          (x: SearxResult) =>
            x.url && x.title && !x.url.includes("youtube.com") && !x.url.endsWith(".pdf")
        )
        .slice(0, 15)
        .map((x: SearxResult) => {
          let domain = "";
          try {
            domain = new URL(x.url!).hostname.replace(/^www\./, "");
          } catch {}
          return {
            title: x.title || "",
            url: x.url || "",
            snippet: x.content || "",
            domain,
          };
        });
      if (results.length > 0) return results;
    } catch {
      continue;
    }
  }
  return [];
}

// ── Jina.ai reader ────────────────────────────────────────────────────────────
// Free URL reader — converts any webpage to clean markdown text. No key needed.
// Works perfectly from Vercel (it's a proper API, not web scraping).
async function jinaRead(url: string): Promise<string> {
  try {
    const r = await fetch(`https://r.jina.ai/${url}`, {
      headers: {
        "User-Agent": UA,
        Accept: "text/plain",
        "X-Return-Format": "text",
        "X-No-Cache": "true",
      },
      signal: AbortSignal.timeout(15_000),
    });
    if (!r.ok) return "";
    const text = await r.text();
    // Jina returns clean markdown; trim to 2500 chars per source
    return text.slice(0, 2500).trim();
  } catch {
    return "";
  }
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const queries: string[] = (
    Array.isArray(body.queries) && body.queries.length > 0
      ? body.queries
      : [body.query]
  )
    .filter((q: unknown): q is string => typeof q === "string" && q.trim().length > 0)
    .map((q: string) => q.trim())
    .slice(0, 3);

  if (queries.length === 0)
    return Response.json({ error: "Query required" }, { status: 400 });

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const emit = (obj: unknown) =>
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(obj)}\n\n`));

      try {
        emit({ status: "connecting", detail: "🔍 Connecting to search…" });

        const all: SearchResult[] = [];
        const seen = new Set<string>();

        // ── Round 1: search all queries in parallel ──────────────────────────
        emit({
          status: "querying",
          detail: `🧭 Searching: ${queries.map((q) => `"${q}"`).join(" · ")}`,
        });

        const searchResults = await Promise.all(queries.map((q) => searxSearch(q)));

        for (let qi = 0; qi < queries.length; qi++) {
          const q = queries[qi];
          const page = searchResults[qi];
          emit({ status: "found", detail: `"${q}" → ${page.length} results` });
          for (const res of page) {
            if (seen.has(res.url)) continue;
            seen.add(res.url);
            all.push(res);
            emit({ result: res });
          }
        }

        if (all.length === 0) {
          // All SearXNG instances failed — rare but possible
          emit({ status: "warn", detail: "⚠️ All search instances timed out — using AI knowledge only" });
          emit({ done: true, count: 0, fetched: 0, context: "", sources: [] });
          controller.close();
          return;
        }

        emit({
          status: "found",
          detail: `✅ ${all.length} sources found — reading top pages…`,
        });

        // ── Round 2: Jina.ai crawl top 4 results ────────────────────────────
        const top = all.slice(0, 4);
        const pageTexts: { url: string; domain: string; text: string }[] = [];

        const jinaResults = await Promise.all(
          top.map(async (res) => {
            emit({ status: "fetching", detail: `📖 Reading ${res.domain}…`, fetching: res.domain });
            const text = await jinaRead(res.url);
            return { res, text };
          })
        );

        for (const { res, text } of jinaResults) {
          if (text && text.length > 80) {
            pageTexts.push({ url: res.url, domain: res.domain, text });
            emit({ status: "fetched", detail: `✅ ${res.domain} — ${text.length} chars` });
          } else {
            emit({ status: "fetched", detail: `⚠️ ${res.domain} — skipped (empty)` });
          }
        }

        // ── Build context for the AI ─────────────────────────────────────────
        const linkContext = all
          .map(
            (r, i) =>
              `[${i + 1}] ${r.title}\nURL: ${r.url}${r.snippet ? `\nSnippet: ${r.snippet}` : ""}`
          )
          .join("\n\n");
        const deepContext = pageTexts
          .map((p) => `=== FULL PAGE: ${p.domain} (${p.url}) ===\n${p.text}`)
          .join("\n\n---\n\n");
        const context = `${linkContext}${deepContext ? `\n\n${deepContext}` : ""}`;

        emit({ done: true, count: all.length, fetched: pageTexts.length, context, sources: all });
      } catch (e) {
        emit({ error: (e as Error).message });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
