import { db } from "@/db";
import { files } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { generateText } from "ai";
import { getModel, type Provider } from "@/lib/ai-providers";

export const dynamic = "force-dynamic";
export const maxDuration = 90;

type OpType = "read" | "write" | "patch" | "create" | "delete" | "fix" | "refactor";

function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }
function sse(obj: unknown) { return `data: ${JSON.stringify(obj)}\n\n`; }

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body) return Response.json({ error: "Invalid body" }, { status: 400 });

  const {
    op, session_id, file_id, filename, language,
    content, instruction,
    api_key, groq_key, provider, model,
  } = body as {
    op: OpType; session_id: number; file_id?: number;
    filename?: string; language?: string; content?: string;
    instruction?: string; api_key?: string; groq_key?: string;
    provider?: string; model?: string;
  };

  const sid = Number(session_id);
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(ctrl) {
      const emit = (obj: unknown) => ctrl.enqueue(encoder.encode(sse(obj)));

      try {
        // ── READ ─────────────────────────────────────────────────────────
        if (op === "read") {
          if (!file_id) throw new Error("file_id required for read");
          emit({ status: "reading", detail: `📖 Reading file…` });
          const [row] = await db.select().from(files).where(eq(files.id, file_id));
          if (!row) throw new Error("File not found");
          emit({ status: "done", op: "read", file: row, content: row.content });
        }

        // ── CREATE ───────────────────────────────────────────────────────
        else if (op === "create") {
          if (!filename || !sid) throw new Error("filename and session_id required");
          emit({ status: "creating", detail: `✨ Creating ${filename}…` });
          await sleep(120);
          const lines = (content || "").split("\n");
          emit({ status: "writing", detail: `✍️ Writing ${lines.length} lines…`, total_lines: lines.length });

          // Stream line-by-line for animation
          let written = 0;
          for (const line of lines) {
            written++;
            if (written % Math.max(1, Math.floor(lines.length / 20)) === 0) {
              emit({ status: "line", line_num: written, total: lines.length });
              await sleep(30);
            }
          }

          const [row] = await db.insert(files).values({
            sessionId: sid,
            filename: filename,
            content: content || "",
            language: language || guessLang(filename),
          }).returning();
          emit({ status: "done", op: "create", file: row });
        }

        // ── WRITE (overwrite) ─────────────────────────────────────────────
        else if (op === "write") {
          if (!file_id) throw new Error("file_id required for write");
          emit({ status: "writing", detail: `💾 Overwriting file…` });
          const lines = (content || "").split("\n");
          for (let i = 0; i < lines.length; i += Math.max(1, Math.floor(lines.length / 15))) {
            emit({ status: "line", line_num: i + 1, total: lines.length });
            await sleep(25);
          }
          const [row] = await db.update(files)
            .set({ content: content || "", updatedAt: new Date() })
            .where(eq(files.id, file_id))
            .returning();
          emit({ status: "done", op: "write", file: row });
        }

        // ── PATCH (AI-guided edit) ─────────────────────────────────────────
        else if (op === "patch" || op === "fix" || op === "refactor") {
          if (!file_id) throw new Error("file_id required");
          emit({ status: "reading", detail: `📖 Reading current file…` });
          const [row] = await db.select().from(files).where(eq(files.id, file_id));
          if (!row) throw new Error("File not found");

          const envGroq = process.env.GROQ_API_KEY || "";
          const envOr = process.env.OPENROUTER_API_KEY || "";
          const prov: Provider = provider === "groq" ? "groq" : "openrouter";
          const key = prov === "groq" ? (groq_key || envGroq) : (api_key || envOr);
          if (!key) throw new Error("API key required for AI-guided edits");

          emit({ status: "thinking", detail: `🧠 Agent analyzing ${row.filename}…` });
          await sleep(200);

          const aiModel = getModel({ provider: prov, model: model || "llama-3.1-8b-instant", apiKey: key });
          const opLabel = op === "fix" ? "Fix all bugs in" : op === "refactor" ? "Refactor and improve" : "Apply this change to";
          const { text } = await generateText({
            model: aiModel,
            temperature: 0.1,
            maxOutputTokens: 8000,
            abortSignal: AbortSignal.timeout(60_000),
            system: `You are a code editor. ${opLabel} the file. Return ONLY the complete updated file content — no markdown fences, no explanation, just raw code.`,
            prompt: `FILE: ${row.filename}\n\`\`\`\n${row.content.slice(0, 12000)}\n\`\`\`\n\nINSTRUCTION: ${instruction || op}\n\nReturn ONLY the complete updated file content.`,
          });

          const newContent = text.replace(/^```[\w:+#.-]*\n?/, "").replace(/\n?```\s*$/, "").trim();
          emit({ status: "applying", detail: `⚡ Applying ${newContent.split("\n").length} line edit…` });

          const newLines = newContent.split("\n");
          for (let i = 0; i < newLines.length; i += Math.max(1, Math.floor(newLines.length / 12))) {
            emit({ status: "line", line_num: i + 1, total: newLines.length });
            await sleep(30);
          }

          const [updated] = await db.update(files)
            .set({ content: newContent, updatedAt: new Date() })
            .where(eq(files.id, file_id))
            .returning();
          emit({ status: "done", op, file: updated, diff_lines: Math.abs(newLines.length - row.content.split("\n").length) });
        }

        // ── DELETE ─────────────────────────────────────────────────────────
        else if (op === "delete") {
          if (!file_id) throw new Error("file_id required for delete");
          emit({ status: "deleting", detail: `🗑️ Deleting file…` });
          await sleep(200);
          await db.delete(files).where(and(eq(files.id, file_id), eq(files.sessionId, sid)));
          emit({ status: "done", op: "delete", file_id });
        }

        else {
          throw new Error(`Unknown op: ${op}`);
        }
      } catch (e) {
        ctrl.enqueue(encoder.encode(sse({ error: (e as Error).message })));
      } finally {
        ctrl.close();
      }
    },
  });

  return new Response(stream, {
    headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", "X-Accel-Buffering": "no" },
  });
}

function guessLang(filename: string): string {
  const ext = filename.split(".").pop()?.toLowerCase() || "";
  const map: Record<string, string> = {
    ts: "typescript", tsx: "typescript", js: "javascript", jsx: "javascript",
    py: "python", rs: "rust", go: "go", java: "java", cpp: "cpp", c: "c",
    html: "html", css: "css", json: "json", md: "markdown", sh: "bash",
    sql: "sql", yaml: "yaml", yml: "yaml", toml: "toml",
  };
  return map[ext] || "text";
}
