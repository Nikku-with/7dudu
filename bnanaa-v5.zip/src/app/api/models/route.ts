import { GROQ_MODELS, OPENROUTER_FREE_MODELS, fetchLiveFreeModels } from "@/lib/free-models";

export const dynamic = "force-dynamic";
// 5 minute cache — fast enough, fresh enough
export const revalidate = 300;

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const provider = searchParams.get("provider") || "openrouter";
  const live = searchParams.get("live") === "1";

  if (provider === "groq") {
    return Response.json({ models: GROQ_MODELS, source: "static" });
  }

  if (live) {
    try {
      const models = await fetchLiveFreeModels();
      return Response.json({ models, source: "live" });
    } catch {
      return Response.json({ models: OPENROUTER_FREE_MODELS, source: "fallback" });
    }
  }

  return Response.json({ models: OPENROUTER_FREE_MODELS, source: "static" });
}
