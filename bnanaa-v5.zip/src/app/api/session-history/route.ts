import { db } from "@/db";
import { messages } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const sid = Number(url.searchParams.get("session_id"));
    if (!sid) return Response.json([]);
    const rows = await db
      .select({
        id: messages.id,
        role: messages.role,
        content: messages.content,
        messageType: messages.messageType,
        createdAt: messages.createdAt,
        metadata: messages.metadata,
      })
      .from(messages)
      .where(eq(messages.sessionId, sid))
      .orderBy(desc(messages.createdAt))
      .limit(100);
    return Response.json(rows);
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}
