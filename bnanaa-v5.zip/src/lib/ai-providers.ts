import { createOpenRouter } from "@openrouter/ai-sdk-provider";
import { createGroq } from "@ai-sdk/groq";
import type { LanguageModel, JSONValue } from "ai";
import { modelSupportsReasoning } from "./free-models";

export type Provider = "groq" | "openrouter";
export type ReasoningEffort = "low" | "medium" | "high";

interface ModelOpts {
  provider: Provider;
  model: string;
  apiKey: string;
}

/**
 * Build a Vercel AI SDK `LanguageModel` for the chosen provider.
 * Both providers speak through `ai`'s unified `streamText`/`generateText`/`generateObject` API,
 * so the rest of the app never has to think about OpenAI-compatible REST shapes again.
 */
export function getModel({ provider, model, apiKey }: ModelOpts): LanguageModel {
  if (provider === "groq") {
    const groq = createGroq({ apiKey });
    return groq(model || "llama-3.1-8b-instant");
  }
  const openrouter = createOpenRouter({
    apiKey,
    headers: {
      "HTTP-Referer": "https://banana-agent.app",
      "X-Title": "Banana Agent",
    },
  });
  return openrouter(model || "openrouter/free");
}

/**
 * Provider-specific options that turn on native reasoning/thinking streaming.
 * Each provider exposes this differently (OpenRouter: `reasoning.effort`,
 * Groq: `reasoningFormat`) — this normalizes both behind one call.
 */
export function reasoningProviderOptions(
  provider: Provider,
  model: string,
  effort: ReasoningEffort = "medium"
): Record<string, Record<string, JSONValue>> | undefined {
  if (!modelSupportsReasoning(provider, model)) return undefined;
  if (provider === "groq") {
    return { groq: { reasoningFormat: "parsed", reasoningEffort: effort } };
  }
  return { openrouter: { reasoning: { effort, enabled: true } } };
}

/** A fast, cheap, low-latency model used for query planning / search-result evaluation. */
export function getPlannerModel({ provider, apiKey }: Omit<ModelOpts, "model">): LanguageModel {
  if (provider === "groq") {
    return createGroq({ apiKey })("llama-3.1-8b-instant");
  }
  return createOpenRouter({ apiKey })("meta-llama/llama-3.3-70b-instruct:free");
}
