"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import dynamic from "next/dynamic";
import { useAgent, type AgentFile } from "@/store/agent-store";
import { copyText } from "@/lib/client-utils";

// Monaco is client-only; no SSR
const MonacoEditor = dynamic(() => import("@monaco-editor/react"), { ssr: false, loading: () => (
  <div className="flex-1 flex items-center justify-center bg-[#0d0d10] text-zinc-500 text-sm">
    Loading Monaco…
  </div>
) });

// ── Agent op animation state ───────────────────────────────────────────────
interface OpAnim {
  id: number;
  op: string;
  detail: string;
  line?: number;
  total?: number;
  done: boolean;
  file?: AgentFile;
}

// ── Language → Monaco language id map ─────────────────────────────────────
function monacoLang(lang: string) {
  const m: Record<string, string> = {
    typescript: "typescript", javascript: "javascript",
    tsx: "typescript", jsx: "javascript",
    python: "python", rust: "rust", go: "go",
    java: "java", cpp: "cpp", c: "c", bash: "shell",
    html: "html", css: "css", json: "json",
    markdown: "markdown", sql: "sql", yaml: "yaml",
  };
  return m[lang] || lang || "plaintext";
}

// ── Sidebar: File Tree ─────────────────────────────────────────────────────
function FileTree({
  files, active, onSelect, onDelete,
}: {
  files: AgentFile[];
  active: AgentFile | null;
  onSelect: (f: AgentFile) => void;
  onDelete: (f: AgentFile) => void;
}) {
  const [delConfirm, setDelConfirm] = useState<number | null>(null);
  const grouped: Record<string, AgentFile[]> = {};
  for (const f of files) {
    const ext = f.filename.split(".").pop() || "other";
    (grouped[ext] = grouped[ext] || []).push(f);
  }
  return (
    <div className="h-full flex flex-col bg-[#0d0d10]">
      <div className="px-3 py-2 text-[10px] font-black tracking-widest text-zinc-500 uppercase border-b border-zinc-800">
        📁 Session Files ({files.length})
      </div>
      <div className="flex-1 overflow-y-auto scroll-thin py-1">
        {files.length === 0 && (
          <div className="px-3 py-8 text-center text-[11px] text-zinc-600">
            No files yet.<br />Ask AI to write code to create files here.
          </div>
        )}
        {files.map((f) => (
          <div
            key={f.id}
            onClick={() => { setDelConfirm(null); onSelect(f); }}
            className={`group flex items-center gap-2 px-3 py-1.5 cursor-pointer transition-colors text-[12px] ${
              active?.id === f.id
                ? "bg-yellow-400/10 text-yellow-300 border-l-2 border-yellow-400"
                : "text-zinc-400 hover:bg-zinc-800/60 hover:text-zinc-200 border-l-2 border-transparent"
            }`}
          >
            <span className="shrink-0 opacity-60">{fileIcon(f.filename)}</span>
            <span className="truncate flex-1 font-mono">{f.filename}</span>
            <span className="text-[9px] text-zinc-600 shrink-0">{f.language}</span>
            {delConfirm === f.id ? (
              <button
                onClick={(e) => { e.stopPropagation(); onDelete(f); setDelConfirm(null); }}
                className="shrink-0 text-[9px] text-red-400 font-bold hover:text-red-200"
              >
                confirm?
              </button>
            ) : (
              <button
                onClick={(e) => { e.stopPropagation(); setDelConfirm(f.id); }}
                className="shrink-0 text-[9px] text-zinc-600 opacity-0 group-hover:opacity-100 hover:text-red-400 transition-all"
              >
                🗑
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function fileIcon(filename: string) {
  const ext = filename.split(".").pop()?.toLowerCase();
  const icons: Record<string, string> = {
    ts: "🔷", tsx: "⚛️", js: "🟨", jsx: "⚛️", py: "🐍",
    html: "🌐", css: "🎨", json: "📋", md: "📝", sql: "🗄️",
    rs: "🦀", go: "🐹", java: "☕", sh: "💻", yaml: "⚙️", toml: "⚙️",
  };
  return icons[ext || ""] || "📄";
}

// ── Agent Op Progress Bar ──────────────────────────────────────────────────
function AgentOpOverlay({ op }: { op: OpAnim }) {
  const pct = op.line && op.total ? Math.round((op.line / op.total) * 100) : 0;
  return (
    <div className="absolute bottom-0 left-0 right-0 bg-zinc-950/95 border-t border-yellow-500/30 px-4 py-2 z-20">
      <div className="flex items-center gap-3">
        <span className="text-[11px] text-yellow-300 font-mono truncate">{op.detail}</span>
        {op.line && op.total && (
          <span className="text-[10px] text-zinc-500 font-mono shrink-0">
            {op.line}/{op.total} lines
          </span>
        )}
        {!op.done && (
          <span className="flex gap-0.5 shrink-0">
            {[0,1,2].map(i => (
              <span key={i} className="w-1 h-1 rounded-full bg-yellow-400 animate-bounce"
                style={{ animationDelay: `${i*0.15}s` }} />
            ))}
          </span>
        )}
      </div>
      {op.line && op.total ? (
        <div className="mt-1.5 h-1 rounded-full bg-zinc-800 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-yellow-400 to-amber-500 transition-all duration-100"
            style={{ width: `${pct}%` }}
          />
        </div>
      ) : null}
    </div>
  );
}

// ── HTML Live Preview ──────────────────────────────────────────────────────
function HtmlPreview({ html, onOpenTab }: { html: string; onOpenTab: () => void }) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  useEffect(() => {
    const fr = iframeRef.current;
    if (!fr) return;
    const doc = fr.contentDocument || fr.contentWindow?.document;
    if (!doc) return;
    doc.open();
    doc.write(html);
    doc.close();
  }, [html]);
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-2 px-3 py-1.5 border-b border-zinc-800 bg-zinc-950 text-[11px]">
        <span className="text-zinc-400 font-bold">🌐 Live Preview</span>
        <button
          onClick={onOpenTab}
          className="ml-auto text-zinc-500 hover:text-yellow-300 transition-colors"
          title="Open in new tab"
        >↗ Open tab</button>
      </div>
      <iframe
        ref={iframeRef}
        className="flex-1 w-full bg-white"
        sandbox="allow-scripts allow-modals"
        title="Live Preview"
      />
    </div>
  );
}

// ── Session History Panel ──────────────────────────────────────────────────
function SessionHistoryPanel({ sessionId, onJumpToFile }: { sessionId: number; onJumpToFile?: (filename: string) => void }) {
  const [msgs, setMsgs] = useState<{
    id: number; role: string; content: string; createdAt: string;
    metadata?: { code_files?: { filename: string }[] };
  }[]>([]);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState<number | null>(null);

  useEffect(() => {
    if (!sessionId) return;
    setLoading(true);
    fetch(`/api/session-history?session_id=${sessionId}`)
      .then(r => r.json())
      .then(data => { setMsgs(Array.isArray(data) ? data : []); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [sessionId]);

  return (
    <div className="h-full flex flex-col bg-[#0d0d10]">
      <div className="px-3 py-2 text-[10px] font-black tracking-widest text-zinc-500 uppercase border-b border-zinc-800 flex items-center gap-2">
        📜 Session History
        <span className="ml-auto text-zinc-600">{msgs.length} msgs</span>
      </div>
      {loading && (
        <div className="flex-1 flex items-center justify-center text-zinc-600 text-sm">Loading…</div>
      )}
      <div className="flex-1 overflow-y-auto scroll-thin divide-y divide-zinc-800/50">
        {msgs.map((m) => (
          <div key={m.id} className="px-3 py-2 hover:bg-zinc-800/30 cursor-pointer transition-colors"
            onClick={() => setExpanded(expanded === m.id ? null : m.id)}>
            <div className="flex items-center gap-2">
              <span className={`text-[10px] font-bold shrink-0 ${m.role === "user" ? "text-yellow-400" : m.role === "agent" ? "text-emerald-400" : "text-zinc-500"}`}>
                {m.role === "user" ? "👤" : m.role === "agent" ? "🍌" : "⚙️"} {m.role}
              </span>
              <span className="text-[10px] text-zinc-600 font-mono shrink-0">
                {new Date(m.createdAt).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
              </span>
              {m.metadata?.code_files?.length ? (
                <span className="text-[9px] text-orange-400">{m.metadata.code_files.length} files</span>
              ) : null}
              <span className="ml-auto text-[9px] text-zinc-600">{expanded === m.id ? "▾" : "▸"}</span>
            </div>
            <div className={`text-[11px] text-zinc-400 mt-0.5 ${expanded === m.id ? "whitespace-pre-wrap" : "truncate"}`}>
              {m.content.slice(0, expanded === m.id ? 2000 : 80)}
            </div>
            {expanded === m.id && m.metadata?.code_files?.map((cf) => (
              <button key={cf.filename}
                onClick={(e) => { e.stopPropagation(); onJumpToFile?.(cf.filename); }}
                className="mt-1 mr-1 inline-block text-[9px] bg-orange-500/15 text-orange-300 px-1.5 py-0.5 rounded hover:bg-orange-500/30"
              >
                📄 {cf.filename}
              </button>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Main Monaco Panel ──────────────────────────────────────────────────────
type PanelTab = "editor" | "preview" | "history";

export default function MonacoPanel({
  initialFile, onClose,
}: {
  initialFile?: AgentFile | null;
  onClose?: () => void;
}) {
  const { files, currentSession, fetchFiles, saveFile, deleteFile, settings } = useAgent();
  const [activeFile, setActiveFile] = useState<AgentFile | null>(initialFile || null);
  const [content, setContent] = useState(initialFile?.content || "");
  const [dirty, setDirty] = useState(false);
  const [tab, setTab] = useState<PanelTab>("editor");
  const [op, setOp] = useState<OpAnim | null>(null);
  const [copied, setCopied] = useState(false);
  const opCountRef = useRef(0);

  // Load first file if none selected
  useEffect(() => {
    if (!activeFile && files.length > 0) {
      setActiveFile(files[0]);
      setContent(files[0].content);
    }
  }, [files]);

  // Sync content when active file changes
  useEffect(() => {
    if (activeFile) { setContent(activeFile.content); setDirty(false); }
  }, [activeFile?.id]);

  const selectFile = useCallback((f: AgentFile) => {
    setActiveFile(f); setContent(f.content); setDirty(false);
    setTab("editor");
  }, []);

  const handleSave = async () => {
    if (!activeFile || !dirty) return;
    await saveFile(activeFile.id, content);
    setDirty(false);
  };

  const handleDelete = async (f: AgentFile) => {
    await deleteFile(f.id);
    if (activeFile?.id === f.id) { setActiveFile(null); setContent(""); }
  };

  // Open HTML in new tab
  const openInTab = () => {
    if (!activeFile) return;
    const blob = new Blob([content], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank");
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  };

  // Agent operation (patch/fix/refactor)
  const runAgentOp = async (opType: "fix" | "refactor" | "patch", instruction?: string) => {
    if (!activeFile) return;
    const id = ++opCountRef.current;
    setOp({ id, op: opType, detail: `🧠 Agent starting ${opType}…`, done: false });

    try {
      const r = await fetch("/api/agent-ops", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          op: opType, session_id: currentSession?.id,
          file_id: activeFile.id, instruction,
          api_key: settings.apiKey, groq_key: settings.groqKey,
          provider: settings.provider, model: settings.model,
        }),
      });
      if (!r.ok || !r.body) throw new Error("op failed");
      const reader = r.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() || "";
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const d = JSON.parse(line.slice(6));
            if (d.error) { setOp(prev => prev && { ...prev, detail: `❌ ${d.error}`, done: true }); break; }
            if (d.status) setOp(prev => prev && { ...prev, detail: d.detail || d.status, line: d.line_num, total: d.total });
            if (d.status === "done" && d.file) {
              setContent(d.file.content);
              setDirty(false);
              setOp(prev => prev && { ...prev, detail: `✅ ${opType} complete`, done: true, file: d.file });
              await fetchFiles();
              setTimeout(() => setOp(null), 3000);
            }
          } catch {}
        }
      }
    } catch (e) {
      setOp(prev => prev && { ...prev, detail: `❌ ${(e as Error).message}`, done: true });
      setTimeout(() => setOp(null), 3000);
    }
  };

  const isHtml = activeFile?.language === "html" || activeFile?.filename?.endsWith(".html");

  return (
    <div className="flex h-full bg-[#0d0d10] text-zinc-100 overflow-hidden rounded-xl border border-zinc-800">
      {/* ── Sidebar ────────────────────────────────────────────────── */}
      <div className="w-52 shrink-0 border-r border-zinc-800 flex flex-col overflow-hidden">
        <FileTree files={files} active={activeFile} onSelect={selectFile} onDelete={handleDelete} />
        {currentSession && (
          <div className="border-t border-zinc-800 shrink-0 max-h-44 overflow-y-auto">
            <SessionHistoryPanel
              sessionId={currentSession.id}
              onJumpToFile={(fname) => {
                const f = files.find(x => x.filename === fname);
                if (f) selectFile(f);
              }}
            />
          </div>
        )}
      </div>

      {/* ── Main area ──────────────────────────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Toolbar */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 border-b border-zinc-800 bg-zinc-950 shrink-0 flex-wrap">
          {/* File name */}
          <span className="font-mono text-[12px] text-yellow-300 shrink-0">
            {activeFile ? `${fileIcon(activeFile.filename)} ${activeFile.filename}` : "No file selected"}
          </span>
          {dirty && <span className="text-[10px] text-amber-400 animate-pulse">● unsaved</span>}

          <div className="flex items-center gap-1 ml-auto">
            {/* Panel tabs */}
            {(["editor", "preview", "history"] as PanelTab[]).map((t) => (
              (!isHtml && t === "preview") ? null :
              <button key={t} onClick={() => setTab(t)}
                className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all ${tab === t ? "bg-yellow-400 text-zinc-900" : "bg-zinc-800 text-zinc-500 hover:text-zinc-200"}`}>
                {t === "editor" ? "✏️ Edit" : t === "preview" ? "🌐 Preview" : "📜 History"}
              </button>
            ))}

            {/* Agent ops */}
            {activeFile && !op && (
              <>
                <button onClick={() => runAgentOp("fix")}
                  className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-500/15 text-red-300 hover:bg-red-500/25 transition-all">
                  🔧 Fix
                </button>
                <button onClick={() => runAgentOp("refactor")}
                  className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/15 text-blue-300 hover:bg-blue-500/25 transition-all">
                  ⚡ Refactor
                </button>
              </>
            )}

            {/* Save */}
            {dirty && (
              <button onClick={handleSave}
                className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500 text-zinc-900 hover:bg-emerald-400 transition-all">
                💾 Save
              </button>
            )}

            {/* Copy */}
            {activeFile && (
              <button onClick={async () => { if (await copyText(content)) { setCopied(true); setTimeout(() => setCopied(false), 1500); }}}
                className="px-2 py-0.5 rounded text-[10px] font-bold bg-zinc-800 text-zinc-400 hover:text-zinc-200 transition-all">
                {copied ? "✓ Copied" : "📋"}
              </button>
            )}

            {/* Open HTML in tab */}
            {isHtml && (
              <button onClick={openInTab}
                className="px-2 py-0.5 rounded text-[10px] font-bold bg-zinc-800 text-zinc-400 hover:text-zinc-200 transition-all">
                ↗ New tab
              </button>
            )}

            {/* Close panel */}
            {onClose && (
              <button onClick={onClose}
                className="px-2 py-0.5 rounded text-[10px] text-zinc-600 hover:text-zinc-300 transition-all">
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Panel content */}
        <div className="flex-1 relative overflow-hidden">
          {tab === "preview" && isHtml ? (
            <HtmlPreview html={content} onOpenTab={openInTab} />
          ) : tab === "history" ? (
            currentSession ? (
              <SessionHistoryPanel sessionId={currentSession.id} onJumpToFile={(fname) => {
                const f = files.find(x => x.filename === fname);
                if (f) { selectFile(f); setTab("editor"); }
              }} />
            ) : (
              <div className="flex items-center justify-center h-full text-zinc-600 text-sm">No session active</div>
            )
          ) : (
            <>
              {activeFile ? (
                <MonacoEditor
                  height="100%"
                  language={monacoLang(activeFile.language)}
                  value={content}
                  onChange={(val) => { setContent(val || ""); setDirty(true); }}
                  onMount={(editor) => {
                    editor.addCommand(2048 + 49 /* Ctrl+S */, () => handleSave());
                  }}
                  options={{
                    theme: "vs-dark",
                    fontSize: 13,
                    fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace",
                    fontLigatures: true,
                    minimap: { enabled: true, scale: 0.8 },
                    scrollBeyondLastLine: false,
                    wordWrap: "on",
                    lineNumbers: "on",
                    renderWhitespace: "boundary",
                    bracketPairColorization: { enabled: true },
                    smoothScrolling: true,
                    cursorBlinking: "phase",
                    cursorSmoothCaretAnimation: "on",
                    tabSize: 2,
                    padding: { top: 12 },
                    suggest: { showKeywords: true },
                    formatOnPaste: true,
                    automaticLayout: true,
                  }}
                />
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-center px-6">
                  <div className="text-4xl mb-3">📁</div>
                  <div className="text-zinc-400 text-sm mb-1">No file selected</div>
                  <div className="text-zinc-600 text-[11px]">Ask AI to write code — files appear here automatically.<br />You can also jump here from any code block in chat (📂 button).</div>
                </div>
              )}
              {/* Agent operation overlay */}
              {op && <AgentOpOverlay op={op} />}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
