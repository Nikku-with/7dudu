"use client";

import { useEffect, useRef, useState } from "react";
import { useAgent, type SearchResult } from "@/store/agent-store";
import { copyText } from "@/lib/client-utils";

const STORAGE_KEY = "banana_recent_sources_v1";
const MAX_RECENT = 20;

interface StoredSource extends SearchResult {
  query: string;
  at: number;
}

function loadRecent(): StoredSource[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function saveRecent(list: StoredSource[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list.slice(0, MAX_RECENT)));
  } catch {
    /* ignore */
  }
}

export function useRecentSources() {
  const { search, messages } = useAgent();
  const [recent, setRecent] = useState<StoredSource[]>([]);

  // initial load
  useEffect(() => {
    setRecent(loadRecent());
  }, []);

  // persist new results from live search
  useEffect(() => {
    if (!search.done || search.results.length === 0) return;
    // find the last user message to use as query label
    const lastUser = [...messages].reverse().find((m) => m.role === "user");
    const query = lastUser?.content.slice(0, 60) || "search";
    const at = Date.now();
    const newItems: StoredSource[] = search.results.map((r) => ({
      ...r,
      query,
      at,
    }));
    setRecent((prev) => {
      const seen = new Set(prev.map((r) => r.url));
      const merged = [
        ...newItems.filter((r) => !seen.has(r.url)),
        ...prev,
      ].slice(0, MAX_RECENT);
      saveRecent(merged);
      return merged;
    });
  }, [search.done]);

  const clear = () => {
    setRecent([]);
    saveRecent([]);
  };

  return { recent, clear };
}

export default function RecentSourcesDropdown() {
  const { recent, clear } = useRecentSources();
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (!ref.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const copy = async (url: string) => {
    if (await copyText(url)) {
      setCopied(url);
      setTimeout(() => setCopied(null), 1500);
    }
  };

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(!open)}
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold transition-all ${
          recent.length > 0
            ? "bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/25"
            : "bg-zinc-800/80 text-zinc-500 hover:text-zinc-300"
        }`}
      >
        🔗 Recent sources
        {recent.length > 0 && (
          <span className="text-[9px] px-1.5 rounded-full bg-emerald-500/20 text-emerald-300">
            {recent.length}
          </span>
        )}
        <span className="text-[10px]">{open ? "▲" : "▼"}</span>
      </button>

      {open && (
        <div className="absolute bottom-full mb-2 right-0 w-[min(340px,calc(100vw-32px))] max-h-[320px] rounded-2xl border border-zinc-700 bg-zinc-900 shadow-2xl overflow-hidden animate-slide-in z-40">
          <div className="flex items-center justify-between px-3 py-2 border-b border-zinc-800 bg-zinc-950/80">
            <span className="text-[11px] font-bold text-emerald-300 tracking-wider uppercase">
              🔗 Recently visited sources
            </span>
            {recent.length > 0 && (
              <button
                onClick={clear}
                className="text-[10px] text-zinc-500 hover:text-red-400"
              >
                clear
              </button>
            )}
          </div>
          <div className="max-h-[260px] overflow-y-auto scroll-thin p-1.5 space-y-1">
            {recent.length === 0 && (
              <div className="px-3 py-6 text-center text-[12px] text-zinc-500">
                No sources yet. Toggle 🌐 Web Search and ask anything to see live results here.
              </div>
            )}
            {recent.map((r, i) => (
              <div
                key={i}
                className="group flex items-start gap-2 rounded-lg px-2 py-1.5 hover:bg-zinc-800/60 transition-colors"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={`https://www.google.com/s2/favicons?domain=${r.domain}&sz=32`}
                  alt=""
                  className="w-4 h-4 rounded mt-0.5 shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <a
                    href={r.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block text-[12px] text-zinc-200 truncate hover:text-yellow-300"
                    title={r.title}
                  >
                    {r.title}
                  </a>
                  <div className="text-[10px] text-zinc-500 truncate">
                    {r.domain} · {r.query}
                  </div>
                </div>
                <button
                  onClick={() => copy(r.url)}
                  className={`shrink-0 px-1.5 py-0.5 rounded text-[9px] font-bold transition-all active:scale-95 ${
                    copied === r.url
                      ? "bg-emerald-500/20 text-emerald-300"
                      : "bg-zinc-800 text-zinc-500 hover:text-zinc-200"
                  }`}
                  title="Copy link"
                >
                  {copied === r.url ? "✓" : "📋"}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
