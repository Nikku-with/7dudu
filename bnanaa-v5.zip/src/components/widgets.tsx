"use client";

import { useState, useRef, useEffect } from "react";
import { copyText, downloadFile, extForLanguage } from "@/lib/client-utils";
import { useAgent } from "@/store/agent-store";

export interface CodeBlockData {
  filename: string;
  language: string;
  content: string;
}

/* ---------- Multi-select question widget (choice / buttons) ---------- */
function MultiSelectWidget({ options, kind }: { options: string[]; kind: string }) {
  const { sendMessage, loading } = useAgent();
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [custom, setCustom] = useState("");
  const [sent, setSent] = useState(false);

  const toggle = (i: number) => {
    if (sent) return;
    setSelected((p) => {
      const n = new Set(p);
      if (n.has(i)) n.delete(i);
      else n.add(i);
      return n;
    });
  };

  const launch = () => {
    const picks = options.filter((_, i) => selected.has(i));
    if (picks.length === 0 && !custom.trim()) return;
    let msg = "";
    if (picks.length) msg += `My selections: ${picks.join(", ")}`;
    if (custom.trim())
      msg += `${picks.length ? ". " : ""}My own answer: ${custom.trim()}`;
    setSent(true);
    sendMessage(msg);
  };

  const count = selected.size + (custom.trim() ? 1 : 0);

  return (
    <div
      className={`my-2 rounded-xl border p-3 transition-all ${
        sent
          ? "border-emerald-500/30 bg-emerald-950/20"
          : "border-yellow-500/30 bg-yellow-500/5"
      }`}
    >
      <div className="flex items-center gap-2 mb-2">
        <span className="text-[10px] font-bold tracking-widest text-yellow-400/90 uppercase">
          {kind === "buttons" ? "⚡ Quick Actions" : "☑️ Pick one or many"}
        </span>
        {!sent && count > 0 && (
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-yellow-500/20 text-yellow-300 font-bold">
            {count} selected
          </span>
        )}
        {sent && (
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold">
            ✓ Launched
          </span>
        )}
      </div>
      <div className="flex flex-wrap gap-1.5">
        {options.map((o, i) => {
          const on = selected.has(i);
          return (
            <button
              key={i}
              onClick={() => toggle(i)}
              disabled={sent}
              className={`px-3 py-1.5 rounded-lg text-[13px] font-medium border transition-all active:scale-95 ${
                on
                  ? "bg-yellow-400 text-zinc-900 border-yellow-400 shadow-[0_0_12px_rgba(250,204,21,0.4)]"
                  : "bg-zinc-800/80 text-zinc-200 border-zinc-700 hover:border-yellow-500/50 hover:bg-zinc-800"
              } ${sent ? "opacity-60 cursor-default" : "cursor-pointer"}`}
            >
              {on ? "✓ " : ""}
              {o}
            </button>
          );
        })}
      </div>
      {!sent && (
        <div className="flex gap-2 mt-2.5">
          <input
            value={custom}
            onChange={(e) => setCustom(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && launch()}
            placeholder="✍️ Or type your own answer…"
            className="flex-1 min-w-0 rounded-lg bg-zinc-900 border border-zinc-700 px-3 py-1.5 text-[13px] text-zinc-100 placeholder:text-zinc-500 focus:border-yellow-500/60 focus:outline-none"
          />
          <button
            onClick={launch}
            disabled={loading || count === 0}
            className="px-4 py-1.5 rounded-lg text-[13px] font-bold bg-gradient-to-r from-yellow-400 to-amber-500 text-zinc-900 disabled:opacity-40 disabled:cursor-not-allowed hover:brightness-110 active:scale-95 transition-all shrink-0"
          >
            Launch 🚀
          </button>
        </div>
      )}
    </div>
  );
}

/* ---------- Copy widget ---------- */
export function CopyCard({ text }: { text: string }) {
  const [ok, setOk] = useState(false);
  return (
    <div className="my-2 flex items-center gap-2 rounded-xl border border-zinc-700 bg-black/50 px-3 py-2">
      <span className="text-zinc-500 font-mono text-xs">$</span>
      <code className="flex-1 min-w-0 font-mono text-[12.5px] text-emerald-300 truncate">
        {text}
      </code>
      <button
        onClick={async () => {
          if (await copyText(text)) {
            setOk(true);
            setTimeout(() => setOk(false), 1800);
          }
        }}
        className={`shrink-0 px-2.5 py-1 rounded-md text-[11px] font-bold transition-all active:scale-95 ${
          ok
            ? "bg-emerald-500/20 text-emerald-300"
            : "bg-zinc-800 text-zinc-300 hover:bg-zinc-700"
        }`}
      >
        {ok ? "✓ Copied!" : "📋 Copy"}
      </button>
    </div>
  );
}

/* ---------- File download card ---------- */
function FileCard({
  filename,
  codeBlocks,
}: {
  filename: string;
  codeBlocks: CodeBlockData[];
}) {
  const { files } = useAgent();
  const [copied, setCopied] = useState(false);
  const [dl, setDl] = useState(false);

  const block =
    codeBlocks.find((b) => b.filename === filename) ||
    (() => {
      const f = files.find((f) => f.filename === filename);
      return f
        ? { filename: f.filename, language: f.language, content: f.content }
        : null;
    })();

  const content = block?.content || "";
  const size = new Blob([content]).size;
  const ext = filename.split(".").pop()?.toUpperCase() || "FILE";

  return (
    <div className="my-2 flex items-center gap-3 rounded-xl border border-blue-500/30 bg-blue-950/20 px-3 py-2.5">
      <div className="w-9 h-9 rounded-lg bg-blue-500/15 flex items-center justify-center text-[10px] font-black text-blue-300 shrink-0">
        {ext.slice(0, 4)}
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-[13px] font-semibold text-blue-100 truncate">
          {filename}
        </div>
        <div className="text-[10px] text-blue-400/70">
          {content ? `${size.toLocaleString()} bytes · ready` : "file not found in this response"}
        </div>
      </div>
      <button
        onClick={async () => {
          if (content && (await copyText(content))) {
            setCopied(true);
            setTimeout(() => setCopied(false), 1500);
          }
        }}
        disabled={!content}
        className="shrink-0 px-2.5 py-1.5 rounded-md text-[11px] font-bold bg-zinc-800 text-zinc-300 hover:bg-zinc-700 disabled:opacity-40 active:scale-95 transition-all"
      >
        {copied ? "✓" : "📋 Copy"}
      </button>
      <button
        onClick={() => {
          if (content && downloadFile(filename, content)) {
            setDl(true);
            setTimeout(() => setDl(false), 1500);
          }
        }}
        disabled={!content}
        className="shrink-0 px-2.5 py-1.5 rounded-md text-[11px] font-bold bg-blue-500/20 text-blue-200 hover:bg-blue-500/30 disabled:opacity-40 active:scale-95 transition-all"
      >
        {dl ? "✓ Saved" : "⬇ Download"}
      </button>
    </div>
  );
}

/* ---------- Other widgets ---------- */
function Checklist({ items }: { items: string[] }) {
  const [done, setDone] = useState<Set<number>>(new Set());
  return (
    <div className="my-2 rounded-xl border border-zinc-700 bg-zinc-900/60 p-3 space-y-1.5">
      {items.map((it, i) => {
        const d = done.has(i);
        return (
          <button
            key={i}
            onClick={() =>
              setDone((p) => {
                const n = new Set(p);
                if (n.has(i)) n.delete(i);
                else n.add(i);
                return n;
              })
            }
            className="flex items-center gap-2.5 w-full text-left group"
          >
            <span
              className={`w-4.5 h-4.5 w-[18px] h-[18px] rounded border flex items-center justify-center text-[10px] transition-all ${
                d
                  ? "bg-emerald-500 border-emerald-500 text-zinc-900"
                  : "border-zinc-600 group-hover:border-emerald-500/60"
              }`}
            >
              {d ? "✓" : ""}
            </span>
            <span
              className={`text-[13px] transition-all ${d ? "line-through text-zinc-500" : "text-zinc-200"}`}
            >
              {it}
            </span>
          </button>
        );
      })}
      <div className="text-[10px] text-zinc-500 pt-1">
        {done.size}/{items.length} done
      </div>
    </div>
  );
}

function Progress({ pct, label }: { pct: number; label: string }) {
  return (
    <div className="my-2 rounded-xl border border-zinc-700 bg-zinc-900/60 p-3">
      <div className="flex justify-between text-[11px] mb-1.5">
        <span className="text-zinc-300 font-medium">{label || "Progress"}</span>
        <span className="text-yellow-400 font-bold">{pct}%</span>
      </div>
      <div className="h-2 rounded-full bg-zinc-800 overflow-hidden">
        <div
          className="h-full rounded-full bg-gradient-to-r from-yellow-400 to-amber-500 animate-shimmer-bg transition-all duration-700"
          style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
        />
      </div>
    </div>
  );
}

function Palette({ colors }: { colors: string[] }) {
  const [copied, setCopied] = useState<string | null>(null);
  return (
    <div className="my-2 flex flex-wrap gap-2">
      {colors.map((c, i) => (
        <button
          key={i}
          onClick={async () => {
            if (await copyText(c)) {
              setCopied(c);
              setTimeout(() => setCopied(null), 1200);
            }
          }}
          className="group rounded-xl overflow-hidden border border-zinc-700 active:scale-95 transition-all"
        >
          <div className="w-16 h-12" style={{ background: c }} />
          <div className="px-1.5 py-1 text-[10px] font-mono text-zinc-300 bg-zinc-900">
            {copied === c ? "✓ copied" : c}
          </div>
        </button>
      ))}
    </div>
  );
}

function Chart({ spec }: { spec: string }) {
  const items = spec
    .split(",")
    .map((s) => {
      const [k, v] = s.split("=");
      return { k: k?.trim(), v: Number(v) || 0 };
    })
    .filter((x) => x.k);
  const max = Math.max(...items.map((i) => i.v), 1);
  return (
    <div className="my-2 rounded-xl border border-zinc-700 bg-zinc-900/60 p-3 space-y-2">
      {items.map((it, i) => (
        <div key={i} className="flex items-center gap-2">
          <span className="text-[11px] text-zinc-300 w-20 truncate shrink-0">{it.k}</span>
          <div className="flex-1 h-4 rounded bg-zinc-800 overflow-hidden">
            <div
              className="h-full rounded bg-gradient-to-r from-violet-500 to-fuchsia-500 animate-grow-bar"
              style={{ width: `${(it.v / max) * 100}%` }}
            />
          </div>
          <span className="text-[11px] font-mono text-zinc-400 w-8 text-right">{it.v}</span>
        </div>
      ))}
    </div>
  );
}

function Timeline({ steps }: { steps: string[] }) {
  return (
    <div className="my-2 flex flex-wrap items-center gap-1">
      {steps.map((s, i) => (
        <div key={i} className="flex items-center gap-1">
          <div className="flex items-center gap-1.5 rounded-full border border-zinc-700 bg-zinc-900/70 pl-1.5 pr-2.5 py-1">
            <span className="w-5 h-5 rounded-full bg-yellow-400/15 text-yellow-400 text-[10px] font-bold flex items-center justify-center">
              {i + 1}
            </span>
            <span className="text-[12px] text-zinc-200">{s}</span>
          </div>
          {i < steps.length - 1 && <span className="text-zinc-600">→</span>}
        </div>
      ))}
    </div>
  );
}

function Table({ spec }: { spec: string }) {
  const rows = spec.split("|").map((r) => r.split(",").map((c) => c.trim()));
  if (!rows.length) return null;
  return (
    <div className="my-2 overflow-x-auto rounded-xl border border-zinc-700">
      <table className="w-full text-[12.5px]">
        <thead>
          <tr className="bg-zinc-800/80">
            {rows[0].map((h, i) => (
              <th key={i} className="px-3 py-2 text-left font-bold text-yellow-300/90">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.slice(1).map((r, i) => (
            <tr key={i} className="border-t border-zinc-800 hover:bg-zinc-800/40">
              {r.map((c, j) => (
                <td key={j} className="px-3 py-1.5 text-zinc-200">
                  {c}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Alert({ level, text }: { level: string; text: string }) {
  const styles: Record<string, string> = {
    info: "border-blue-500/40 bg-blue-950/30 text-blue-200",
    warn: "border-amber-500/40 bg-amber-950/30 text-amber-200",
    warning: "border-amber-500/40 bg-amber-950/30 text-amber-200",
    error: "border-red-500/40 bg-red-950/30 text-red-200",
    success: "border-emerald-500/40 bg-emerald-950/30 text-emerald-200",
  };
  const icons: Record<string, string> = {
    info: "ℹ️",
    warn: "⚠️",
    warning: "⚠️",
    error: "🚨",
    success: "✅",
  };
  return (
    <div
      className={`my-2 flex gap-2 rounded-xl border px-3 py-2.5 text-[13px] ${styles[level] || styles.info}`}
    >
      <span>{icons[level] || "ℹ️"}</span>
      <span>{text}</span>
    </div>
  );
}

function Stat({ label, value, delta }: { label: string; value: string; delta?: string }) {
  const up = delta?.startsWith("+");
  return (
    <div className="my-2 inline-flex flex-col rounded-xl border border-zinc-700 bg-zinc-900/70 px-4 py-2.5 mr-2">
      <span className="text-[10px] uppercase tracking-wider text-zinc-500">{label}</span>
      <span className="text-xl font-black text-zinc-100">{value}</span>
      {delta && (
        <span className={`text-[11px] font-bold ${up ? "text-emerald-400" : "text-red-400"}`}>
          {delta}
        </span>
      )}
    </div>
  );
}

function Toggle({ label, initial }: { label: string; initial: boolean }) {
  const [on, setOn] = useState(initial);
  return (
    <button
      onClick={() => setOn(!on)}
      className="my-2 flex items-center gap-2.5 rounded-xl border border-zinc-700 bg-zinc-900/70 px-3 py-2"
    >
      <span
        className={`w-9 h-5 rounded-full p-0.5 transition-colors ${on ? "bg-emerald-500" : "bg-zinc-700"}`}
      >
        <span
          className={`block w-4 h-4 rounded-full bg-white transition-transform ${on ? "translate-x-4" : ""}`}
        />
      </span>
      <span className="text-[13px] text-zinc-200">{label}</span>
      <span className={`text-[10px] font-bold ${on ? "text-emerald-400" : "text-zinc-500"}`}>
        {on ? "ON" : "OFF"}
      </span>
    </button>
  );
}

/* ---------- Tools used chips ---------- */
function ToolsChips({ tools }: { tools: string[] }) {
  return (
    <div className="my-2 flex items-center gap-1.5 flex-wrap">
      <span className="text-[10px] font-black tracking-widest uppercase text-zinc-500">
        🧰 Tools
      </span>
      {tools.map((t, i) => (
        <span
          key={i}
          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-violet-500/10 text-violet-300 border border-violet-500/25 animate-slide-in"
          style={{ animationDelay: `${i * 0.08}s` }}
        >
          ⚙ {t}
        </span>
      ))}
    </div>
  );
}

/* ---------- Tabs widget ---------- */
function TabsWidget({ spec }: { spec: string }) {
  const tabs = spec
    .split(";")
    .map((s) => {
      const idx = s.indexOf("=");
      if (idx === -1) return null;
      return { title: s.slice(0, idx).trim(), content: s.slice(idx + 1).trim() };
    })
    .filter((t): t is { title: string; content: string } => Boolean(t?.title));
  const [active, setActive] = useState(0);
  if (!tabs.length) return null;
  return (
    <div className="my-2.5 rounded-xl border border-zinc-700 bg-zinc-900/60 overflow-hidden">
      <div className="flex border-b border-zinc-800 overflow-x-auto scroll-thin">
        {tabs.map((t, i) => (
          <button
            key={i}
            onClick={() => setActive(i)}
            className={`px-4 py-2 text-[12px] font-bold whitespace-nowrap transition-all ${
              active === i
                ? "text-yellow-300 border-b-2 border-yellow-400 bg-yellow-500/5"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            {t.title}
          </button>
        ))}
      </div>
      <div className="px-4 py-3 text-[13px] text-zinc-200 leading-relaxed animate-slide-in" key={active}>
        {tabs[active].content}
      </div>
    </div>
  );
}

/* ---------- Accordion widget ---------- */
function AccordionWidget({ spec }: { spec: string }) {
  const items = spec
    .split(";")
    .map((s) => {
      const idx = s.indexOf("=");
      if (idx === -1) return null;
      return { title: s.slice(0, idx).trim(), body: s.slice(idx + 1).trim() };
    })
    .filter((t): t is { title: string; body: string } => Boolean(t?.title));
  const [open, setOpen] = useState<Set<number>>(new Set([0]));
  if (!items.length) return null;
  return (
    <div className="my-2.5 rounded-xl border border-zinc-700 bg-zinc-900/60 divide-y divide-zinc-800 overflow-hidden">
      {items.map((it, i) => {
        const isOpen = open.has(i);
        return (
          <div key={i}>
            <button
              onClick={() =>
                setOpen((p) => {
                  const n = new Set(p);
                  if (n.has(i)) n.delete(i);
                  else n.add(i);
                  return n;
                })
              }
              className="w-full flex items-center gap-2 px-4 py-2.5 text-left hover:bg-zinc-800/40 transition-colors"
            >
              <span
                className={`text-yellow-400 text-[11px] transition-transform ${isOpen ? "rotate-90" : ""}`}
              >
                ▶
              </span>
              <span className="text-[13px] font-semibold text-zinc-100">{it.title}</span>
            </button>
            {isOpen && (
              <div className="px-4 pb-3 pl-9 text-[12.5px] text-zinc-300 leading-relaxed animate-slide-in">
                {it.body}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ---------- Compare widget ---------- */
function CompareWidget({ spec }: { spec: string }) {
  const sides = spec
    .split("|")
    .map((s) => {
      const idx = s.indexOf("=");
      if (idx === -1) return null;
      return {
        title: s.slice(0, idx).trim(),
        points: s
          .slice(idx + 1)
          .split(",")
          .map((p) => p.trim())
          .filter(Boolean),
      };
    })
    .filter((t): t is { title: string; points: string[] } => Boolean(t?.title));
  if (sides.length < 2) return null;
  const colors = ["#facc15", "#60a5fa", "#34d399"];
  return (
    <div className="my-2.5 grid gap-2" style={{ gridTemplateColumns: `repeat(${Math.min(sides.length, 3)}, 1fr)` }}>
      {sides.slice(0, 3).map((s, i) => (
        <div
          key={i}
          className="rounded-xl border bg-zinc-900/60 p-3"
          style={{ borderColor: `${colors[i]}40` }}
        >
          <div
            className="text-[13px] font-black mb-2 pb-2 border-b"
            style={{ color: colors[i], borderColor: `${colors[i]}25` }}
          >
            {s.title}
          </div>
          <div className="space-y-1.5">
            {s.points.map((p, j) => (
              <div key={j} className="flex gap-1.5 text-[12px] text-zinc-300">
                <span style={{ color: colors[i] }}>✓</span>
                <span>{p}</span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------- Dispatcher ---------- */
/* ---------- Inline HTML live preview widget ---------- */
function HtmlPreviewWidget({ filename, content }: { filename: string; content: string }) {
  const [open, setOpen] = useState(true);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const { jumpToMonaco, files } = useAgent();

  // Write content to iframe
  useEffect(() => {
    if (!open) return;
    const fr = iframeRef.current;
    if (!fr) return;
    const doc = fr.contentDocument || fr.contentWindow?.document;
    if (!doc) return;
    doc.open(); doc.write(content); doc.close();
  }, [content, open]);

  const openInTab = () => {
    const blob = new Blob([content], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank");
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  };

  const openMonaco = () => {
    const f = files.find(x => x.filename === filename);
    if (f) jumpToMonaco(f);
  };

  return (
    <div className="my-3 rounded-2xl border border-blue-500/25 bg-zinc-900/70 overflow-hidden">
      <div className="flex items-center gap-2 px-3 py-2 border-b border-blue-500/20 bg-zinc-950">
        <span className="text-blue-400 text-sm">🌐</span>
        <span className="text-[11px] font-bold text-blue-300 uppercase tracking-widest">Live Preview</span>
        <span className="text-[10px] font-mono text-zinc-500">{filename}</span>
        <div className="ml-auto flex gap-1.5">
          <button onClick={openMonaco}
            className="px-2 py-0.5 rounded text-[10px] font-bold bg-zinc-800 text-yellow-400 hover:bg-zinc-700 transition-all">
            📂 Monaco
          </button>
          <button onClick={openInTab}
            className="px-2 py-0.5 rounded text-[10px] font-bold bg-zinc-800 text-zinc-300 hover:bg-zinc-700 transition-all">
            ↗ New tab
          </button>
          <button onClick={() => setOpen(o => !o)}
            className="px-2 py-0.5 rounded text-[10px] text-zinc-500 hover:text-zinc-300 transition-all">
            {open ? "▲ Hide" : "▼ Show"}
          </button>
        </div>
      </div>
      {open && (
        <iframe
          ref={iframeRef}
          className="w-full bg-white"
          style={{ height: "360px" }}
          sandbox="allow-scripts allow-modals"
          title={`Preview: ${filename}`}
        />
      )}
    </div>
  );
}

export default function Widget({
  kind,
  params,
  codeBlocks,
}: {
  kind: string;
  params: string;
  codeBlocks: CodeBlockData[];
}) {
  switch (kind) {
    case "choice":
    case "buttons":
      return (
        <MultiSelectWidget
          kind={kind}
          options={params.split(",").map((s) => s.trim()).filter(Boolean)}
        />
      );
    case "checklist":
      return <Checklist items={params.split(",").map((s) => s.trim()).filter(Boolean)} />;
    case "copy":
      return <CopyCard text={params} />;
    case "file":
      return <FileCard filename={params.trim()} codeBlocks={codeBlocks} />;
    case "progress": {
      const [pct, ...rest] = params.split(":");
      return <Progress pct={Number(pct) || 0} label={rest.join(":")} />;
    }
    case "color_palette":
      return <Palette colors={params.split(",").map((s) => s.trim()).filter(Boolean)} />;
    case "chart": {
      const [, ...rest] = params.split(":");
      return <Chart spec={rest.join(":") || params} />;
    }
    case "timeline":
      return <Timeline steps={params.split(",").map((s) => s.trim()).filter(Boolean)} />;
    case "table":
      return <Table spec={params} />;
    case "alert": {
      const [level, ...rest] = params.split(":");
      return <Alert level={level.trim()} text={rest.join(":").trim()} />;
    }
    case "stat": {
      const [label, value, delta] = params.split(":");
      return <Stat label={label} value={value || ""} delta={delta} />;
    }
    case "note": {
      const [title, ...rest] = params.split(":");
      return <Alert level="info" text={`${title}: ${rest.join(":")}`} />;
    }
    case "badge": {
      const [text, color] = params.split(":");
      return (
        <span
          className="inline-block my-1 mr-1 px-2 py-0.5 rounded-full text-[11px] font-bold"
          style={{
            background: `${color || "#facc15"}22`,
            color: color || "#facc15",
            border: `1px solid ${color || "#facc15"}55`,
          }}
        >
          {text}
        </span>
      );
    }
    case "link": {
      const idx = params.indexOf(":");
      const title = params.slice(0, idx);
      const url = params.slice(idx + 1).trim();
      let domain = "";
      try {
        domain = new URL(url).hostname.replace(/^www\./, "");
      } catch {}
      return (
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="my-2 flex items-center gap-2.5 rounded-xl border border-zinc-700 bg-zinc-900/70 px-3 py-2.5 hover:border-yellow-500/50 transition-colors group"
        >
          {domain && (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={`https://www.google.com/s2/favicons?domain=${domain}&sz=32`}
              alt=""
              className="w-5 h-5 rounded"
            />
          )}
          <span className="text-[13px] font-medium text-zinc-100 truncate flex-1">
            {title}
          </span>
          <span className="text-[11px] text-zinc-500 truncate max-w-[140px]">{domain}</span>
          <span className="text-zinc-500 group-hover:text-yellow-400 transition-colors">↗</span>
        </a>
      );
    }
    case "rating": {
      const n = Math.min(5, Math.max(0, Number(params) || 0));
      return (
        <div className="my-1 text-lg tracking-wider">
          {"★".repeat(n)}
          <span className="text-zinc-700">{"★".repeat(5 - n)}</span>
        </div>
      );
    }
    case "toggle": {
      const [label, state] = params.split(":");
      return <Toggle label={label} initial={state?.trim() === "on"} />;
    }
    case "tools":
      return (
        <ToolsChips
          tools={params.split(",").map((s) => s.trim()).filter(Boolean).slice(0, 6)}
        />
      );
    case "tabs":
      return <TabsWidget spec={params} />;
    case "accordion":
      return <AccordionWidget spec={params} />;
    case "compare":
      return <CompareWidget spec={params} />;
    case "preview": {
      // [WIDGET:preview:filename.html] — inline live HTML preview iframe
      const fname = params.trim();
      const block = codeBlocks.find(b => b.filename === fname || b.language === "html");
      if (!block) return null;
      return <HtmlPreviewWidget filename={fname} content={block.content} />;
    }
    default:
      // Unknown widget type — return null silently (no raw [kind:params] text leak)
      return null;
  }
}
