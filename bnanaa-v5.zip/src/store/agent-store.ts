"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { ReasoningEffort } from "@/lib/ai-providers";

export interface Settings {
  apiKey: string;
  groqKey: string;
  provider: "openrouter" | "groq";
  model: string;
  reasoningEffort: ReasoningEffort;
  thinkingEnabled: boolean;
}
export interface Session {
  id: number;
  title: string;
  model: string;
  status: string;
  createdAt: string;
  updatedAt: string;
}
export interface MessageMeta {
  code_files?: { filename: string; language: string }[];
  model_used?: string;
  usage?: { prompt_tokens?: number; completion_tokens?: number };
  demo?: boolean;
  sources?: { title: string; url: string; snippet: string; domain: string }[];
  reasoning?: string;
}
export interface Message {
  id: number;
  sessionId: number;
  role: string;
  content: string;
  messageType: string;
  metadata: MessageMeta;
  createdAt: string;
}
export interface AgentFile {
  id: number;
  sessionId: number;
  filename: string;
  content: string;
  language: string;
}
export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
  domain: string;
}
export interface SearchState {
  active: boolean;
  status: string;
  results: SearchResult[];
  done: boolean;
  queries?: string[];
  analysisReason?: string;
}
export interface Activity {
  id: number;
  text: string;
  time: string;
}

const DEF_SETTINGS: Settings = {
  apiKey: "",
  groqKey: "",
  provider: "groq",
  model: "llama-3.1-8b-instant",
  reasoningEffort: "medium",
  thinkingEnabled: true,
};

// Non-reactive module-level handles — zustand's get() already solves the stale-closure
// problem the old React Context needed curRef/abortRef workarounds for, but the abort
// controller itself genuinely doesn't belong in reactive state.
let abortController: AbortController | null = null;
let activityIdCounter = 0;

interface AgentState {
  settings: Settings;
  sessions: Session[];
  currentSession: Session | null;
  messages: Message[];
  files: AgentFile[];
  loading: boolean;
  phase: string;
  activities: Activity[];
  streamingText: string;
  reasoningText: string;
  totalTokens: number;
  search: SearchState;
  showSettings: boolean;
  activeTab: string;
  monacoOpen: boolean;
  monacoJumpFile: AgentFile | null;
}

interface AgentActions {
  setSettings: (s: Settings) => void;
  fetchSessions: () => Promise<void>;
  createSession: () => Promise<Session | null>;
  deleteSession: (id: number) => Promise<void>;
  selectSession: (s: Session | null) => void;
  sendMessage: (msg: string, mode?: string, webSearch?: boolean) => Promise<void>;
  stopGeneration: () => void;
  fetchFiles: () => Promise<void>;
  saveFile: (id: number, c: string) => Promise<void>;
  deleteFile: (id: number) => Promise<void>;
  setShowSettings: (v: boolean) => void;
  setActiveTab: (t: string) => void;
  hasKey: () => boolean;
  setMonacoOpen: (v: boolean) => void;
  jumpToMonaco: (file: AgentFile) => void;
}

type Store = AgentState & AgentActions;

export const useAgentStore = create<Store>()(
  persist(
    (set, get) => {
      const addActivity = (text: string) => {
        const time = new Date().toLocaleTimeString("en-IN", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: false,
        });
        set((s) => ({
          activities: [{ id: ++activityIdCounter, text, time }, ...s.activities].slice(0, 40),
        }));
      };

      const fetchMsgs = async (sid: number) => {
        try {
          const r = await fetch(`/api/messages?session_id=${sid}`);
          const d = await r.json();
          set({ messages: Array.isArray(d) ? d : [] });
        } catch {}
      };

      const analyzeMessage = async (
        msg: string,
        signal: AbortSignal
      ): Promise<{ need_search: boolean; queries: string[]; reason: string }> => {
        const { settings, messages } = get();
        // Pass last 6 messages so analyze can use conversation context
        const historySnippet = messages
          .filter(m => m.id > 0).slice(-6)
          .map(m => `${m.role === "user" ? "User" : "Agent"}: ${m.content.slice(0, 150)}`)
          .join("\n");
        try {
          const r = await fetch("/api/analyze", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              message: msg,
              history_snippet: historySnippet || undefined,
              api_key: settings.apiKey,
              groq_key: settings.groqKey,
              provider: settings.provider,
              model: settings.model,
            }),
            signal,
          });
          if (!r.ok) throw new Error("analyze failed");
          const d = await r.json();
          return {
            need_search: Boolean(d.need_search),
            queries: Array.isArray(d.queries) ? d.queries : [],
            reason: d.reason || "",
          };
        } catch {
          return { need_search: true, queries: [msg.slice(0, 90)], reason: "fallback" };
        }
      };

      const runSearch = async (
        queries: string[],
        signal: AbortSignal,
        reason?: string,
        append = false
      ): Promise<{ context: string; sources: SearchResult[] }> => {
        set((s) => ({
          search: {
            active: true,
            status: `🧭 ${queries.join(" · ")}`,
            results: append ? s.search.results : [],
            done: false,
            queries: append ? [...(s.search.queries || []), ...queries] : queries,
            analysisReason: reason,
          },
        }));
        addActivity("🌐 Live web search started");
        let context = "";
        let sources: SearchResult[] = [];
        try {
          const r = await fetch("/api/search", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ queries }),
            signal,
          });
          if (!r.ok || !r.body) throw new Error("search failed");
          const reader = r.body.getReader();
          const decoder = new TextDecoder();
          let buf = "";
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buf += decoder.decode(value, { stream: true });
            const lines = buf.split("\n");
            buf = lines.pop() || "";
            for (const line of lines) {
              if (!line.startsWith("data: ")) continue;
              try {
                const d = JSON.parse(line.slice(6));
                if (d.status)
                  set((s) => ({ search: { ...s.search, status: d.detail || d.status } }));
                if (d.result) {
                  set((s) => ({ search: { ...s.search, results: [...s.search.results, d.result] } }));
                  addActivity(`🔗 ${d.result.domain}`);
                }
                if (d.done) {
                  context = d.context || "";
                  if (Array.isArray(d.sources)) sources = d.sources;
                  set((s) => ({
                    search: {
                      ...s.search,
                      done: true,
                      status: `✅ ${d.count} sources · ${d.fetched || 0} pages read`,
                    },
                  }));
                  addActivity(`✅ Search done — ${d.count} sources, ${d.fetched || 0} pages read`);
                }
              } catch {}
            }
          }
        } catch {
          set((s) => ({ search: { ...s.search, done: true, status: "⚠️ Search unavailable" } }));
          addActivity("⚠️ Web search failed — continuing without it");
        }
        return { context, sources };
      };

      return {
        settings: DEF_SETTINGS,
        sessions: [],
        currentSession: null,
        messages: [],
        files: [],
        loading: false,
        phase: "idle",
        activities: [],
        streamingText: "",
        reasoningText: "",
        totalTokens: 0,
        search: { active: false, status: "", results: [], done: false },
        showSettings: false,
        activeTab: "chat",
        monacoOpen: false,
        monacoJumpFile: null,

        setSettings: (s) => set({ settings: s }),

        hasKey: () => {
          const { settings } = get();
          return Boolean(settings.provider === "groq" ? settings.groqKey : settings.apiKey);
        },

        fetchSessions: async () => {
          try {
            const r = await fetch("/api/sessions", { cache: "no-store" });
            const d = await r.json();
            set({ sessions: Array.isArray(d) ? d : [] });
          } catch {
            set({ sessions: [] });
          }
        },

        createSession: async () => {
          const { settings, fetchSessions } = get();
          try {
            const r = await fetch("/api/sessions", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ title: "New Session", model: settings.model }),
            });
            if (!r.ok) return null;
            const d = await r.json();
            await fetchSessions();
            set({ currentSession: d, messages: [], files: [] });
            addActivity("🆕 New session created");
            return d;
          } catch {
            return null;
          }
        },

        deleteSession: async (id) => {
          const { currentSession, fetchSessions } = get();
          try {
            await fetch("/api/sessions", {
              method: "DELETE",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ id }),
            });
            if (currentSession?.id === id) {
              set({ currentSession: null, messages: [], files: [] });
            }
            await fetchSessions();
          } catch {}
        },

        selectSession: (s) => {
          set({ currentSession: s });
          if (s) {
            fetchMsgs(s.id);
            get().fetchFiles();
          } else {
            set({ messages: [], files: [] });
          }
        },

        fetchFiles: async () => {
          const c = get().currentSession;
          if (!c) return;
          try {
            const r = await fetch(`/api/files?session_id=${c.id}`);
            const d = await r.json();
            set({ files: Array.isArray(d) ? d : [] });
          } catch {}
        },

        saveFile: async (id, c) => {
          try {
            await fetch("/api/files", {
              method: "PUT",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ id, content: c }),
            });
            await get().fetchFiles();
          } catch {}
        },

        deleteFile: async (id) => {
          try {
            await fetch("/api/files", {
              method: "DELETE",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ id }),
            });
            await get().fetchFiles();
          } catch {}
        },

        stopGeneration: () => {
          abortController?.abort();
          abortController = null;
        },

        setShowSettings: (v) => set({ showSettings: v }),
        setActiveTab: (t) => set({ activeTab: t }),
        setMonacoOpen: (v) => set({ monacoOpen: v }),
        jumpToMonaco: (file) => set({ monacoOpen: true, monacoJumpFile: file }),

        sendMessage: async (msg, mode = "normal", webSearch = false) => {
          let session = get().currentSession;
          if (!session) {
            session = await get().createSession();
            if (!session) return;
          }
          const { settings } = get();
          set({
            loading: true,
            phase: "thinking",
            streamingText: "",
            reasoningText: "",
            activities: [],
          });
          addActivity("🧠 Thinking…");
          if (!webSearch) set({ search: { active: false, status: "", results: [], done: false } });

          // optimistic user bubble
          const optimistic: Message = {
            id: -Date.now(),
            sessionId: session.id,
            role: "user",
            content: msg,
            messageType: "text",
            metadata: {},
            createdAt: new Date().toISOString(),
          };
          set((s) => ({ messages: [...s.messages, optimistic] }));

          const controller = new AbortController();
          abortController = controller;

          let accumulated = "";
          try {
            let searchCtx = "";
            let searchSources: SearchResult[] = [];
            const isSmallTalk =
              /^(hi+|hii+|hello+|hey+|yo+|sup|namaste|thanks?|thank you|ok+|okay|hmm+|good (morning|night|evening)|kaise ho|kya haal|wassup|how are you)[\s!.?]*$/i.test(
                msg.trim()
              ) || msg.trim().split(/\s+/).length < 2;

            if (webSearch && isSmallTalk) {
              addActivity("💬 Small-talk detected — search skipped");
            } else if (webSearch) {
              set({ phase: "analyzing" });
              addActivity("🔬 Analyzing your message…");
              set({ search: { active: true, status: "🔬 Analyzing what to search…", results: [], done: false } });
              const plan = await analyzeMessage(msg, controller.signal);

              if (!plan.need_search) {
                addActivity(`🧠 No search needed — ${plan.reason || "answering directly"}`);
                set({ search: { active: false, status: "", results: [], done: false } });
              } else {
                addActivity(`🧭 Search plan: ${plan.queries.map((q) => `"${q}"`).join(", ")}`);
                set({ phase: "searching" });
                let queries = plan.queries;
                const allSources: SearchResult[] = [];
                const seenUrls = new Set<string>();
                const ctxParts: string[] = [];
                const allQueries: string[] = [];
                const MAX_ROUNDS = 3;

                for (let round = 1; round <= MAX_ROUNDS; round++) {
                  if (round > 1)
                    addActivity(`🔁 Round ${round}: ${queries.map((q) => `"${q}"`).join(", ")}`);
                  allQueries.push(...queries);
                  const sr = await runSearch(
                    queries,
                    controller.signal,
                    round === 1 ? plan.reason : `Round ${round} — refining`,
                    round > 1
                  );
                  for (const s of sr.sources) {
                    if (!seenUrls.has(s.url)) {
                      seenUrls.add(s.url);
                      allSources.push(s);
                    }
                  }
                  if (sr.context) ctxParts.push(`--- ROUND ${round} ---\n${sr.context}`);

                  if (round === MAX_ROUNDS) break;

                  set({ phase: "analyzing" });
                  addActivity(`🔬 Evaluating ${allSources.length} sources…`);
                  try {
                    const rr = await fetch("/api/analyze", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({
                        message: msg,
                        api_key: settings.apiKey,
                        groq_key: settings.groqKey,
                        provider: settings.provider,
                        model: settings.model,
                        prior: {
                          queries: allQueries,
                          results: allSources.slice(0, 15).map((s) => ({
                            title: s.title,
                            snippet: s.snippet,
                            domain: s.domain,
                          })),
                        },
                      }),
                      signal: controller.signal,
                    });
                    const refine = await rr.json();
                    if (refine.sufficient || !refine.queries?.length) {
                      addActivity(`✅ Coverage complete — ${refine.reason || "enough sources"}`);
                      break;
                    }
                    addActivity(`🧭 Gap found: ${refine.reason || "refining queries"}`);
                    queries = refine.queries;
                    set({ phase: "searching" });
                  } catch {
                    break;
                  }
                }

                searchSources = allSources;
                searchCtx = ctxParts.join("\n\n");
                if (searchCtx) {
                  searchCtx = `SEARCH PLAN (agentic, ${allQueries.length} queries across rounds): ${allQueries.join("; ")}\nReason: ${plan.reason}\n\n${searchCtx}`;
                }
                set((s) => ({
                  search: { ...s.search, done: true, status: `✅ ${allSources.length} sources · ${allQueries.length} queries` },
                }));
              }
            }

            const history = get()
              .messages.filter((m) => m.id > 0)
              .slice(-12)
              .map((m) => ({ role: m.role, content: m.content }));

            const r = await fetch("/api/agent", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                session_id: session.id,
                message: msg,
                api_key: settings.apiKey,
                groq_key: settings.groqKey,
                provider: settings.provider,
                model: settings.model,
                reasoning_effort: settings.reasoningEffort,
                thinking_enabled: settings.thinkingEnabled,
                history,
                mode,
                search_results: searchCtx,
                search_sources: searchSources,
              }),
              signal: controller.signal,
            });
            if (!r.ok || !r.body) {
              const e = await r.json().catch(() => ({ error: "Request failed" }));
              throw new Error(e.error || "Request failed");
            }

            const reader = r.body.getReader();
            const decoder = new TextDecoder();
            let buf = "";

            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              buf += decoder.decode(value, { stream: true });
              const lines = buf.split("\n");
              buf = lines.pop() || "";
              for (const line of lines) {
                if (!line.startsWith("data: ")) continue;
                let d: Record<string, unknown>;
                try {
                  d = JSON.parse(line.slice(6));
                } catch {
                  continue;
                }
                if (typeof d.token === "string") {
                  accumulated += d.token;
                  set({ streamingText: accumulated });
                }
                if (typeof d.reasoning_token === "string") {
                  set((s) => ({ reasoningText: s.reasoningText + d.reasoning_token }));
                }
                if (typeof d.phase === "string") {
                  set({ phase: d.phase });
                  if (typeof d.detail === "string") addActivity(d.detail);
                }
                if (typeof d.activity === "string") addActivity(d.activity);
                if (typeof d.error === "string") throw new Error(d.error);
                if (d.complete) {
                  const usage = d.usage as
                    | { prompt_tokens?: number; completion_tokens?: number }
                    | undefined;
                  if (usage) {
                    const t = (usage.prompt_tokens || 0) + (usage.completion_tokens || 0);
                    set((s) => ({ totalTokens: s.totalTokens + t }));
                    addActivity(`📊 ${t} tokens used`);
                  }
                  const cf = d.code_files as { filename: string }[] | undefined;
                  cf?.forEach((f) => addActivity(`📄 ${f.filename} ready`));
                  if (d.reasoning_used) addActivity("🧠 Native reasoning tokens used");
                }
              }
            }

            set({ streamingText: "", reasoningText: "", phase: "complete" });
            addActivity("✅ Response complete");
            let dbFetched = false;
            try {
              await fetchMsgs(session.id);
              dbFetched = true;
            } catch {
              // If DB fetch fails, keep the streamed content in local state
            }
            if (!dbFetched && accumulated) {
              const agentBubble: Message = {
                id: -2,
                sessionId: session.id,
                role: "agent",
                content: accumulated,
                messageType: "agent_response",
                metadata: {},
                createdAt: new Date().toISOString(),
              };
              set((s) => ({ messages: [...s.messages.filter((m) => m.id > 0), agentBubble] }));
            }
            try {
              await get().fetchFiles();
            } catch {
              /* ignore */
            }
          } catch (err) {
            const e = err as Error;
            if (e.name === "AbortError") {
              addActivity("⏹ Stopped by user");
              set({ phase: "idle" });
            } else {
              set({ phase: "error" });
              addActivity(`❌ ${e.message}`);
              const errBubble: Message = {
                id: -Date.now(),
                sessionId: session!.id,
                role: "system",
                content: `❌ Error: ${e.message}\n\nPlease try again. Check your API key in ⚙️ Settings if the problem persists.`,
                messageType: "error",
                metadata: {},
                createdAt: new Date().toISOString(),
              };
              set((s) => ({ messages: [...s.messages.filter((m) => m.id > 0), errBubble] }));
            }
            set({ streamingText: "", reasoningText: "" });
          } finally {
            set({ loading: false });
            abortController = null;
            setTimeout(() => set({ phase: "idle" }), 3000);
          }
        },
      };
    },
    {
      name: "banana_s3",
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({ settings: state.settings }) as Store,
      merge: (persisted, current) => ({
        ...current,
        settings: { ...DEF_SETTINGS, ...(persisted as { settings?: Partial<Settings> })?.settings },
      }),
    }
  )
);

/** Kept as an alias so existing component code (`useAgent()`) doesn't need renaming. */
export const useAgent = useAgentStore;
