import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  meta,
  partners,
  vows,
  memoryTabs,
  memoryItems,
  pings,
} from "@/db/schema";
import { eq, desc, asc } from "drizzle-orm";
import { randomUUID } from "crypto";
import { VOW_SEED, PARTNER_META, UNLOCK_DATE, type PartnerId } from "@/lib/data";

export const dynamic = "force-dynamic";

async function seed() {
  await db.insert(meta).values({ id: 1 }).onConflictDoNothing();
  for (const id of ["nik", "rumi"] as PartnerId[]) {
    await db
      .insert(partners)
      .values({
        id,
        realName: PARTNER_META[id].realName,
        nickname: PARTNER_META[id].nickname,
      })
      .onConflictDoNothing();
  }
  const existing = await db.select().from(vows);
  if (existing.length === 0) {
    let i = 1;
    for (const v of VOW_SEED) {
      await db
        .insert(vows)
        .values({ id: i, authorId: v.authorId, ord: v.ord, text: v.text });
      i++;
    }
  }
  const tabs = await db.select().from(memoryTabs);
  if (tabs.length === 0) {
    await db
      .insert(memoryTabs)
      .values({ id: "tab-first", name: "Pehli Yaadein", ord: 0 });
  }
}

type PartnerRow = typeof partners.$inferSelect;

async function fullState() {
  await seed();
  const [m] = await db.select().from(meta).where(eq(meta.id, 1));
  const ps = await db.select().from(partners);
  const vs = (await db.select().from(vows).orderBy(asc(vows.id))).map((v) => ({
    ...v,
    respondedAt: v.respondedAt ? v.respondedAt.toISOString() : null,
  }));
  const tabs = (
    await db.select().from(memoryTabs).orderBy(asc(memoryTabs.ord))
  ).map((t) => ({ ...t }));
  const rawItems = await db
    .select()
    .from(memoryItems)
    .orderBy(desc(memoryItems.createdAt));
  const items = rawItems.map((it) => ({
    id: it.id,
    tabId: it.tabId,
    authorId: it.authorId as PartnerId,
    kind: it.kind as "text" | "image" | "video" | "voice",
    body: it.body,
    locked: it.locked,
    createdAt: it.createdAt.toISOString(),
  }));
  const rawPings = await db
    .select()
    .from(pings)
    .orderBy(desc(pings.createdAt))
    .limit(12);
  const pingList = rawPings.map((p) => ({
    id: p.id,
    fromId: p.fromId as PartnerId,
    seen: p.seen,
  }));
  const partnerMap: Record<PartnerId, PartnerRow> = {
    nik: ps.find((x) => x.id === "nik")!,
    rumi: ps.find((x) => x.id === "rumi")!,
  };
  return {
    ready: true,
    unlocked: m?.unlocked ?? false,
    ringPlaced: m?.ringPlaced ?? false,
    completedAt: m?.completedAt ? m.completedAt.toISOString() : null,
    partners: partnerMap,
    vows: vs,
    tabs,
    items,
    pings: pingList,
  };
}

export async function GET(
  req: NextRequest,
  ctx: { params: Promise<{ action: string }> }
) {
  const { action } = await ctx.params;
  if (action !== "state") {
    return NextResponse.json({ ok: false, error: "unknown" }, { status: 404 });
  }
  try {
    const state = await fullState();
    return NextResponse.json(state);
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}

export async function POST(
  req: NextRequest,
  ctx: { params: Promise<{ action: string }> }
) {
  const { action } = await ctx.params;
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  try {
    await seed();
    switch (action) {
      case "unlock": {
        if (body.date !== UNLOCK_DATE) {
          return NextResponse.json(
            { ok: false, error: "Galat date. Phir se socho, dil se." },
            { status: 403 }
          );
        }
        await db.update(meta).set({ unlocked: true }).where(eq(meta.id, 1));
        return NextResponse.json({ ok: true });
      }
      case "select": {
        const who = body.who as PartnerId;
        if (who !== "nik" && who !== "rumi")
          return NextResponse.json({ ok: false }, { status: 400 });
        const [row] = await db.select().from(partners).where(eq(partners.id, who));
        const linkCode = row?.linkCode ?? randomUUID().slice(0, 12);
        await db
          .update(partners)
          .set({ selected: true, linkCode })
          .where(eq(partners.id, who));
        return NextResponse.json({ ok: true, linkCode });
      }
      case "accept": {
        const code = String(body.code ?? "");
        const [owner] = await db
          .select()
          .from(partners)
          .where(eq(partners.linkCode, code));
        if (!owner)
          return NextResponse.json(
            { ok: false, error: "Ye link valid nahi hai." },
            { status: 404 }
          );
        const viewerId = (owner.id === "nik" ? "rumi" : "nik") as PartnerId;
        await db
          .update(partners)
          .set({ acceptedByPartner: true })
          .where(eq(partners.id, owner.id));
        const [viewer] = await db
          .select()
          .from(partners)
          .where(eq(partners.id, viewerId));
        if (viewer && !viewer.selected) {
          const linkCode = randomUUID().slice(0, 12);
          await db
            .update(partners)
            .set({ selected: true, linkCode })
            .where(eq(partners.id, viewerId));
        }
        return NextResponse.json({ ok: true, ownerId: owner.id, viewerId });
      }
      case "vow": {
        const id = Number(body.vowId);
        const response =
          body.response === "yes" ? "yes" : body.response === "no" ? "no" : null;
        await db
          .update(vows)
          .set({ response, respondedAt: response ? new Date() : null })
          .where(eq(vows.id, id));
        return NextResponse.json({ ok: true });
      }
      case "ring": {
        await db
          .update(meta)
          .set({ ringPlaced: true, completedAt: new Date() })
          .where(eq(meta.id, 1));
        return NextResponse.json({ ok: true });
      }
      case "tab-new": {
        const name = String(body.name ?? "").trim().slice(0, 40);
        if (!name) return NextResponse.json({ ok: false }, { status: 400 });
        const tabs = await db.select().from(memoryTabs);
        const tab = { id: `tab-${randomUUID().slice(0, 8)}`, name, ord: tabs.length };
        await db.insert(memoryTabs).values(tab);
        return NextResponse.json({ ok: true, tab });
      }
      case "item-new": {
        const kind = String(body.kind);
        const bodyStr = String(body.body ?? "");
        if (bodyStr.length > 4_500_000) {
          return NextResponse.json(
            { ok: false, error: "File bahut badi hai (max ~3MB)." },
            { status: 413 }
          );
        }
        const item = {
          id: `mem-${randomUUID().slice(0, 10)}`,
          tabId: String(body.tabId),
          authorId: String(body.authorId),
          kind,
          body: bodyStr,
          locked: Boolean(body.locked),
          lockCode: body.lockCode ? String(body.lockCode) : null,
        };
        await db.insert(memoryItems).values(item);
        return NextResponse.json({ ok: true, id: item.id });
      }
      case "item-check": {
        const [it] = await db
          .select()
          .from(memoryItems)
          .where(eq(memoryItems.id, String(body.id)));
        if (!it) return NextResponse.json({ ok: false }, { status: 404 });
        const ok = it.lockCode === String(body.code);
        return NextResponse.json({ ok });
      }
      case "ping": {
        const fromId = String(body.fromId);
        await db.insert(pings).values({ fromId });
        return NextResponse.json({ ok: true });
      }
      case "ping-seen": {
        const viewer = String(body.viewer);
        const all = await db.select().from(pings).where(eq(pings.seen, false));
        for (const p of all) {
          if (p.fromId !== viewer) {
            await db.update(pings).set({ seen: true }).where(eq(pings.id, p.id));
          }
        }
        return NextResponse.json({ ok: true });
      }
      default:
        return NextResponse.json(
          { ok: false, error: "unknown action" },
          { status: 404 }
        );
    }
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
