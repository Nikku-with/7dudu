import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Nik & Rumi — Hamari Shaadi",
  description:
    "Nikhil weds Rashmika · 13 September 2026 · ek choti si duniya, sirf hum dono ki.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="hi">
      <body className="antialiased min-h-screen">{children}</body>
    </html>
  );
}
