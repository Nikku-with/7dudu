"use client";
import { useEffect, useRef, useState } from "react";
import { post, useIdentity, useWeddingState } from "@/lib/api";
import { other, PARTNER_META, type PartnerId } from "@/lib/data";
import { IconHeart, Petals, ToastHost, pushToast } from "@/components/bits";
import {
  AcceptScreen,
  IdentitySelect,
  LockScreen,
  WeddingLinkCard,
  Welcome,
} from "@/components/Onboarding";
import { Certificate, ChatWall } from "@/components/WeddingStory";
import { CompletionOverlay, RingCeremony, Vows } from "@/components/Ceremony";
import { Memories } from "@/components/Memories";

export default function Home() {
  const { state, refresh } = useWeddingState();
  const [identity, setIdentity] = useIdentity();
  const [welcomed, setWelcomed] = useState(false);
  const [tab, setTab] = useState<"shaadi" | "yaadein">("shaadi");
  const [showComplete, setShowComplete] = useState(false);

  const [acceptCode] = useState<string | null>(() => {
    if (typeof window === "undefined") return null;
    return new URLSearchParams(window.location.search).get("accept");
  });
  const [focusId] = useState<string | null>(() => {
    if (typeof window === "undefined") return null;
    return new URLSearchParams(window.location.search).get("m");
  });
  const [acceptDone, setAcceptDone] = useState(false);

  useEffect(() => {
    setWelcomed(localStorage.getItem("nr_welcomed") === "1");
    if (focusId) setTab("yaadein");
  }, [focusId]);

  // completion overlay triggers once per device
  useEffect(() => {
    if (state?.ringPlaced && localStorage.getItem("nr_seen_complete") !== "1") {
      setShowComplete(true);
    }
  }, [state?.ringPlaced]);

  // live ping watcher
  const lastPing = useRef<number>(0);
  useEffect(() => {
    if (!state || !identity) return;
    const fresh = state.pings.filter(
      (p) => !p.seen && p.fromId !== identity && p.id > lastPing.current
    );
    if (fresh.length > 0) {
      lastPing.current = Math.max(...state.pings.map((p) => p.id));
      pushToast(`${PARTNER_META[fresh[0].fromId].nickname} ne aapko pyaar se ping kiya.`, "rose");
      void post("ping-seen", { viewer: identity });
    } else if (state.pings.length) {
      lastPing.current = Math.max(lastPing.current, ...state.pings.map((p) => p.id));
    }
  }, [state, identity]);

  if (!state) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-maroon-deep">
        <IconHeart className="w-12 h-12 text-gold-soft anim-heart" />
        <p className="font-script text-3xl text-cream">Nik &amp; Rumi</p>
        <p className="text-xs tracking-widest text-gold-soft/70 uppercase">Duniya load ho rahi hai…</p>
      </div>
    );
  }

  if (!state.unlocked) {
    return (
      <>
        <LockScreen onUnlocked={() => void refresh()} />
        <ToastHost />
      </>
    );
  }

  if (acceptCode && !acceptDone) {
    return (
      <>
        <AcceptScreen
          code={acceptCode}
          state={state}
          onDone={(viewer: PartnerId) => {
            setIdentity(viewer);
            setAcceptDone(true);
            window.history.replaceState({}, "", window.location.pathname);
            void refresh();
          }}
        />
        <ToastHost />
      </>
    );
  }

  if (!welcomed) {
    return (
      <>
        <Welcome
          onDone={() => {
            localStorage.setItem("nr_welcomed", "1");
            setWelcomed(true);
          }}
        />
        <ToastHost />
      </>
    );
  }

  if (!identity) {
    return (
      <>
        <IdentitySelect
          onSelected={(p) => {
            setIdentity(p);
            void refresh();
          }}
        />
        <ToastHost />
      </>
    );
  }

  const them = other(identity);
  const mutual =
    state.partners.nik.acceptedByPartner && state.partners.rumi.acceptedByPartner;

  return (
    <div className="paper relative min-h-screen pb-24">
      <Petals count={10} />
      <ToastHost />

      {showComplete ? (
        <CompletionOverlay
          onClose={() => {
            localStorage.setItem("nr_seen_complete", "1");
            setShowComplete(false);
          }}
        />
      ) : null}

      {/* header */}
      <header className="sticky top-0 z-40 border-b border-gold/40 bg-cream/90 backdrop-blur">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-3 px-4 py-3">
          <div className="flex items-center gap-2">
            <IconHeart className="w-6 h-6 text-rose anim-heart" />
            <p className="font-script text-3xl leading-none text-maroon">Nik &amp; Rumi</p>
          </div>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-green-800/10 px-3 py-1 text-[11px] font-bold tracking-wide text-green-900 uppercase">
            <span className="h-1.5 w-1.5 rounded-full bg-green-700 anim-blink" /> live synced
          </span>
          {state.completedAt ? (
            <span className="rounded-full bg-maroon px-3 py-1 text-[11px] font-bold tracking-wide text-gold-soft uppercase">
              Shaadi poori · 13·09·2026
            </span>
          ) : null}
          <nav className="ml-auto flex items-center gap-2">
            {(
              [
                ["shaadi", "Hamari Shaadi"],
                ["yaadein", "Yaadein"],
              ] as ["shaadi" | "yaadein", string][]
            ).map(([k, label]) => (
              <button
                key={k}
                type="button"
                onClick={() => setTab(k)}
                className={`rounded-full px-4 py-2 font-display text-sm font-semibold transition ${
                  tab === k ? "bg-maroon text-cream shadow" : "text-maroon hover:bg-cream-2"
                }`}
              >
                {label}
              </button>
            ))}
            <span className="hidden rounded-full border border-gold/60 bg-cream-2 px-3 py-1.5 text-xs font-bold text-maroon sm:inline">
              {PARTNER_META[identity].nickname} · {PARTNER_META[identity].realName}
            </span>
          </nav>
        </div>
      </header>

      <main className="relative z-20 mx-auto max-w-5xl px-4 pt-10">
        {tab === "shaadi" ? (
          <div className="space-y-4">
            <div className="text-center">
              <p className="anim-fade-up font-script text-5xl text-rose sm:text-6xl">
                {PARTNER_META[identity].nickname}, swagat hai aapki duniya mein
              </p>
              <p className="mt-2 font-display text-lg italic text-maroon">
                {PARTNER_META.nik.realName} ♥ {PARTNER_META.rumi.realName} · 13 September 2026
              </p>
            </div>

            <div className="mt-8">
              <WeddingLinkCard state={state} identity={identity} />
            </div>

            <div className="mt-16">
              <Certificate />
            </div>

            <ChatWall />

            <Vows state={state} identity={identity} mutual={mutual} />

            <RingCeremony
              state={state}
              identity={identity}
              onPlaced={() => void refresh()}
            />
          </div>
        ) : (
          <Memories
            state={state}
            identity={identity}
            focusId={focusId}
            onPing={() => {
              void post("ping", { fromId: identity }).then(() => {
                pushToast(`${PARTNER_META[them].nickname} ko ping chala gaya.`, "gold");
                void refresh();
              });
            }}
          />
        )}
      </main>

      <footer className="relative z-20 mt-16 text-center text-xs text-ink/50">
        <p className="font-script text-2xl text-rose/70">Nikhil ♥ Rashmika</p>
        <p>Ek choti si duniya, sirf hum dono ki · made with pyaar</p>
      </footer>
    </div>
  );
}
