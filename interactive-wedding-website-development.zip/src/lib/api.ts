"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import type { PartnerId } from "./data";

export type PartnerState = {
  id: PartnerId;
  realName: string;
  nickname: string;
  selected: boolean;
  linkCode: string | null;
  acceptedByPartner: boolean;
};

export type VowState = {
  id: number;
  authorId: PartnerId;
  ord: number;
  text: string;
  response: "yes" | "no" | null;
  respondedAt: string | null;
};

export type TabState = { id: string; name: string; ord: number };

export type ItemState = {
  id: string;
  tabId: string;
  authorId: PartnerId;
  kind: "text" | "image" | "video" | "voice";
  body: string;
  locked: boolean;
  createdAt: string;
};

export type PingState = { id: number; fromId: PartnerId; seen: boolean };

export type FullState = {
  ready: boolean;
  unlocked: boolean;
  ringPlaced: boolean;
  completedAt: string | null;
  partners: Record<PartnerId, PartnerState>;
  vows: VowState[];
  tabs: TabState[];
  items: ItemState[];
  pings: PingState[];
};

export async function post<T = Record<string, unknown>>(
  action: string,
  body?: Record<string, unknown>
): Promise<T & { ok: boolean }> {
  const res = await fetch(`/api/${action}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body ?? {}),
  });
  const data = (await res.json()) as T & { ok: boolean };
  if (!res.ok) throw new Error(data?.ok ? "" : "request failed");
  return data;
}

export function useWeddingState() {
  const [state, setState] = useState<FullState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/state", { cache: "no-store" });
      const data = (await res.json()) as FullState;
      setState(data);
      setError(null);
    } catch {
      setError("Server se connect nahi ho paya, dobara koshish ho rahi hai…");
    }
  }, []);

  useEffect(() => {
    void refresh();
    timer.current = setInterval(() => void refresh(), 2500);
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [refresh]);

  return { state, refresh, error };
}

export function useIdentity(): [PartnerId | null, (p: PartnerId | null) => void] {
  const [id, setId] = useState<PartnerId | null>(null);
  useEffect(() => {
    const v = localStorage.getItem("nr_identity");
    if (v === "nik" || v === "rumi") setId(v);
  }, []);
  const set = useCallback((p: PartnerId | null) => {
    if (p) localStorage.setItem("nr_identity", p);
    else localStorage.removeItem("nr_identity");
    setId(p);
  }, []);
  return [id, set];
}
