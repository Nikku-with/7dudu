export const UNLOCK_DATE = "2026-05-03"; // 3 May 2026 — the key to the door
export const WEDDING_DATE_LABEL = "13 September 2026";

export const GIF_RING_1 =
  "https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExY3ZsYW42YXhydWJ5N2JraGMxaTk2bnl1bDNva2YxZTRiMW9kMjdociZlcD12MV9naWZzX3RyZW5kaW5nJmN0PWc/kZqbBT64ECtjy/giphy.gif";
export const GIF_RING_2 =
  "https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNGc1NzNzbzRoZnBtNmVtZmM0ZjI2Z2Y0djRia2V6ZmFyNWlsczVneiZlcD12MV9naWZzX3NlYXJjaCZjdD1n/UJG50B8TJD5Mk/giphy.gif";

export type PartnerId = "nik" | "rumi";

export const PARTNER_META: Record<
  PartnerId,
  { realName: string; nickname: string; label: string }
> = {
  nik: { realName: "Nikhil Mehra", nickname: "Nik", label: "Main Nik hoon" },
  rumi: {
    realName: "Rashmika Mehra",
    nickname: "Rumi",
    label: "Main Rumi hoon",
  },
};

export const other = (p: PartnerId): PartnerId => (p === "nik" ? "rumi" : "nik");

// ---- Vachan (vows). authorId = jisne vachan diya, doosra partner accept karta hai.
export const VOW_SEED: { authorId: PartnerId; ord: number; text: string }[] = [
  {
    authorId: "rumi",
    ord: 1,
    text: "Hum ek dusre se naraz ho sakte hain, but baat na karke choti si problem ko kabhi bhi bada nahi karenge. Main ya aap — jo galat ho gaalti maan kar sorry bol denge, aur ek hi topic pe argument nahi karenge unless it's necessary.",
  },
  {
    authorId: "rumi",
    ord: 2,
    text: "Jab bhi apne beech koi misunderstanding hogi hum baat karke solve karenge, chup rehke door nahi jayenge. Busy hone pe aake bol denge ki kuch kaam hai, ignore nahi kar rahi. Aur kitna bhi busy day ho, hum ek dusre ke liye time nikalne ki puri koshish karenge.",
  },
  {
    authorId: "rumi",
    ord: 3,
    text: "Hum ek dusre ki feelings ki hamesha respect karenge, equal efforts pay karenge. Gusse mein kabhi bhi ek dusre ko hurt karne wale words nahi bolenge.",
  },
  {
    authorId: "rumi",
    ord: 4,
    text: "Hum hamesha ek dusre pe trust banaye rakhenge, kabhi bhi usse break nahi karenge. Ek dusre ko samajhne ki koshish karenge, change karne ke bajaye. Jhuth nahi bolenge — jo bhi hoga aake sach bol denge, chahe wo kaisa bhi ho. Apna rishta jhuth ke base pe nahi chalega.",
  },
  {
    authorId: "nik",
    ord: 1,
    text: "Ladayi ke beech mein ek dusre ko ignore ya 'farq nahi padta' wali baatein nahi bolenge. Bina baat kiye off chale jana band. Hum jhuth kabhi nahi bolenge. Agar thoda bhi lage ki main ignore kar raha hoon toh ab aisa nahi lagega — ye meri galtiyon ke karan lagta tha, ab main dhyan rakhunga. Rishte mein balance rakhunga, aur kuch bhi ho jaye, meri gaalti par bhi main aapke paas aaoonga.",
  },
  {
    authorId: "nik",
    ord: 2,
    text: "Main aapka saath nahi chodoonga, jab tak aap meri taraf se kisi bhi type ki waisi harkat na karein. Main breakup ki baat lekar aapse kabhi wapas baat nahi karunga — aapko iski puri zindagi need nahi padni chahiye. Iska main khyal rakhunga.",
  },
  {
    authorId: "nik",
    ord: 3,
    text: "Humari private chats, humari personal baatein, humare DM mein ki gayi koi bhi baat hum kabhi bhi kisi ko share nahi karenge. Ladayi ho jaye ya kuch bhi — khud se solve karenge, kabhi kisi aur se kuch nahi bolenge. Bas.",
  },
];

// ---- Original chat transcript, line by line, jaise bheja gaya tha.
export type ChatMsg = {
  from: PartnerId;
  time: string;
  text: string;
  replyTo?: string;
};

export const CHAT_TRANSCRIPT: ChatMsg[] = [
  {
    from: "rumi",
    time: "9:11 PM",
    text: "Ham ek dusre se naraz ho sakte h but baat na krke choti si prblm ko kbhi bhi bada nhi karenge me ya aap glti maan kr sorry bol denge aur ek hi topic pe argument nhi krnge unless it's necessary😝😝😝🎀",
  },
  {
    from: "rumi",
    time: "9:12 PM",
    text: "Jab bhi apne bich koi misunderstanding hogi ham baat krke solve krenge chup rhke dur ny jayenge aur busy hone pe aake bol denge ki kuch kam h ignore nhi kr rhi/rha aur kitna bhi busy day ho ham ek dusre ke liye tem nikalne ki puri koshish krenge (aap apne dost ke sath thoda kam ghumo bby)",
  },
  {
    from: "rumi",
    time: "9:12 PM",
    text: "Ham ek dusre ki feelings ki hamesha respect karenge equal efforts pay krenge gusse m kbhi bhi ek dusre ko hurt krne vale words nhi bolenge",
  },
  {
    from: "rumi",
    time: "9:12 PM",
    text: "Ham ek dusre se naraz ho sakte h but baat na krke choti si prblm ko kbhi bhi bada nhi karenge me ya aap glti maan kr sorry bol denge aur ek hi topic pe argument nhi krnge unless it's necessary",
  },
  {
    from: "rumi",
    time: "9:12 PM",
    text: "Ham hamesha ek dusre pe trust banaye rkhenge kbhi bhi usko break nhi karenge sath hi ek dusre ko smjhne ki koshi karenge change krne ke bajaye jhuth nhi bolenge jo bhi hoga aake sach bol denge chahe vo fir kaisa bhi ho apna rishta jhuth ke base pr nhi chalega😝☝🏻",
  },
  {
    from: "nik",
    time: "9:48 PM",
    replyTo: "Rumii",
    text: "Mai nikhil mehra aaj 13.sep.2026 ko ye likh rha hu 😋 kyuki aaj meri aur meri jo hone wali wifey hai rashmika mehra banne wali hai 😈👆🏻 toh ab shadi ke pehle mai kuch vachan lunga and kuch baatein share krunga and kuch bolunga jo meri bawnii wifey rumi ko apne mai change krni hogi. Sabse pehle toh ye ki hum dono kaafi abnormal behave krne lag jate 😭💔 ladayi ke bheech mai jaise dono ek dusre ke kuch lagte ho na ho ya frk na padta ho esi faltu ki bkc krne lagte wo sab khtm krna. And ladayi jo whi na khtm krne ki jgh hum badhate rehte aur 😔 aur baar baar off chlew jate hai jisse fir baat bhi nhi krte aur fir sab khrab hojata 😭 and abse ye nhi ho mai ye chata hu and bby aap bhi esa kuch na kro ye dhyan rakhna ignore na krna, abnormal jaise like frk ni padta aapse ye wo kyuki wo hurt krta ngl bolte nhi khudka silly attitude ko upar rkhne ke liye ik 😭💔 bby hum juth nhi bolenge bss kabhi bhi 😡😡 aake bolenge kaha hai kitna time lgega ye wo. And aapko agar thoda bhi lagta hai mai ignore krta aapko toh abse nhi lagega meri hi gltiyo ke karan lagta 😭👆 mai bhi lodu hu thoda sa. And bby ye hogya pehla vachan. And 2nd hai ki aap merse bhut hi jyada rudely baat krti kabhi kabhi gusse mai, wo aapko nhi malum padta pr mai kilas bhi jata aur meko hurt v hota 😭 bby. And aapne merse jhut bola tha ki aap ladko se baat ni kr rhi 😔 wo rls mai hoke bhi aap kr hi rhi thi. Aapne bola only ek gc mai hu ladko se baat ni krri and wagera wagera ki saare bhaiya bhabhi hai uss gc mai. Ye cheez maine bby aap pr trust krke maan li thi, chalo itna trust kr skta pr uss time breakup hogya tha toh kuch pucha bhi nhi maine. Toh pr apna breakup 2 din chala dhang se then patchup hogya 😭🥀 bhut achi baat hai but uss time maine id kholi toh dekha ki rls mai the uske bhi pehle se aap baat toh kr rhi thi. And maine jitne bhi ladke bataye aapne kaha sab dost hai toh wo sab 2 din mai toh banne nhi hoge itne? 😭 Toh bby aap jhut bolna band krdo pls inn cheezo mai. And kuch bhi hai aap merko batao na, mai aapko kha thodi jaunga 😭 agar abhi bhi kuch ho toh bata dena pls kyuki mai viswaas nhi kr pata abhi bhi, uske liye sorry meko krna chiye pr nhi krta 1% bhi mai 😭💔🥀 kyuki aap jhut pakde janne ke baad off ese bhagti ho, kya bolu, replies bhi waise dene lag jati aap rude se 😔🥀 and aap jhut bolne lag jati, and aap jhut toh har baar hi bolti ho kya bolu 😭 bss ye chodd do bby, baaki mai aapke har cheez har nakhre aapki gulami krne ko bhi taiyar hu. Mai aapse waada krta hu ki rls mai balanced rkhunga, kuch bhi ho jaye tab bhi mai aaunga aapko, meri glti pr v aaunga. Pr mai jesa chata hu wesi aap ban toh jaaw 🤭 oki bby???? Haa aur wo ek cheez — aap ab koi v msg aayega toh meko bataogi. Male friends abhi jaha tk meko aap pr trust nhi, ek bhi nhi banaogi na kisi se baat krogi aap, kyuki aap wesi ny ho ki aapko kisi ladke se baat krne de saku as a friend bhi. So nhi krogi aap kisi ladke se baat ya ye rls nhi chlegaw mere sath toh 😈👆 pr aap nahi krogi ab, aap meri wifey ban gyi ho aur shyd achi v ban gyi ho thodi toh 🤭 samjhne lagi ho cheezo ko thoda. {{{{ BBY SORRY YE WALI CHEEZE REMIND KRNE KE LIYE PR JRURI THA HADS SE JYADA 🤧🫰🏻 }}}} Btw ab vachan aur promises ka alag likhunga, ye to bkc krdi maine 🤣🤣",
  },
  {
    from: "nik",
    time: "9:51 PM",
    text: "Vachan ye hai ki aapka sath nhi chodunga bby aap jaha tk na merse kisi bhi type ki waisi harkate krti. And mai aapse breakup thing ko lekar wapas kabhi baat ny krunga — agar krri toh maan lena chakka tha chala gay 😭💔 ye bol dena achha lagega merko, pr aap ko iski puri zindagi need na pade bolne ki, iska mai khyal rakhunga bby 💋🎀 btw I love you so muchhhh myy love rummiiii 🤭🤭",
  },
  {
    from: "nik",
    time: "9:54 PM",
    text: "Hum humari private chats, hum humari personal baatein, humari talks, humare dm mai ki gyi kesi bhi kuch bhi baat hum kabhi bhi kisi ko kabhi bhi share nhi krenge. Ladayi hoajye ya kuch bhi, khudse solve karenge, kabhi kisi aur se kuch nhi bolenge. Bss.",
  },
];

export const WEDDING_IMAGES = [
  { src: "/images/bigday.jpg", caption: "The Big Day" },
  { src: "/images/varmala.png", caption: "Varmala — haan, hamesha ke liye" },
  { src: "/images/pheras.png", caption: "Saat phere, saat vaade" },
  { src: "/images/sindoor.png", caption: "Sindoor — ab Mehra" },
];
