import {
  pgTable,
  text,
  boolean,
  integer,
  timestamp,
  serial,
} from "drizzle-orm/pg-core";

// Singleton row that holds global ceremony state
export const meta = pgTable("meta", {
  id: integer("id").primaryKey().default(1),
  unlocked: boolean("unlocked").notNull().default(false),
  ringPlaced: boolean("ring_placed").notNull().default(false),
  completedAt: timestamp("completed_at"),
});

// The two partners: 'nik' and 'rumi'
export const partners = pgTable("partners", {
  id: text("id").primaryKey(),
  realName: text("real_name").notNull(),
  nickname: text("nickname").notNull(),
  selected: boolean("selected").notNull().default(false),
  linkCode: text("link_code"),
  acceptedByPartner: boolean("accepted_by_partner").notNull().default(false),
});

// Vachan / vows. authorId = who gave the vow, the OTHER partner responds.
export const vows = pgTable("vows", {
  id: integer("id").primaryKey(),
  authorId: text("author_id").notNull(),
  ord: integer("ord").notNull(),
  text: text("text").notNull(),
  response: text("response"), // 'yes' | 'no' | null
  respondedAt: timestamp("responded_at"),
});

// Memory boards (tabs)
export const memoryTabs = pgTable("memory_tabs", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  ord: integer("ord").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Items inside a memory board: text note, photo, video, voice note
export const memoryItems = pgTable("memory_items", {
  id: text("id").primaryKey(),
  tabId: text("tab_id").notNull(),
  authorId: text("author_id").notNull(),
  kind: text("kind").notNull(), // text | image | video | voice
  body: text("body").notNull().default(""),
  locked: boolean("locked").notNull().default(false),
  lockCode: text("lock_code"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Live pings between partners
export const pings = pgTable("pings", {
  id: serial("id").primaryKey(),
  fromId: text("from_id").notNull(),
  seen: boolean("seen").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
