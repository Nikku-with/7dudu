"use client";
import { useState } from "react";
import { post, type FullState } from "@/lib/api";
import { PARTNER_META, UNLOCK_DATE, type PartnerId } from "@/lib/data";
import {
  IconCheck,
  IconHeart,
  IconLink,
  IconLock,
  IconX,
  Petals,
  pushToast,
  CopyButton,
} from "./bits";

/* ------------------------- 1. DATE LOCK ------------------------- */
export function LockScreen({ onUnlocked }: { onUnlocked: () => void }) {
  const [date, setDate] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function tryUnlock() {
    setBusy(true);
    setErr(null);
    try {
      const res = await post("unlock", { date });
      if (res.ok) {
        pushToast("Taala khul gaya. Swagat hai.", "gold");
        onUnlocked();
      }
    } catch {
      setErr("Galat date. Ye sirf hum dono ki duniya hai.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-maroon-deep px-4">
      <div
        className="pointer-events-none absolute inset-0 opacity-30"
        style={{
          background:
            "radial-gradient(700px 380px at 50% 12%, rgba(227,200,126,0.35), transparent 60%), radial-gradient(900px 500px at 50% 110%, rgba(156,58,71,0.55), transparent 65%)",
        }}
      />
      <div className="anim-spin-slow pointer-events-none absolute -top-40 left-1/2 h-[560px] w-[560px] -translate-x-1/2 rounded-full border border-gold/25" />
      <div className="anim-spin-slow pointer-events-none absolute -top-24 left-1/2 h-[380px] w-[380px] -translate-x-1/2 rounded-full border border-gold/20 [animation-direction:reverse]" />

      <div className="anim-fade-up relative w-full max-w-md rounded-3xl border border-gold/50 bg-cream/95 p-8 text-center shadow-2xl ornate-frame">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full border border-gold/60 bg-maroon text-gold-soft anim-glow">
          <IconLock className="w-7 h-7" />
        </div>
        <p className="font-script text-4xl text-rose">Nik &amp; Rumi</p>
        <h1 className="font-display mt-1 text-xl font-semibold tracking-widest text-maroon-deep uppercase">
          Private Wedding World
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-ink/75">
          Ye darwaza sirf unke liye khulta hai jo jaante hain — wo din, jab humne
          decide kiya ki hamesha saath chalenge. Sahi date daalo, taala khulega.
        </p>

        <label className="mt-6 block text-left text-xs font-semibold tracking-widest text-maroon uppercase">
          Humari date
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="mt-2 w-full rounded-xl border border-gold/60 bg-cream px-4 py-3 font-display text-lg text-maroon-deep outline-none focus:border-maroon"
          />
        </label>
        <p className="mt-2 text-[11px] italic text-ink/50">
          Hint: May 2026 ka wo din jo sirf hum jaante hain.
        </p>

        {err ? (
          <p className="anim-pop mt-3 rounded-lg bg-rose/15 px-3 py-2 text-sm font-medium text-maroon">
            {err}
          </p>
        ) : null}

        <button
          type="button"
          disabled={busy || !date}
          onClick={() => void tryUnlock()}
          className="mt-5 w-full rounded-xl bg-maroon px-6 py-3.5 font-display text-lg font-semibold tracking-wide text-cream shadow-lg transition hover:bg-maroon-soft active:scale-[0.98] disabled:opacity-40"
        >
          {busy ? "Khul raha hai…" : "Taala kholo"}
        </button>
      </div>
    </div>
  );
}

/* ------------------------- 2. WELCOME WALL ------------------------- */
export function Welcome({ onDone }: { onDone: () => void }) {
  return (
    <div className="paper relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-4 py-10">
      <Petals count={22} />
      <div className="anim-pop relative z-20 w-full max-w-sm overflow-hidden rounded-2xl border-2 border-gold shadow-2xl">
        <img src="/images/bigday.jpg" alt="Nikhil and Rashmika — The Big Day" className="w-full" />
      </div>
      <p className="anim-fade-up relative z-20 mt-8 font-display text-lg tracking-[0.4em] text-maroon-soft uppercase [animation-delay:0.5s]">
        Welcome to
      </p>
      <h1 className="gold-shimmer relative z-20 font-script text-6xl leading-tight sm:text-7xl [animation-delay:0.8s] anim-fade-up">
        Nik &amp; Rumi World
      </h1>
      <p className="anim-fade-up relative z-20 mt-3 font-display text-xl italic text-maroon [animation-delay:1.1s]">
        13 · 09 · 2026 — jahan do dil ek hue
      </p>
      <button
        type="button"
        onClick={onDone}
        className="anim-fade-up relative z-20 mt-8 inline-flex items-center gap-2 rounded-full bg-maroon px-8 py-3.5 font-display text-lg font-semibold text-cream shadow-xl transition hover:bg-maroon-soft active:scale-95 [animation-delay:1.5s]"
      >
        <IconHeart className="w-5 h-5 text-gold-soft anim-heart" />
        Andar aao
      </button>
    </div>
  );
}

/* ------------------------- 3. IDENTITY SELECT ------------------------- */
export function IdentitySelect({
  onSelected,
}: {
  onSelected: (p: PartnerId, linkCode: string) => void;
}) {
  const [busy, setBusy] = useState<PartnerId | null>(null);

  async function pick(p: PartnerId) {
    setBusy(p);
    try {
      const res = await post<{ linkCode: string }>("select", { who: p });
      onSelected(p, res.linkCode);
      pushToast(`${PARTNER_META[p].nickname} ke roop mein andar aa gaye.`, "gold");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="paper relative flex min-h-screen flex-col items-center justify-center px-4 py-12">
      <Petals count={14} />
      <p className="font-script relative z-20 text-4xl text-rose">Pehle ye batao…</p>
      <h1 className="relative z-20 font-display text-3xl font-semibold text-maroon-deep">
        Aap kaun ho, jaan?
      </h1>
      <p className="relative z-20 mt-2 max-w-md text-center text-sm text-ink/70">
        Apna naam chuno — phir aapki apni wedding link banegi jo aap apne partner
        ko bhejoge. Jab wo accept karega, shaadi aage badhegi. Live.
      </p>

      <div className="relative z-20 mt-10 grid w-full max-w-2xl gap-6 sm:grid-cols-2">
        {(["nik", "rumi"] as PartnerId[]).map((p, i) => (
          <button
            key={p}
            type="button"
            disabled={busy !== null}
            onClick={() => void pick(p)}
            className={`anim-fade-up group overflow-hidden rounded-2xl border-2 border-gold/70 bg-cream text-left shadow-xl transition hover:-translate-y-1 hover:shadow-2xl active:scale-[0.98] disabled:opacity-50 ${
              i === 0 ? "[animation-delay:0.15s]" : "[animation-delay:0.3s]"
            }`}
          >
            <div className="h-52 overflow-hidden">
              <img
                src={p === "nik" ? "/images/pheras.png" : "/images/sindoor.png"}
                alt={PARTNER_META[p].realName}
                className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
              />
            </div>
            <div className="p-5">
              <p className="font-script text-3xl text-rose">{PARTNER_META[p].nickname}</p>
              <p className="font-display text-lg font-semibold text-maroon-deep">
                {PARTNER_META[p].realName}
              </p>
              <p className="mt-1 text-xs tracking-widest text-gold-deep uppercase">
                {busy === p ? "Link ban rahi hai…" : PARTNER_META[p].label}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ------------------------- 4. LINK CARD + ACCEPT ------------------------- */
export function WeddingLinkCard({
  state,
  identity,
}: {
  state: FullState;
  identity: PartnerId;
}) {
  const me = state.partners[identity];
  const them = state.partners[identity === "nik" ? "rumi" : "nik"];
  const myLink = me.linkCode ? `${window.location.origin}/?accept=${me.linkCode}` : "";
  const mutual = me.acceptedByPartner && them.acceptedByPartner;

  return (
    <div className="ornate-frame rounded-2xl bg-cream p-6">
      <div className="flex items-center gap-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-maroon text-gold-soft">
          <IconLink className="w-5 h-5" />
        </span>
        <div>
          <h3 className="font-display text-xl font-semibold text-maroon-deep">
            Wedding Link — {them.nickname} ko bhejo
          </h3>
          <p className="text-xs text-ink/65">
            Jab {them.nickname} accept karega, dono ko live dikhega.
          </p>
        </div>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-3">
        <code className="min-w-0 flex-1 truncate rounded-lg border border-gold/50 bg-cream-2 px-3 py-2 text-xs text-maroon">
          {myLink || "Link ban rahi hai…"}
        </code>
        {myLink ? <CopyButton value={myLink} label="Link copy karo" /> : null}
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        <StatusPill
          ok={them.acceptedByPartner}
          label={
            them.acceptedByPartner
              ? `${them.nickname} ne aapki link accept kar li`
              : `${them.nickname} abhi tak accept nahi kiya`
          }
        />
        <StatusPill
          ok={me.acceptedByPartner}
          label={
            me.acceptedByPartner
              ? `Aapne ${them.nickname} ki link accept kar li`
              : `Aapne ${them.nickname} ki link accept nahi ki`
          }
        />
      </div>

      {mutual ? (
        <p className="anim-pop mt-4 flex items-center gap-2 rounded-xl bg-green-800/10 px-4 py-3 text-sm font-semibold text-green-900">
          <IconCheck className="w-5 h-5" />
          Dono taraf se accept — ab vachan khul gaye.
        </p>
      ) : null}
    </div>
  );
}

function StatusPill({ ok, label }: { ok: boolean; label: string }) {
  return (
    <div
      className={`flex items-center gap-2 rounded-xl border px-4 py-3 text-sm font-medium ${
        ok
          ? "border-green-700/40 bg-green-800/10 text-green-900"
          : "border-gold/40 bg-cream-2 text-ink/70"
      }`}
    >
      {ok ? (
        <IconCheck className="w-4 h-4 shrink-0" />
      ) : (
        <span className="h-2 w-2 shrink-0 rounded-full bg-rose anim-blink" />
      )}
      {label}
    </div>
  );
}

export function AcceptScreen({
  code,
  state,
  onDone,
}: {
  code: string;
  state: FullState;
  onDone: (viewer: PartnerId) => void;
}) {
  const owner =
    state.partners.nik.linkCode === code
      ? state.partners.nik
      : state.partners.rumi.linkCode === code
        ? state.partners.rumi
        : null;
  const [busy, setBusy] = useState(false);
  const [invalid, setInvalid] = useState(false);

  async function accept() {
    if (!owner) return;
    setBusy(true);
    try {
      const res = await post<{ viewerId: PartnerId }>("accept", { code });
      if (res.ok) {
        pushToast(`${owner.nickname} ki wedding link accept ho gayi.`, "rose");
        onDone(res.viewerId);
      } else {
        setInvalid(true);
      }
    } catch {
      setInvalid(true);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="paper relative flex min-h-screen items-center justify-center px-4">
      <Petals count={16} />
      <div className="anim-pop relative z-20 w-full max-w-md rounded-3xl border-2 border-gold bg-cream p-8 text-center shadow-2xl">
        {!owner ? (
          <>
            <IconX className="mx-auto w-10 h-10 text-rose" />
            <h1 className="mt-3 font-display text-2xl font-semibold text-maroon-deep">
              Ye link valid nahi hai
            </h1>
            <p className="mt-2 text-sm text-ink/70">
              Shayad purani hai ya tooti hui. Apne partner se nayi link lo.
            </p>
          </>
        ) : (
          <>
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-maroon text-gold-soft anim-heart">
              <IconHeart className="w-8 h-8" />
            </div>
            <p className="mt-4 font-script text-4xl text-rose">{owner.nickname} ki taraf se</p>
            <h1 className="mt-1 font-display text-2xl font-semibold text-maroon-deep">
              {owner.realName} ne aapko wedding link bheji hai
            </h1>
            <p className="mt-3 text-sm leading-relaxed text-ink/75">
              Is link ko accept karne ka matlab hai — aap is shaadi mein apni jagah
              pakki kar rahe ho, vachan nibhaoge, haath thhaamoge. Pakka?
            </p>
            {invalid ? (
              <p className="mt-3 text-sm font-medium text-rose">Kuch gadbad hui, dobara try karo.</p>
            ) : null}
            <div className="mt-6 flex gap-3">
              <button
                type="button"
                onClick={() => onDone(owner.id === "nik" ? "rumi" : "nik")}
                className="flex-1 rounded-xl border border-gold/60 px-4 py-3 font-display font-semibold text-maroon transition hover:bg-cream-2"
              >
                Abhi nahi
              </button>
              <button
                type="button"
                disabled={busy}
                onClick={() => void accept()}
                className="flex-1 rounded-xl bg-maroon px-4 py-3 font-display font-semibold text-cream shadow-lg transition hover:bg-maroon-soft active:scale-95 disabled:opacity-50"
              >
                {busy ? "Soch raha hoon…" : "Haan, accept hai"}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
