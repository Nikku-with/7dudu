"use client";
import { useEffect, useRef, useState } from "react";
import confetti from "canvas-confetti";
import { post, type FullState, type VowState } from "@/lib/api";
import { CHAT_TRANSCRIPT, GIF_RING_1, GIF_RING_2, other, PARTNER_META, type PartnerId } from "@/lib/data";
import { IconCheck, IconLock, IconRing, IconX, SectionTitle, pushToast } from "./bits";

/* ============================ VACHAN ============================ */
export function Vows({
  state,
  identity,
  mutual,
}: {
  state: FullState;
  identity: PartnerId;
  mutual: boolean;
}) {
  async function respond(v: VowState, r: "yes" | "no") {
    await post("vow", { vowId: v.id, response: r });
    pushToast(
      r === "yes"
        ? `Aapne ${PARTNER_META[v.authorId as PartnerId].nickname} ka vachan sweekar kiya.`
        : "Aapne abhi mana kiya — jab dil kahe, phir sochna.",
      r === "yes" ? "gold" : "rose"
    );
  }

  if (!mutual) {
    return (
      <section className="mt-20">
        <SectionTitle script="vachan" title="Saat Vaade" />
        <div className="mx-auto mt-8 flex max-w-md flex-col items-center gap-3 rounded-2xl border border-gold/50 bg-cream p-8 text-center shadow-lg">
          <IconLock className="w-8 h-8 text-maroon" />
          <p className="font-display text-lg font-semibold text-maroon-deep">Vachan abhi band hain</p>
          <p className="text-sm text-ink/70">
            Pehle dono ko ek dusre ki wedding link accept karni hogi. Tabhi vaade khulenge.
          </p>
        </div>
      </section>
    );
  }

  const forMe = state.vows.filter((v) => v.authorId !== identity);
  const mine = state.vows.filter((v) => v.authorId === identity);
  const them = other(identity);

  return (
    <section className="mt-20">
      <SectionTitle
        script="kya ye vaade nibhaoge?"
        title="Vachan — Ek Ek Karke"
        sub={`${PARTNER_META[them].nickname} ke vaade aapke liye. Haan ya na — aapka jawab ${PARTNER_META[them].nickname} ko live dikhega.`}
      />

      <div className="mx-auto mt-8 max-w-2xl space-y-4">
        {forMe.map((v, i) => (
          <div key={v.id} className="anim-fade-up rounded-2xl border border-gold/50 bg-cream p-5 shadow-md" style={{ animationDelay: `${i * 0.12}s` }}>
            <div className="flex items-center justify-between gap-2">
              <p className="text-xs font-bold tracking-widest text-rose uppercase">
                {PARTNER_META[v.authorId as PartnerId].nickname} ka vachan {v.ord}
              </p>
              <ResponseBadge response={v.response} who="aapka jawab" />
            </div>
            <p className="mt-2 text-[15px] leading-relaxed text-ink/90">“{v.text}”</p>
            {v.response !== "yes" ? (
              <div className="mt-4 flex gap-3">
                <button
                  type="button"
                  onClick={() => void respond(v, "yes")}
                  className="flex-1 rounded-xl bg-maroon px-4 py-2.5 font-display font-semibold text-cream shadow transition hover:bg-maroon-soft active:scale-95"
                >
                  Haan, nibhaunga/nibhaungi
                </button>
                <button
                  type="button"
                  onClick={() => void respond(v, "no")}
                  className="rounded-xl border border-rose/50 px-4 py-2.5 font-display font-semibold text-rose transition hover:bg-rose/10 active:scale-95"
                >
                  Na
                </button>
              </div>
            ) : null}
          </div>
        ))}
      </div>

      <div className="mx-auto mt-10 max-w-2xl">
        <h3 className="text-center font-display text-xl font-semibold text-maroon-deep">
          Aapke vaade — {PARTNER_META[them].nickname} ka jawab (live)
        </h3>
        <div className="mt-4 space-y-3">
          {mine.map((v) => (
            <div key={v.id} className="flex items-center justify-between gap-3 rounded-xl border border-gold/40 bg-cream-2 px-4 py-3">
              <p className="line-clamp-2 text-sm text-ink/80">“{v.text}”</p>
              <ResponseBadge response={v.response} who={`${PARTNER_META[them].nickname}`} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ResponseBadge({ response, who }: { response: VowState["response"]; who: string }) {
  if (response === "yes")
    return (
      <span className="anim-pop inline-flex shrink-0 items-center gap-1 rounded-full bg-green-800/15 px-3 py-1 text-xs font-bold text-green-900">
        <IconCheck className="w-3.5 h-3.5" /> {who}: Haan
      </span>
    );
  if (response === "no")
    return (
      <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-rose/15 px-3 py-1 text-xs font-bold text-rose">
        <IconX className="w-3.5 h-3.5" /> {who}: Na
      </span>
    );
  return (
    <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-cream-3/70 px-3 py-1 text-xs font-semibold text-ink/60">
      <span className="h-1.5 w-1.5 rounded-full bg-gold anim-blink" /> {who}: soch raha hai…
    </span>
  );
}

/* ============================ RING ============================ */
export function RingCeremony({
  state,
  identity,
  onPlaced,
}: {
  state: FullState;
  identity: PartnerId;
  onPlaced: () => void;
}) {
  const allYes = state.vows.length > 0 && state.vows.every((v) => v.response === "yes");
  const them = other(identity);
  const nameOnHand = identity === "rumi" ? "Nikhil" : "Rashmika";

  if (!allYes) {
    return (
      <section className="mt-20">
        <SectionTitle script="angoothi" title="The Ring" />
        <div className="mx-auto mt-8 flex max-w-md flex-col items-center gap-3 rounded-2xl border border-gold/50 bg-cream p-8 text-center shadow-lg">
          <IconRing className="w-8 h-8 text-maroon" />
          <p className="font-display text-lg font-semibold text-maroon-deep">Angoothi abhi thaali mein hai</p>
          <p className="text-sm text-ink/70">Jab saare vachan dono taraf se “haan” honge, tab ye ring pehni jayegi.</p>
        </div>
      </section>
    );
  }

  return (
    <section className="mt-20">
      <SectionTitle
        script="haath thhaam lo"
        title="Ring Pehnao"
        sub={
          state.ringPlaced
            ? "Angoothi pehen chuki hai — ye haath ab hamesha ke liye."
            : `Ring ko pakdo aur ${PARTNER_META[identity].nickname === "Rumi" ? "apni" : "Rumi"} ki ring finger tak kheench kar le jao.`
        }
      />
      <div className="mt-8 flex justify-center">
        <HandWithRing placed={state.ringPlaced} nameOnHand={nameOnHand} onPlaced={onPlaced} partnerFirst={PARTNER_META[them].realName.split(" ")[0]} />
      </div>
    </section>
  );
}

function HandWithRing({
  placed,
  nameOnHand,
  onPlaced,
  partnerFirst,
}: {
  placed: boolean;
  nameOnHand: string;
  onPlaced: () => void;
  partnerFirst: string;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const handRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const [snapped, setSnapped] = useState(placed);
  const started = useRef(false);

  useEffect(() => {
    if (wrapRef.current && !started.current) {
      started.current = true;
      const r = wrapRef.current.getBoundingClientRect();
      setPos({ x: r.width / 2 - 32, y: r.height - 84 });
    }
  }, []);

  useEffect(() => setSnapped(placed), [placed]);

  function targetPoint() {
    const wrap = wrapRef.current?.getBoundingClientRect();
    const hand = handRef.current?.getBoundingClientRect();
    if (!wrap || !hand) return null;
    return {
      x: hand.left - wrap.left + hand.width * (130 / 320),
      y: hand.top - wrap.top + hand.height * (150 / 420),
    };
  }

  function onPointerDown(e: React.PointerEvent) {
    if (snapped) return;
    (e.target as Element).setPointerCapture(e.pointerId);
    setDragging(true);
  }
  function onPointerMove(e: React.PointerEvent) {
    if (!dragging || snapped) return;
    const wrap = wrapRef.current?.getBoundingClientRect();
    if (!wrap) return;
    setPos({ x: e.clientX - wrap.left - 32, y: e.clientY - wrap.top - 32 });
  }
  function onPointerUp() {
    if (!dragging) return;
    setDragging(false);
    const t = targetPoint();
    if (t) {
      const cx = pos.x + 32;
      const cy = pos.y + 32;
      const d = Math.hypot(cx - t.x, cy - t.y);
      if (d < 46) {
        setSnapped(true);
        setPos({ x: t.x - 32, y: t.y - 22 });
        onPlaced();
        return;
      }
    }
    const r = wrapRef.current?.getBoundingClientRect();
    if (r) setPos({ x: r.width / 2 - 32, y: r.height - 84 });
  }

  return (
    <div ref={wrapRef} className="relative h-[480px] w-full max-w-sm select-none">
      {/* thaali */}
      {!snapped ? (
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 rounded-full border-2 border-gold/70 bg-gold-soft/30 px-10 py-3 text-center">
          <p className="text-[11px] font-bold tracking-widest text-gold-deep uppercase">Ring ki thaali — yahan se pakdo</p>
        </div>
      ) : null}

      {/* hand */}
      <div ref={handRef} className="absolute left-1/2 top-0 w-[300px] -translate-x-1/2">
        <svg viewBox="0 0 320 420" className="w-full drop-shadow-xl">
          <g fill="#eab78e" stroke="#b97f52" strokeWidth="2">
            <rect x="70" y="128" width="34" height="120" rx="17" />
            <rect x="112" y="92" width="36" height="156" rx="18" />
            <rect x="156" y="82" width="36" height="166" rx="18" />
            <rect x="200" y="98" width="34" height="150" rx="17" />
            <rect x="228" y="238" width="38" height="104" rx="19" transform="rotate(28 247 290)" />
            <rect x="64" y="214" width="176" height="156" rx="46" />
          </g>
          {/* mehndi vines on fingers */}
          <g stroke="#7a1f2b" strokeWidth="2" fill="none" opacity="0.75">
            <path d="M130 108v60M174 98v70M217 112v58M87 142v44" strokeDasharray="1 7" strokeLinecap="round" />
            <circle cx="130" cy="196" r="5" />
            <circle cx="174" cy="196" r="5" />
            <circle cx="217" cy="196" r="5" />
          </g>
          {/* palm mandala */}
          <g stroke="#7a1f2b" fill="none" opacity="0.8">
            <circle cx="152" cy="296" r="44" strokeWidth="1.5" />
            <circle cx="152" cy="296" r="34" strokeWidth="1.2" strokeDasharray="3 5" />
            {Array.from({ length: 12 }, (_, i) => {
              const a = (i * Math.PI) / 6;
              return (
                <path
                  key={i}
                  d={`M${152 + Math.cos(a) * 44} ${296 + Math.sin(a) * 44} q ${Math.cos(a) * 8} ${Math.sin(a) * 8} 0 0`}
                  strokeWidth="2"
                />
              );
            })}
            <circle cx="152" cy="296" r="4" fill="#7a1f2b" stroke="none" />
          </g>
          {/* name written on hand */}
          <text x="152" y="300" textAnchor="middle" fontFamily="'Great Vibes', cursive" fontSize="30" fill="#521220">
            {nameOnHand}
          </text>
          <text x="152" y="322" textAnchor="middle" fontFamily="'Cormorant Garamond', serif" fontSize="11" letterSpacing="3" fill="#7a1f2b">
            WEDS {partnerFirst.toUpperCase()}
          </text>
        </svg>
      </div>

      {/* ring */}
      <div
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        className={`absolute z-20 h-16 w-16 ${snapped ? "" : "cursor-grab active:cursor-grabbing"} ${dragging ? "scale-110" : ""} transition-transform`}
        style={{ left: pos.x, top: pos.y, touchAction: "none" }}
      >
        <svg viewBox="0 0 64 64" className={`w-full drop-shadow-lg ${snapped ? "anim-pop" : dragging ? "" : "anim-float"}`}>
          <circle cx="32" cy="40" r="16" fill="none" stroke="#c19a3f" strokeWidth="7" />
          <circle cx="32" cy="40" r="16" fill="none" stroke="#e3c87e" strokeWidth="2.5" />
          <path d="M24 22 32 10l8 12-8 8z" fill="#b3405a" stroke="#7a1f2b" strokeWidth="1.5" />
          <path d="M32 10v20M24 22h16" stroke="#f8f2e7" strokeWidth="1" opacity="0.7" />
        </svg>
      </div>
    </div>
  );
}

/* ============================ COMPLETION ============================ */
const FINALE_LINES = [
  "Nikhil Mehra aur Rashmika Mehra — ab ek naam, ek ghar, ek kahani.",
  "Hum ek dusre se naraz ho sakte hain, par door kabhi nahi jayenge.",
  "Jhuth nahi, bas sach — chahe jaisa bhi ho.",
  "Private baatein private rahengi, hamesha.",
  "Gusse mein bhi hurt karne wale shabd nahi.",
  "Busy din mein bhi ek dusre ke liye time.",
  "I love you so muchhhh, my love Rummii.",
  "Aapka saath nahi chodunga — ye mera aakhri vachan.",
  "13 · 09 · 2026 — hamari shaadi poori hui.",
];

export function CompletionOverlay({ onClose }: { onClose: () => void }) {
  const [phase, setPhase] = useState<0 | 1 | 2>(0);
  const [shown, setShown] = useState(1);

  useEffect(() => {
    const t1 = window.setTimeout(() => setPhase(1), 4200);
    const t2 = window.setTimeout(() => setPhase(2), 8400);
    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    };
  }, []);

  useEffect(() => {
    if (phase !== 2) return;
    const burst = () => {
      confetti({ particleCount: 90, spread: 80, origin: { y: 0.6 }, colors: ["#7a1f2b", "#c19a3f", "#e3c87e", "#b3405a"] });
    };
    burst();
    const iv = window.setInterval(burst, 1400);
    const reveal = window.setInterval(() => {
      setShown((s) => Math.min(s + 1, FINALE_LINES.length + CHAT_TRANSCRIPT.length));
    }, 900);
    return () => {
      window.clearInterval(iv);
      window.clearInterval(reveal);
    };
  }, [phase]);

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center overflow-y-auto bg-maroon-deep/97 px-4 py-8 backdrop-blur-sm">
      {phase === 0 ? (
        <div className="anim-pop text-center">
          <img src={GIF_RING_1} alt="Ring moment" className="mx-auto max-h-[52vh] rounded-2xl shadow-2xl" />
          <p className="mt-4 font-script text-4xl text-gold-soft">Angoothi pehen gayi…</p>
        </div>
      ) : phase === 1 ? (
        <div className="anim-pop text-center">
          <img src={GIF_RING_2} alt="Together forever" className="mx-auto max-h-[52vh] rounded-2xl shadow-2xl" />
          <p className="mt-4 font-script text-4xl text-gold-soft">…aur dil bhi.</p>
        </div>
      ) : (
        <div className="w-full max-w-2xl text-center">
          <p className="anim-pop font-display text-sm tracking-[0.5em] text-gold-soft uppercase">13 · 09 · 2026</p>
          <h1 className="gold-shimmer anim-pop mt-2 font-script text-6xl leading-tight sm:text-7xl">
            Shaadi Poori Hui
          </h1>
          <p className="anim-fade-up mt-2 font-display text-xl italic text-cream/90 [animation-delay:0.4s]">
            Mr &amp; Mrs Mehra — officially, unofficially, forever.
          </p>

          <div className="chat-scroll mx-auto mt-8 max-h-[38vh] space-y-3 overflow-y-auto text-left">
            {FINALE_LINES.slice(0, Math.max(0, shown)).map((l, i) => (
              <p key={`f${i}`} className="anim-rotate-card rounded-xl border border-gold/40 bg-cream/10 px-4 py-3 font-display text-lg text-cream">
                {l}
              </p>
            ))}
            {shown > FINALE_LINES.length
              ? CHAT_TRANSCRIPT.slice(0, shown - FINALE_LINES.length).map((m, i) => (
                  <p key={`c${i}`} className="anim-rotate-card rounded-xl border border-gold/30 bg-cream/5 px-4 py-2.5 text-sm leading-relaxed text-cream/80">
                    <span className="font-bold text-gold-soft">{m.from === "nik" ? "Nik" : "Rumi"}:</span>{" "}
                    {m.text.length > 160 ? m.text.slice(0, 160) + "…" : m.text}
                  </p>
                ))
              : null}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="anim-fade-up mt-8 inline-flex items-center gap-2 rounded-full bg-gold px-8 py-3.5 font-display text-lg font-semibold text-maroon-deep shadow-xl transition hover:bg-gold-soft active:scale-95 [animation-delay:1s]"
          >
            <IconCheck className="w-5 h-5" />
            Yaadon mein chalo
          </button>
        </div>
      )}
    </div>
  );
}
