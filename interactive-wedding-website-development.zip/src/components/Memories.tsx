"use client";
import { useEffect, useRef, useState } from "react";
import { post, type FullState, type ItemState } from "@/lib/api";
import { other, PARTNER_META, type PartnerId } from "@/lib/data";
import {
  CopyButton,
  IconCheck,
  IconImage,
  IconLock,
  IconMic,
  IconNote,
  IconPing,
  IconPlus,
  IconSend,
  IconUnlock,
  IconVideo,
  IconX,
  pushToast,
} from "./bits";

type Kind = "text" | "image" | "video" | "voice";

function fileToDataUrl(f: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = reject;
    r.readAsDataURL(f);
  });
}

export function Memories({
  state,
  identity,
  focusId,
  onPing,
}: {
  state: FullState;
  identity: PartnerId;
  focusId: string | null;
  onPing: () => void;
}) {
  const [activeTab, setActiveTab] = useState<string>(state.tabs[0]?.id ?? "");
  const [newTab, setNewTab] = useState("");
  const [showNewTab, setShowNewTab] = useState(false);

  const [kind, setKind] = useState<Kind>("text");
  const [text, setText] = useState("");
  const [lock, setLock] = useState(false);
  const [lockCode, setLockCode] = useState("");
  const [busy, setBusy] = useState(false);

  const [rec, setRec] = useState<MediaRecorder | null>(null);
  const [voicePreview, setVoicePreview] = useState<string | null>(null);
  const [mediaPreview, setMediaPreview] = useState<{ kind: Kind; data: string } | null>(null);
  const [unlockedIds, setUnlockedIds] = useState<Record<string, boolean>>({});
  const [codeDraft, setCodeDraft] = useState<Record<string, string>>({});

  const them = other(identity);

  useEffect(() => {
    if (!activeTab && state.tabs[0]) setActiveTab(state.tabs[0].id);
  }, [state.tabs, activeTab]);

  useEffect(() => {
    if (focusId) {
      const el = document.getElementById(`mem-${focusId}`);
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "center" });
        const item = state.items.find((i) => i.id === focusId);
        if (item && item.tabId !== activeTab) setActiveTab(item.tabId);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusId]);

  const items = state.items.filter((i) => i.tabId === activeTab);

  async function send(body: string, k: Kind) {
    setBusy(true);
    try {
      await post("item-new", {
        tabId: activeTab,
        authorId: identity,
        kind: k,
        body,
        locked: lock,
        lockCode: lock ? lockCode || "1314" : null,
      });
      pushToast(lock ? "Yaad lock ho kar save ho gayi." : "Yaad save ho gayi — live.", "gold");
      setText("");
      setVoicePreview(null);
      setMediaPreview(null);
      setLock(false);
      setLockCode("");
    } catch {
      pushToast("Save nahi ho payi, dobara try karo.", "rose");
    } finally {
      setBusy(false);
    }
  }

  async function pickFile(f: File | undefined, k: Kind) {
    if (!f) return;
    if (f.size > 3_200_000) {
      pushToast("File 3MB se chhoti rakho, jaan.", "rose");
      return;
    }
    const data = await fileToDataUrl(f);
    setMediaPreview({ kind: k, data });
  }

  async function startVoice() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      const chunks: Blob[] = [];
      mr.ondataavailable = (e) => chunks.push(e.data);
      mr.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunks, { type: mr.mimeType || "audio/webm" });
        if (blob.size > 3_200_000) {
          pushToast("Voice note bahut lamba ho gaya.", "rose");
          return;
        }
        const data = await fileToDataUrl(new File([blob], "vn.webm", { type: blob.type }));
        setVoicePreview(data);
      };
      mr.start();
      setRec(mr);
    } catch {
      pushToast("Mic access nahi mila.", "rose");
    }
  }
  function stopVoice() {
    if (rec && rec.state !== "inactive") rec.stop();
    setRec(null);
  }

  async function tryUnlockItem(it: ItemState) {
    const code = codeDraft[it.id] ?? "";
    const res = await post<{ ok: boolean }>("item-check", { id: it.id, code });
    if (res.ok) {
      setUnlockedIds((u) => ({ ...u, [it.id]: true }));
      pushToast("Lock khul gaya.", "gold");
    } else {
      pushToast("Galat code.", "rose");
    }
  }

  return (
    <section className="mx-auto max-w-3xl">
      {/* header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="font-script text-4xl text-rose">hamari yaadein</p>
          <p className="text-sm text-ink/70">
            Jo bhi yahan daloge, {PARTNER_META[them].nickname} ko live dikhega. Chat nahi — sirf yaadein.
          </p>
        </div>
        <button
          type="button"
          onClick={onPing}
          className="inline-flex items-center gap-2 rounded-full bg-maroon px-5 py-2.5 font-display font-semibold text-cream shadow-lg transition hover:bg-maroon-soft active:scale-95"
        >
          <IconPing className="w-5 h-5 text-gold-soft anim-heart" />
          {PARTNER_META[them].nickname} ko ping karo
        </button>
      </div>

      {/* tabs */}
      <div className="mt-6 flex flex-wrap items-center gap-2">
        {state.tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setActiveTab(t.id)}
            className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${
              activeTab === t.id
                ? "border-maroon bg-maroon text-cream shadow"
                : "border-gold/50 bg-cream text-maroon hover:bg-cream-2"
            }`}
          >
            {t.name}
          </button>
        ))}
        {showNewTab ? (
          <form
            className="flex items-center gap-2"
            onSubmit={async (e) => {
              e.preventDefault();
              if (!newTab.trim()) return;
              const res = await post<{ tab: { id: string } }>("tab-new", { name: newTab });
              setActiveTab(res.tab.id);
              setNewTab("");
              setShowNewTab(false);
              pushToast("Naya memory tab ban gaya.", "gold");
            }}
          >
            <input
              autoFocus
              value={newTab}
              onChange={(e) => setNewTab(e.target.value)}
              placeholder="Tab ka naam"
              className="w-36 rounded-full border border-gold/60 bg-cream px-3 py-2 text-sm outline-none focus:border-maroon"
            />
            <button type="submit" className="rounded-full bg-maroon p-2 text-cream"><IconCheck className="w-4 h-4" /></button>
            <button type="button" onClick={() => setShowNewTab(false)} className="rounded-full border border-gold/50 p-2 text-maroon"><IconX className="w-4 h-4" /></button>
          </form>
        ) : (
          <button
            type="button"
            onClick={() => setShowNewTab(true)}
            className="inline-flex items-center gap-1 rounded-full border border-dashed border-gold/70 px-4 py-2 text-sm font-semibold text-gold-deep transition hover:bg-gold-soft/30"
          >
            <IconPlus className="w-4 h-4" /> Naya tab
          </button>
        )}
      </div>

      {/* composer */}
      <div className="ornate-frame mt-6 rounded-2xl bg-cream p-5">
        <div className="flex flex-wrap gap-2">
          {(
            [
              ["text", "Note", <IconNote key="n" className="w-4 h-4" />],
              ["image", "Photo", <IconImage key="i" className="w-4 h-4" />],
              ["video", "Video", <IconVideo key="v" className="w-4 h-4" />],
            ] as [Kind, string, React.ReactNode][]
          ).map(([k, label, icon]) => (
            <button
              key={k}
              type="button"
              onClick={() => {
                setKind(k);
                setMediaPreview(null);
                setVoicePreview(null);
              }}
              className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-2 text-sm font-semibold transition ${
                kind === k ? "border-maroon bg-maroon text-cream" : "border-gold/50 bg-cream-2 text-maroon hover:bg-gold-soft/40"
              }`}
            >
              {icon} {label}
            </button>
          ))}
        </div>

        <div className="mt-4">
          {kind === "text" ? (
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={3}
              placeholder={`${PARTNER_META[them].nickname} ke liye kuch likho…`}
              className="w-full rounded-xl border border-gold/50 bg-cream-2/60 px-4 py-3 text-sm outline-none focus:border-maroon"
            />
          ) : (
            <label className="flex cursor-pointer flex-col items-center gap-2 rounded-xl border-2 border-dashed border-gold/60 bg-cream-2/50 px-4 py-8 text-center transition hover:bg-gold-soft/20">
              {kind === "image" ? <IconImage className="w-8 h-8 text-maroon" /> : <IconVideo className="w-8 h-8 text-maroon" />}
              <span className="text-sm font-semibold text-maroon">{kind === "image" ? "Photo chuno" : "Video chuno"} (max 3MB)</span>
              <input
                type="file"
                accept={kind === "image" ? "image/*" : "video/*"}
                className="hidden"
                onChange={(e) => void pickFile(e.target.files?.[0], kind)}
              />
            </label>
          )}

          {/* voice hold button */}
          <div className="mt-3 flex items-center gap-3">
            <button
              type="button"
              onPointerDown={() => void startVoice()}
              onPointerUp={stopVoice}
              onPointerLeave={() => rec && stopVoice()}
              className={`inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold shadow transition active:scale-95 ${
                rec ? "bg-rose text-cream anim-glow" : "bg-cream-2 text-maroon border border-gold/60"
              }`}
            >
              <IconMic className="w-4 h-4" />
              {rec ? "Sun raha hoon… chhodo to save hoga" : "Mic dabaye rakho — voice note"}
            </button>
            {voicePreview ? <audio controls src={voicePreview} className="h-9" /> : null}
          </div>

          {mediaPreview ? (
            <div className="mt-3 rounded-xl border border-gold/50 bg-cream-2/50 p-3">
              {mediaPreview.kind === "image" ? (
                <img src={mediaPreview.data} alt="preview" className="max-h-48 rounded-lg" />
              ) : (
                <video src={mediaPreview.data} controls className="max-h-48 rounded-lg" />
              )}
            </div>
          ) : null}

          <div className="mt-4 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => setLock((l) => !l)}
              className={`inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-semibold transition ${
                lock ? "border-maroon bg-maroon text-cream" : "border-gold/50 bg-cream-2 text-maroon"
              }`}
            >
              {lock ? <IconLock className="w-4 h-4" /> : <IconUnlock className="w-4 h-4" />}
              {lock ? "Locked rahegi" : "Lock lagao"}
            </button>
            {lock ? (
              <input
                value={lockCode}
                onChange={(e) => setLockCode(e.target.value)}
                placeholder="Lock code (default 1314)"
                className="w-44 rounded-full border border-gold/60 bg-cream px-3 py-2 text-sm outline-none focus:border-maroon"
              />
            ) : null}
            <button
              type="button"
              disabled={busy || (!text && !voicePreview && !mediaPreview)}
              onClick={() => {
                if (mediaPreview) void send(mediaPreview.data, mediaPreview.kind);
                else if (voicePreview) void send(voicePreview, "voice");
                else if (text.trim()) void send(text.trim(), "text");
              }}
              className="ml-auto inline-flex items-center gap-2 rounded-full bg-maroon px-6 py-2.5 font-display font-semibold text-cream shadow-lg transition hover:bg-maroon-soft active:scale-95 disabled:opacity-40"
            >
              <IconSend className="w-4 h-4" /> Save karo
            </button>
          </div>
        </div>
      </div>

      {/* items */}
      <div className="mt-8 space-y-4">
        {items.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-gold/60 bg-cream/60 p-8 text-center text-sm text-ink/60">
            Is tab mein abhi koi yaad nahi. Pehli yaad aap dono mein se koi bhi daal sakta hai.
          </p>
        ) : (
          items.map((it) => {
            const isLocked = it.locked && !unlockedIds[it.id];
            const author = PARTNER_META[it.authorId as PartnerId];
            return (
              <article
                id={`mem-${it.id}`}
                key={it.id}
                className={`anim-fade-up rounded-2xl border bg-cream p-4 shadow-md ${
                  focusId === it.id ? "border-rose ring-2 ring-rose/40" : "border-gold/50"
                }`}
              >
                <header className="flex flex-wrap items-center gap-2 text-xs text-ink/60">
                  <span className="rounded-full bg-maroon/10 px-2.5 py-1 font-bold text-maroon">{author.nickname}</span>
                  <span>{new Date(it.createdAt).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
                  {it.locked ? (
                    <span className="inline-flex items-center gap-1 rounded-full bg-gold-soft/40 px-2.5 py-1 font-semibold text-gold-deep">
                      <IconLock className="w-3 h-3" /> locked
                    </span>
                  ) : null}
                  <span className="ml-auto"><CopyButton value={`${window.location.origin}/?m=${it.id}`} label="Link bhejo" /></span>
                </header>

                {isLocked ? (
                  <div className="mt-3 flex flex-col items-start gap-2 rounded-xl bg-cream-2/70 p-4">
                    <p className="flex items-center gap-2 text-sm font-semibold text-maroon"><IconLock className="w-4 h-4" /> Ye yaad lock hai</p>
                    <div className="flex gap-2">
                      <input
                        type="password"
                        value={codeDraft[it.id] ?? ""}
                        onChange={(e) => setCodeDraft((c) => ({ ...c, [it.id]: e.target.value }))}
                        placeholder="Code daalo"
                        className="w-40 rounded-lg border border-gold/60 bg-cream px-3 py-2 text-sm outline-none focus:border-maroon"
                      />
                      <button type="button" onClick={() => void tryUnlockItem(it)} className="rounded-lg bg-maroon px-4 py-2 text-sm font-semibold text-cream">Kholo</button>
                    </div>
                  </div>
                ) : (
                  <div className="mt-3">
                    {it.kind === "text" ? (
                      <p className="whitespace-pre-wrap text-[15px] leading-relaxed text-ink/90">{it.body}</p>
                    ) : it.kind === "image" ? (
                      <img src={it.body} alt="memory" className="max-h-80 rounded-xl border border-gold/40" />
                    ) : it.kind === "video" ? (
                      <video src={it.body} controls className="max-h-80 rounded-xl" />
                    ) : (
                      <audio controls src={it.body} className="w-full" />
                    )}
                  </div>
                )}
              </article>
            );
          })
        )}
      </div>
    </section>
  );
}
