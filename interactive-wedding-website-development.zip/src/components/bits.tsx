"use client";
import { useEffect, useMemo, useState } from "react";

/* ---------------- inline SVG icons (no emoji in UI chrome) ---------------- */
type IconProps = { className?: string };

export const IconHeart = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
    <path d="M12 21s-7.5-4.7-10-9.3C.4 8.6 2 5 5.5 5c2 0 3.4 1.1 4.5 2.7C11.1 6.1 12.5 5 14.5 5 18 5 19.6 8.6 22 11.7 19.5 16.3 12 21 12 21z" />
  </svg>
);
export const IconRing = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className} aria-hidden>
    <circle cx="12" cy="14.5" r="6" />
    <path d="M9.5 6.5 12 3l2.5 3.5L12 9z" fill="currentColor" stroke="none" />
  </svg>
);
export const IconLock = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className} aria-hidden>
    <rect x="5" y="10.5" width="14" height="9.5" rx="2" />
    <path d="M8 10.5V8a4 4 0 0 1 8 0v2.5" />
  </svg>
);
export const IconUnlock = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className} aria-hidden>
    <rect x="5" y="10.5" width="14" height="9.5" rx="2" />
    <path d="M8 10.5V8a4 4 0 0 1 7.7-1.5" />
  </svg>
);
export const IconMic = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className} aria-hidden>
    <rect x="9" y="3" width="6" height="11" rx="3" />
    <path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M9 21h6" />
  </svg>
);
export const IconImage = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className} aria-hidden>
    <rect x="3.5" y="4.5" width="17" height="15" rx="2.5" />
    <circle cx="9" cy="10" r="1.8" />
    <path d="m5 18 5-5 3.5 3.5L17 13l3.5 4" />
  </svg>
);
export const IconVideo = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className} aria-hidden>
    <rect x="3" y="6" width="13" height="12" rx="2.5" />
    <path d="m16 10.5 5-3v9l-5-3z" />
  </svg>
);
export const IconNote = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className} aria-hidden>
    <path d="M6 3.5h9L19 7.5V20.5H6z" />
    <path d="M14.5 3.5v4.5H19M9 12h6M9 15.5h6" />
  </svg>
);
export const IconSend = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
    <path d="M3 11.5 21 3l-6.5 18-3-7.5z" />
  </svg>
);
export const IconCopy = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className} aria-hidden>
    <rect x="8.5" y="8.5" width="12" height="12" rx="2" />
    <path d="M15.5 8.5v-3a2 2 0 0 0-2-2h-8a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h3" />
  </svg>
);
export const IconCheck = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" className={className} aria-hidden>
    <path d="m4.5 12.5 5 5L19.5 6.5" />
  </svg>
);
export const IconX = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" className={className} aria-hidden>
    <path d="m6 6 12 12M18 6 6 18" />
  </svg>
);
export const IconLink = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className} aria-hidden>
    <path d="M10 14a4.5 4.5 0 0 0 6.4 0l3-3a4.5 4.5 0 0 0-6.4-6.4l-1.5 1.5" />
    <path d="M14 10a4.5 4.5 0 0 0-6.4 0l-3 3a4.5 4.5 0 0 0 6.4 6.4l1.5-1.5" />
  </svg>
);
export const IconPing = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className} aria-hidden>
    <path d="M12 20a8 8 0 0 0 8-8c0-4.4-3.6-8-8-8s-8 3.6-8 8c0 1.6.5 3.1 1.3 4.4L4 20l3.8-1.2A7.9 7.9 0 0 0 12 20z" />
    <path d="M9 12h.01M12 12h.01M15 12h.01" strokeWidth="2.6" strokeLinecap="round" />
  </svg>
);
export const IconPlus = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" className={className} aria-hidden>
    <path d="M12 5v14M5 12h14" />
  </svg>
);
export const IconSparkle = ({ className = "w-5 h-5" }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
    <path d="M12 2.5 14 9l6.5 2L14 13l-2 6.5L10 13l-6.5-2L10 9z" />
  </svg>
);

/* ---------------- copy button ---------------- */
export function CopyButton({ value, label }: { value: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
        } catch {
          const ta = document.createElement("textarea");
          ta.value = value;
          document.body.appendChild(ta);
          ta.select();
          document.execCommand("copy");
          ta.remove();
        }
        setCopied(true);
        window.setTimeout(() => setCopied(false), 1600);
      }}
      className="inline-flex items-center gap-2 rounded-full border border-gold/60 bg-cream px-4 py-2 text-xs font-semibold tracking-wide text-maroon transition hover:bg-gold-soft/40 active:scale-95"
    >
      {copied ? <IconCheck className="w-4 h-4 text-green-700" /> : <IconCopy className="w-4 h-4" />}
      {copied ? "Copy ho gaya" : label ?? "Copy karo"}
    </button>
  );
}

/* ---------------- falling rose petals ---------------- */
export function Petals({ count = 18 }: { count?: number }) {
  const petals = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        left: (i * 53) % 100,
        delay: (i * 0.9) % 9,
        dur: 8 + ((i * 1.7) % 7),
        size: 8 + ((i * 3) % 10),
      })),
    [count]
  );
  return (
    <div className="pointer-events-none fixed inset-0 z-10 overflow-hidden" aria-hidden>
      {petals.map((p, i) => (
        <span
          key={i}
          className="petal"
          style={{
            left: `${p.left}%`,
            width: p.size,
            height: p.size * 0.8,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.dur}s`,
          }}
        />
      ))}
    </div>
  );
}

/* ---------------- tiny toast bus ---------------- */
export function pushToast(text: string, tone: "gold" | "rose" = "gold") {
  window.dispatchEvent(new CustomEvent("nr-toast", { detail: { text, tone } }));
}

export function ToastHost() {
  const [toasts, setToasts] = useState<{ id: number; text: string; tone: string }[]>([]);
  useEffect(() => {
    const on = (e: Event) => {
      const d = (e as CustomEvent).detail as { text: string; tone: string };
      const id = Date.now() + Math.random();
      setToasts((t) => [...t, { id, ...d }]);
      window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3600);
    };
    window.addEventListener("nr-toast", on);
    return () => window.removeEventListener("nr-toast", on);
  }, []);
  return (
    <div className="fixed bottom-5 left-1/2 z-[90] flex w-[min(92vw,420px)] -translate-x-1/2 flex-col gap-2">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`anim-pop rounded-xl border px-4 py-3 text-sm font-medium shadow-xl backdrop-blur ${
            t.tone === "rose"
              ? "border-rose/50 bg-maroon-deep/95 text-cream"
              : "border-gold/60 bg-cream/95 text-maroon-deep"
          }`}
        >
          {t.text}
        </div>
      ))}
    </div>
  );
}

/* ---------------- decorative heading ---------------- */
export function SectionTitle({
  script,
  title,
  sub,
}: {
  script: string;
  title: string;
  sub?: string;
}) {
  return (
    <div className="text-center">
      <p className="font-script text-3xl text-rose sm:text-4xl">{script}</p>
      <h2 className="font-display text-2xl font-semibold tracking-wide text-maroon-deep sm:text-3xl">
        {title}
      </h2>
      {sub ? <p className="mt-1 text-sm text-ink/70">{sub}</p> : null}
      <div className="mx-auto mt-3 flex items-center justify-center gap-3 text-gold">
        <span className="h-px w-14 bg-gold/70" />
        <IconSparkle className="w-4 h-4" />
        <span className="h-px w-14 bg-gold/70" />
      </div>
    </div>
  );
}
