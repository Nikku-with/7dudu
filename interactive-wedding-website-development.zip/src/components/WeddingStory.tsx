"use client";
import { CHAT_TRANSCRIPT, WEDDING_DATE_LABEL, WEDDING_IMAGES } from "@/lib/data";
import { IconHeart, SectionTitle } from "./bits";

/* ------------------------- MARRIAGE CERTIFICATE ------------------------- */
export function Certificate() {
  return (
    <section className="relative">
      <SectionTitle
        script="hamara pramaan patra"
        title="Marriage Certificate"
        sub="Khud likhi, khud nibhayi — bina duniya ke, poori duniya se zyada."
      />

      <div className="paper ornate-frame relative mx-auto mt-8 max-w-3xl rounded-2xl p-6 sm:p-10">
        {/* corner flourishes */}
        {["top-3 left-3", "top-3 right-3 rotate-90", "bottom-3 right-3 rotate-180", "bottom-3 left-3 -rotate-90"].map(
          (pos) => (
            <svg key={pos} viewBox="0 0 40 40" className={`absolute h-8 w-8 text-gold ${pos}`} fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden>
              <path d="M2 38V14C2 7 7 2 14 2h24" />
              <path d="M8 38V16c0-4.4 3.6-8 8-8h22" opacity="0.6" />
              <circle cx="10" cy="10" r="2.4" fill="currentColor" stroke="none" />
            </svg>
          )
        )}

        <p className="text-center font-display text-xs tracking-[0.5em] text-gold-deep uppercase">
          Certificate of Marriage
        </p>
        <p className="mt-2 text-center font-script text-5xl text-rose sm:text-6xl">
          Nikhil weds Rashmika
        </p>
        <p className="mt-1 text-center font-display text-lg italic text-maroon">
          {WEDDING_DATE_LABEL} · self-solemnised with love
        </p>

        <div className="mx-auto my-6 flex items-center justify-center gap-4 text-gold">
          <span className="h-px w-24 bg-gold/70" />
          <IconHeart className="w-5 h-5 text-rose anim-heart" />
          <span className="h-px w-24 bg-gold/70" />
        </div>

        <div className="grid gap-6 sm:grid-cols-2">
          <div className="rounded-xl border border-gold/50 bg-cream/70 p-5">
            <p className="font-display text-xs tracking-[0.35em] text-gold-deep uppercase">वर · The Groom</p>
            <p className="mt-1 font-display text-2xl font-semibold text-maroon-deep">Nikhil Mehra</p>
            <dl className="mt-3 space-y-1.5 text-sm text-ink/80">
              <div className="flex gap-2"><dt className="w-14 shrink-0 font-semibold text-maroon">पिता</dt><dd>Pramod Mehra</dd></div>
              <div className="flex gap-2"><dt className="w-14 shrink-0 font-semibold text-maroon">माता</dt><dd>Sunita Mehra</dd></div>
            </dl>
          </div>
          <div className="rounded-xl border border-gold/50 bg-cream/70 p-5">
            <p className="font-display text-xs tracking-[0.35em] text-gold-deep uppercase">वधू · The Bride</p>
            <p className="mt-1 font-display text-2xl font-semibold text-maroon-deep">Rashmika Mehra</p>
            <p className="text-xs italic text-ink/60">née Rana · pyaar se “Rumi”</p>
            <dl className="mt-3 space-y-1.5 text-sm text-ink/80">
              <div className="flex gap-2"><dt className="w-14 shrink-0 font-semibold text-maroon">पिता</dt><dd>Mahaveer Rana</dd></div>
              <div className="flex gap-2"><dt className="w-14 shrink-0 font-semibold text-maroon">माता</dt><dd>Sukh Dei</dd></div>
            </dl>
          </div>
        </div>

        <p className="mt-6 text-center text-sm leading-relaxed text-ink/75">
          Is din dono ne ek dusre ka haath thhaama, vachan liye, aur bina kisi
          mandap ke apna mandap khud bana liya. Ye pramaan patra gawah hai ki
          Nikhil aur Rashmika ab ek hain — aaj, kal, hamesha.
        </p>

        {/* seal */}
        <div className="mt-6 flex items-end justify-between">
          <div className="text-left">
            <p className="font-script text-3xl text-maroon">Nikhil</p>
            <p className="h-px w-32 bg-ink/50" />
            <p className="mt-1 text-[10px] tracking-widest text-ink/60 uppercase">Groom · Nik</p>
          </div>
          <div className="anim-spin-slow relative flex h-24 w-24 items-center justify-center rounded-full border-2 border-dashed border-rose/70 text-rose" style={{ animationDuration: "40s" }}>
            <div className="text-center">
              <p className="font-script text-2xl leading-none">N &amp; R</p>
              <p className="text-[8px] tracking-[0.25em] uppercase">13·09·2026</p>
            </div>
          </div>
          <div className="text-right">
            <p className="font-script text-3xl text-maroon">Rashmika</p>
            <p className="ml-auto h-px w-32 bg-ink/50" />
            <p className="mt-1 text-[10px] tracking-widest text-ink/60 uppercase">Bride · Rumi</p>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------- CHAT WALL ------------------------- */
export function ChatWall() {
  return (
    <section className="relative mt-20">
      <SectionTitle
        script="uss raat ki baatein"
        title="Vachan & Vaade — Original Chats"
        sub="13 September 2026 · jaise likha tha, waise hi, line by line."
      />

      <div className="mx-auto mt-8 max-w-2xl overflow-hidden rounded-3xl border-2 border-gold/70 bg-[#efe7db] shadow-2xl">
        <div className="flex items-center gap-3 bg-maroon px-5 py-3 text-cream">
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gold-soft text-maroon-deep">
            <IconHeart className="w-4 h-4" />
          </span>
          <div>
            <p className="font-display text-lg font-semibold leading-tight">Nik ♥ Rumii</p>
            <p className="text-[11px] text-gold-soft/90">13 Sep 2026 · private · forever</p>
          </div>
        </div>

        <div className="chat-scroll max-h-[560px] space-y-4 overflow-y-auto px-4 py-6 sm:px-6">
          <p className="mx-auto w-fit rounded-full bg-cream-3/70 px-4 py-1 text-[11px] font-semibold tracking-widest text-maroon uppercase">
            13 September 2026
          </p>
          {CHAT_TRANSCRIPT.map((m, i) => (
            <div
              key={i}
              className={`anim-line flex ${m.from === "nik" ? "justify-end" : "justify-start"}`}
              style={{ animationDelay: `${0.25 + i * 0.35}s` }}
            >
              <div className={`max-w-[85%] ${m.from === "nik" ? "text-right" : "text-left"}`}>
                <p className={`mb-1 px-1 text-[11px] font-bold tracking-wide ${m.from === "nik" ? "text-maroon-soft" : "text-rose"}`}>
                  {m.from === "nik" ? "𝙉𝙠 ⌁" : "Rumii"}
                  {m.replyTo ? <span className="ml-1 font-normal text-ink/50">↩ {m.replyTo}</span> : null}
                </p>
                <div
                  className={`whitespace-pre-wrap rounded-2xl px-4 py-3 text-left text-[13.5px] leading-relaxed shadow-sm ${
                    m.from === "nik"
                      ? "rounded-tr-sm bg-maroon text-cream"
                      : "rounded-tl-sm border border-gold/40 bg-cream text-ink"
                  }`}
                >
                  {m.text}
                </div>
                <p className="mt-1 px-1 text-[10px] text-ink/45">{m.time}</p>
              </div>
            </div>
          ))}
          <p className="anim-fade-up pt-2 text-center font-script text-3xl text-rose [animation-delay:3.4s]">
            …aur baaki poori zindagi baaki hai.
          </p>
        </div>
      </div>

      {/* gallery with names */}
      <div className="mx-auto mt-10 grid max-w-4xl gap-5 sm:grid-cols-2">
        {WEDDING_IMAGES.map((img, i) => (
          <figure
            key={img.src}
            className="anim-fade-up group overflow-hidden rounded-2xl border-2 border-gold/60 bg-cream shadow-lg"
            style={{ animationDelay: `${0.2 + i * 0.15}s` }}
          >
            <div className="overflow-hidden">
              <img
                src={img.src}
                alt={`Nikhil and Rashmika — ${img.caption}`}
                className="h-64 w-full object-cover transition duration-700 group-hover:scale-105"
              />
            </div>
            <figcaption className="flex items-center justify-between px-4 py-3">
              <span className="font-display text-sm font-semibold text-maroon-deep">{img.caption}</span>
              <span className="font-script text-xl text-rose">Nikhil ♥ Rashmika</span>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}
